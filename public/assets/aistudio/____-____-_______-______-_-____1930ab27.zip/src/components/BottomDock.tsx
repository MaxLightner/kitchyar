import React from 'react';
import {
  AppWindow,
  BrickWall,
  DoorClosed,
  Eraser,
  Flame,
  GripVertical,
  MousePointer2,
  Pencil,
  RectangleHorizontal,
  Refrigerator,
} from 'lucide-react';
import { ToolId } from '../cad/types';

interface BottomDockProps {
  activeTool: ToolId;
  onSelectTool: (tool: ToolId) => void;
}

export const BottomDock: React.FC<BottomDockProps> = ({
  activeTool,
  onSelectTool,
}) => {
  const btnCls = (active: boolean, danger = false) =>
    `h-11 px-3 rounded-xl border text-xs font-bold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 transition active:scale-95 ${
      active
        ? danger
          ? 'bg-red-600 border-red-600 text-white shadow-sm'
          : 'bg-indigo-600 border-indigo-600 text-white shadow-sm'
        : 'bg-white border-slate-300 text-slate-800 hover:bg-slate-50'
    }`;

  return (
    <div className="relative shrink-0 z-30">
      <nav
        aria-label="ابزارهای درج و طراحی"
        className="h-14 bg-white border-t border-slate-200 flex items-center justify-start sm:justify-center px-2.5 gap-1.5 overflow-x-auto no-scrollbar"
      >
        {/* گروه درج سازه و باکس و تجهیزات */}
        <button
          type="button"
          onClick={() => onSelectTool('wall')}
          aria-pressed={activeTool === 'wall'}
          className={btnCls(activeTool === 'wall')}
        >
          <BrickWall className="w-4 h-4" />
          <span>دیوار</span>
        </button>

        <button
          type="button"
          onClick={() => onSelectTool('cab-draw')}
          aria-pressed={activeTool === 'cab-draw'}
          className={btnCls(activeTool === 'cab-draw')}
        >
          <RectangleHorizontal className="w-4 h-4" />
          <span>باکس کابینت</span>
        </button>

        <button
          type="button"
          onClick={() => onSelectTool('fridge')}
          aria-pressed={activeTool === 'fridge'}
          className={btnCls(activeTool === 'fridge')}
        >
          <Refrigerator className="w-4 h-4" />
          <span>یخچال</span>
        </button>

        <button
          type="button"
          onClick={() => onSelectTool('appliance')}
          aria-pressed={activeTool === 'appliance'}
          className={btnCls(activeTool === 'appliance')}
        >
          <Flame className="w-4 h-4" />
          <span>تجهیزات</span>
        </button>

        <button
          type="button"
          onClick={() => onSelectTool('opening')}
          aria-pressed={activeTool === 'opening'}
          className={btnCls(activeTool === 'opening')}
        >
          <AppWindow className="w-4 h-4" />
          <span>پنجره / درب / ستون</span>
        </button>

        <div className="w-px h-6 bg-slate-200 mx-0.5 shrink-0" />

        {/* گروه طراحی نما، یونیت‌بندی و ویرایش */}
        <button
          type="button"
          onClick={() => onSelectTool('doors')}
          aria-pressed={activeTool === 'doors'}
          className={btnCls(activeTool === 'doors')}
        >
          <DoorClosed className="w-4 h-4" />
          <span>درب‌گذاری</span>
        </button>

        <button
          type="button"
          onClick={() => onSelectTool('pencil')}
          aria-pressed={activeTool === 'pencil' || activeTool === 'skeleton'}
          className={btnCls(activeTool === 'pencil' || activeTool === 'skeleton')}
        >
          <Pencil className="w-4 h-4" />
          <span>مداد / یونیت و طبقه</span>
        </button>

        <button
          type="button"
          onClick={() => onSelectTool('handle')}
          aria-pressed={activeTool === 'handle'}
          className={btnCls(activeTool === 'handle')}
        >
          <GripVertical className="w-4 h-4" />
          <span>دستگیره</span>
        </button>

        <button
          type="button"
          onClick={() => onSelectTool('select')}
          aria-pressed={activeTool === 'select'}
          className={btnCls(activeTool === 'select')}
        >
          <MousePointer2 className="w-4 h-4" />
          <span>انتخاب و تراز</span>
        </button>

        <button
          type="button"
          onClick={() => onSelectTool('eraser')}
          aria-pressed={activeTool === 'eraser'}
          className={btnCls(activeTool === 'eraser', true)}
        >
          <Eraser className="w-4 h-4" />
          <span>پاک‌کن</span>
        </button>
      </nav>
    </div>
  );
};
