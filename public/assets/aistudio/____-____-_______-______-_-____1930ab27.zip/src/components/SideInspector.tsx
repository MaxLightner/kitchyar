import React from 'react';
import {
  AlignCenterHorizontal,
  AlignLeft,
  AlignRight,
  ChevronLeft,
  ChevronRight,
  Columns2,
  Columns3,
  Columns4,
  DoorClosed,
  FlipHorizontal2,
  Lock,
  LockOpen,
  RotateCw,
  Rows3,
  Shirt,
  SlidersHorizontal,
  SquareDashed,
  Trash2,
} from 'lucide-react';
import {
  APPLIANCE_CONFIGS,
  DRAWER_PATTERNS,
  FRIDGE_MODELS,
  FRIDGE_MODEL_ORDER,
  LIFT_PATTERNS,
  MAX_DOOR_CM,
  MIN_DOOR_CM,
} from '../cad/constants';
import { OPENING_LABELS } from '../cad/openingRules';
import {
  ApplianceKind,
  BoxKind,
  CabinetBox,
  DoorKind,
  DoorSwing,
  DoorUnit,
  FridgeModel,
  HandleStyle,
  MultiSelection,
  OpeningKind,
  Orientation,
  ToolId,
  Wall,
  WallOpening,
} from '../cad/types';

interface SideInspectorProps {
  collapsed: boolean;
  onToggleCollapse: () => void;
  activeTool: ToolId;
  activeWall: Wall | null;
  activeBox: CabinetBox | null;
  selectedDoor: DoorUnit | null;
  selectedOpening: WallOpening | null;
  multiSelection?: MultiSelection;
  doorsLocked: boolean;
  // Tool states
  drawBoxKind: BoxKind;
  onSelectDrawBoxKind: (k: BoxKind) => void;
  doorOrient: Orientation;
  onSetDoorOrient: (o: Orientation) => void;
  doorTargetWidth: number;
  onSetDoorTargetWidth: (w: number) => void;
  doorVertCount: number;
  onSetDoorVertCount: (c: number) => void;
  drawerPatIdx: number;
  onSetDrawerPatIdx: (i: number) => void;
  liftPatIdx: number;
  onSetLiftPatIdx: (i: number) => void;
  shelfCount: number;
  onSetShelfCount: (c: number) => void;
  handleStyle: HandleStyle;
  onSetHandleStyle: (s: HandleStyle) => void;
  handleOrient: Orientation;
  onSetHandleOrient: (o: Orientation) => void;
  fridgeModel: FridgeModel;
  onSetFridgeModel: (m: FridgeModel) => void;
  fridgeHasFrame: boolean;
  onSetFridgeHasFrame: (v: boolean) => void;
  applianceKind: ApplianceKind;
  onSetApplianceKind: (k: ApplianceKind) => void;
  hoodKind: 'hidden' | 'chimney';
  onSetHoodKind: (h: 'hidden' | 'chimney') => void;
  openingKind: OpeningKind;
  onSetOpeningKind: (k: OpeningKind) => void;
  openingSwing: DoorSwing;
  onSetOpeningSwing: (s: DoorSwing) => void;
  onToggleLock: () => void;
  // Selection & align actions
  onSetDoorKind: (kind: DoorKind, drawerRatios?: number[]) => void;
  onDivideEvenly: (count: number) => void;
  onEqualizeDoors: () => void;
  onMirrorBox: () => void;
  onAlignBox: (pos: 'left' | 'center' | 'right') => void;
  onAddFiller: (side: 'left' | 'right') => void;
  onUpdateBoxNumeric: (field: 'width' | 'height' | 'offsetX' | 'elevY' | 'depth', val: number) => void;
  onDeleteSelectedBox: () => void;
  onUpdateOpeningNumeric: (
    field: 'offsetX' | 'width' | 'elevY' | 'height',
    val: number
  ) => void;
  onChangeOpeningSwing: (s: DoorSwing) => void;
  onDeleteSelectedOpening: () => void;
  onOptimizeAppliances: () => void;
  onBulkDelete: () => void;
  onBulkSetDoorKind: (kind: DoorKind, ratios?: number[]) => void;
  onBulkEqualizeDoors: () => void;
  onClearMultiSelection: () => void;
}

const BOX_KINDS: Array<{ id: BoxKind; label: string }> = [
  { id: 'base', label: 'زمینی (۸۶×۶۰)' },
  { id: 'wall', label: 'هوایی (۷۵×۳۲)' },
  { id: 'wall-deep', label: 'هوایی عمق‌دار (۴۵×۵۸)' },
  { id: 'tall', label: 'قدی (۲۲۰×۶۰)' },
  { id: 'closet', label: 'کمد دیواری (۲۳۵×۶۰)' },
];

const SWING_LABELS: Array<{ id: DoorSwing; label: string }> = [
  { id: 'left-in', label: 'چپ ← داخل' },
  { id: 'right-in', label: 'راست ← داخل' },
  { id: 'left-out', label: 'چپ ← بیرون' },
  { id: 'right-out', label: 'راست ← بیرون' },
];

export const SideInspector: React.FC<SideInspectorProps> = (props) => {
  const {
    collapsed,
    onToggleCollapse,
    activeTool,
    activeWall,
    activeBox,
    selectedDoor,
    selectedOpening,
    multiSelection,
    doorsLocked,
  } = props;

  if (collapsed) {
    return (
      <aside className="w-10 bg-white border-l border-slate-200 flex flex-col items-center py-2 shrink-0 z-25">
        <button
          type="button"
          onClick={onToggleCollapse}
          aria-label="باز کردن پنل تنظیمات ابزار"
          title="باز کردن پنل تنظیمات"
          className="h-9 w-8 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 inline-flex items-center justify-center"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
      </aside>
    );
  }

  const isWallBox = activeBox?.type === 'wall' || activeBox?.type === 'wall-deep';
  const isStepDrawer =
    selectedDoor?.kind === 'drawer' &&
    selectedDoor.drawerRatios.length === 2 &&
    selectedDoor.drawerRatios[0] < 0.28;
  const isEq3Drawer =
    selectedDoor?.kind === 'drawer' &&
    selectedDoor.drawerRatios.length === 2 &&
    selectedDoor.drawerRatios[0] >= 0.28;

  return (
    <aside
      aria-label="پنل تنظیمات و بازرس ابزار"
      className="fixed sm:static top-12 bottom-14 right-0 w-[236px] bg-white border-l border-slate-200 flex flex-col overflow-y-auto no-scrollbar shrink-0 z-25 shadow-xl sm:shadow-none"
    >
      {/* هدر پنل کنار */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-slate-200 shrink-0 sticky top-0 bg-white z-10">
        <div className="flex items-center gap-1.5 text-xs font-extrabold text-slate-800">
          <SlidersHorizontal className="w-3.5 h-3.5 text-indigo-600" />
          <span>تنظیمات ابزار</span>
        </div>
        <button
          type="button"
          onClick={onToggleCollapse}
          aria-label="بستن پنل کنار"
          className="h-7 w-7 rounded-md hover:bg-slate-100 text-slate-500 inline-flex items-center justify-center"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <div className="p-3 pb-6 space-y-4 text-xs">
        {/* ۱. تنظیمات ابزار فعال */}
        {activeTool === 'cab-draw' && (
          <section className="space-y-2">
            <h3 className="text-[11px] font-extrabold text-slate-500">نوع باکس برای رسم</h3>
            <div className="space-y-1">
              {BOX_KINDS.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => props.onSelectDrawBoxKind(item.id)}
                  className={`w-full h-9 px-2.5 rounded-lg border text-right text-xs font-bold transition ${
                    props.drawBoxKind === item.id
                      ? 'bg-indigo-50 border-indigo-600 text-indigo-700'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </section>
        )}

        {activeTool === 'doors' && (
          <section className="space-y-3">
            <h3 className="text-[11px] font-extrabold text-slate-500">تنظیمات براش درب</h3>

            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={() => props.onSetDoorOrient('vertical')}
                className={`h-9 rounded-lg border text-xs font-bold transition ${
                  props.doorOrient === 'vertical'
                    ? 'bg-indigo-600 border-indigo-600 text-white'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                عمودی (درب)
              </button>
              <button
                type="button"
                onClick={() => props.onSetDoorOrient('horizontal')}
                className={`h-9 rounded-lg border text-xs font-bold transition ${
                  props.doorOrient === 'horizontal'
                    ? 'bg-indigo-600 border-indigo-600 text-white'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                افقی (کشو/جک)
              </button>
            </div>

            {/* عرض مستقیم درب ۳۰..۶۰ */}
            <div className="space-y-1.5 pt-1 border-t border-slate-100">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-600">عرض درب هدف</span>
                <span className="text-xs font-extrabold text-indigo-700 tabular-nums">
                  {props.doorTargetWidth} cm
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() =>
                    props.onSetDoorTargetWidth(Math.max(MIN_DOOR_CM, props.doorTargetWidth - 5))
                  }
                  aria-label="کاهش عرض درب"
                  className="h-8 w-8 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 font-bold"
                >
                  -
                </button>
                <input
                  type="range"
                  min={MIN_DOOR_CM}
                  max={MAX_DOOR_CM}
                  step={5}
                  aria-label="اسلایدر عرض درب از ۳۰ تا ۶۰"
                  value={props.doorTargetWidth}
                  onChange={(e) => props.onSetDoorTargetWidth(Number(e.target.value))}
                  className="flex-1 accent-indigo-600"
                />
                <button
                  type="button"
                  onClick={() =>
                    props.onSetDoorTargetWidth(Math.min(MAX_DOOR_CM, props.doorTargetWidth + 5))
                  }
                  aria-label="افزایش عرض درب"
                  className="h-8 w-8 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 font-bold"
                >
                  +
                </button>
              </div>
              <div className="grid grid-cols-5 gap-1">
                {[30, 40, 45, 50, 60].map((w) => (
                  <button
                    key={w}
                    type="button"
                    onClick={() => props.onSetDoorTargetWidth(w)}
                    className={`h-7 rounded border text-[11px] font-bold tabular-nums ${
                      props.doorTargetWidth === w
                        ? 'bg-indigo-50 border-indigo-600 text-indigo-700'
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {w}
                  </button>
                ))}
              </div>
            </div>

            {props.doorOrient === 'vertical' ? (
              <div className="space-y-1.5 pt-1 border-t border-slate-100">
                <span className="text-[11px] font-bold text-slate-600 block">
                  تعداد درب در هر کلیک
                </span>
                <div className="grid grid-cols-4 gap-1">
                  {[1, 2, 3, 4].map((cnt) => (
                    <button
                      key={cnt}
                      type="button"
                      onClick={() => props.onSetDoorVertCount(cnt)}
                      className={`h-8 rounded-lg border text-xs font-bold tabular-nums ${
                        props.doorVertCount === cnt
                          ? 'bg-indigo-50 border-indigo-600 text-indigo-700'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      {cnt}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-1.5 pt-1 border-t border-slate-100">
                <span className="text-[11px] font-bold text-slate-600 block">
                  {isWallBox ? 'الگوی درب افقی هوایی' : 'الگوی کشوی زمینی'}
                </span>
                <div className="space-y-1">
                  {(isWallBox ? LIFT_PATTERNS : DRAWER_PATTERNS).map((pat, idx) => {
                    const active = isWallBox
                      ? props.liftPatIdx === idx
                      : props.drawerPatIdx === idx;
                    return (
                      <button
                        key={pat.id}
                        type="button"
                        onClick={() =>
                          isWallBox
                            ? props.onSetLiftPatIdx(idx)
                            : props.onSetDrawerPatIdx(idx)
                        }
                        className={`w-full h-8 px-2.5 rounded-lg border text-right text-xs font-bold ${
                          active
                            ? 'bg-indigo-50 border-indigo-600 text-indigo-700'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        {pat.label}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </section>
        )}

        {activeTool === 'fridge' && (
          <section className="space-y-2.5">
            <h3 className="text-[11px] font-extrabold text-slate-500">مدل یخچال</h3>
            <div className="space-y-1.5">
              {FRIDGE_MODEL_ORDER.map((m) => {
                const cfg = FRIDGE_MODELS[m];
                return (
                  <button
                    key={m}
                    type="button"
                    onClick={() => props.onSetFridgeModel(m)}
                    className={`w-full h-10 px-2.5 rounded-lg border text-right text-xs font-bold flex items-center justify-between ${
                      props.fridgeModel === m
                        ? 'bg-indigo-50 border-indigo-600 text-indigo-700'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span>{cfg.shortLabel}</span>
                    <span className="text-[11px] tabular-nums opacity-80">
                      {cfg.width}×{cfg.depth}
                    </span>
                  </button>
                );
              })}
            </div>
            <label className="flex items-center gap-2 pt-1 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={props.fridgeHasFrame}
                onChange={(e) => props.onSetFridgeHasFrame(e.target.checked)}
                className="rounded border-slate-300 text-indigo-600"
              />
              <span className="text-slate-700 font-semibold">فریم ۲cm دور یخچال</span>
            </label>
            <p className="text-[11px] text-slate-500 leading-relaxed">
              کلیک در نمای پلان یا روبرو، یخچال + کابینت افقی بالای آن را هم‌تراز با ردیف هوایی می‌سازد.
            </p>
          </section>
        )}

        {activeTool === 'appliance' && (
          <section className="space-y-2.5">
            <h3 className="text-[11px] font-extrabold text-slate-500">انتخاب تجهیز</h3>
            <div className="space-y-1.5">
              {(['sink', 'gas', 'dishwasher', 'washing'] as ApplianceKind[]).map((k) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => props.onSetApplianceKind(k)}
                  className={`w-full h-9 px-2.5 rounded-lg border text-right text-xs font-bold ${
                    props.applianceKind === k
                      ? 'bg-indigo-50 border-indigo-600 text-indigo-700'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {APPLIANCE_CONFIGS[k].label}
                </button>
              ))}
            </div>

            {props.applianceKind === 'gas' && (
              <div className="space-y-1.5 pt-2 border-t border-slate-100">
                <span className="text-[11px] font-bold text-slate-600 block">نوع هود بالای گاز</span>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => props.onSetHoodKind('hidden')}
                    className={`h-8 rounded-lg border text-xs font-bold ${
                      props.hoodKind === 'hidden'
                        ? 'bg-indigo-50 border-indigo-600 text-indigo-700'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    مخفی
                  </button>
                  <button
                    type="button"
                    onClick={() => props.onSetHoodKind('chimney')}
                    className={`h-8 rounded-lg border text-xs font-bold ${
                      props.hoodKind === 'chimney'
                        ? 'bg-indigo-50 border-indigo-600 text-indigo-700'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    شومینه‌ای
                  </button>
                </div>
              </div>
            )}

            <p className="text-[11px] text-slate-500 leading-relaxed">
              قابل درج روی باکس زمینی در هر دو نمای پلان و روبرو (با جلوگیری خودکار از هم‌پوشانی).
            </p>
          </section>
        )}

        {activeTool === 'opening' && (
          <section className="space-y-2.5">
            <h3 className="text-[11px] font-extrabold text-slate-500">درج پنجره، درب و ستون</h3>
            <div className="space-y-1.5">
              {(['window', 'door', 'column'] as OpeningKind[]).map((ok) => (
                <button
                  key={ok}
                  type="button"
                  onClick={() => props.onSetOpeningKind(ok)}
                  className={`w-full h-9 px-2.5 rounded-lg border text-right text-xs font-bold ${
                    props.openingKind === ok
                      ? 'bg-indigo-50 border-indigo-600 text-indigo-700'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {OPENING_LABELS[ok]}
                </button>
              ))}
            </div>

            {props.openingKind === 'door' && (
              <div className="space-y-1 pt-2 border-t border-slate-100">
                <span className="text-[11px] font-bold text-slate-600 block">جهت بازشو</span>
                <div className="grid grid-cols-2 gap-1">
                  {SWING_LABELS.map((sw) => (
                    <button
                      key={sw.id}
                      type="button"
                      onClick={() => props.onSetOpeningSwing(sw.id)}
                      className={`h-8 rounded border text-[11px] font-bold ${
                        props.openingSwing === sw.id
                          ? 'bg-indigo-50 border-indigo-600 text-indigo-700'
                          : 'bg-white border-slate-200 text-slate-700'
                      }`}
                    >
                      {sw.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <p className="text-[11px] text-slate-500 leading-relaxed">
              روی دیوار در پلان یا روبرو کلیک کنید؛ سپس در حالت انتخاب با کشیدن لبه‌ها اندازه و جایش را تغییر دهید.
            </p>
          </section>
        )}

        {(activeTool === 'pencil' || activeTool === 'skeleton') && (
          <section className="space-y-2.5">
            <h3 className="text-[11px] font-extrabold text-slate-500">مداد یونیت‌بندی و طبقه</h3>
            <div className="flex items-center justify-between">
              <span className="text-slate-600 font-bold">تعداد طبقه در کلیک</span>
              <span className="text-amber-700 font-extrabold tabular-nums">
                {props.shelfCount} طبقه
              </span>
            </div>
            <div className="grid grid-cols-4 gap-1">
              {[1, 2, 3, 4].map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => props.onSetShelfCount(c)}
                  className={`h-8 rounded-lg border text-xs font-bold tabular-nums ${
                    props.shelfCount === c
                      ? 'bg-amber-50 border-amber-600 text-amber-800'
                      : 'bg-white border-slate-200 text-slate-700'
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={props.onToggleLock}
              className="w-full h-9 rounded-lg border border-slate-300 bg-slate-50 hover:bg-slate-100 text-slate-800 font-bold inline-flex items-center justify-center gap-1.5"
            >
              {doorsLocked ? <Lock className="w-3.5 h-3.5" /> : <LockOpen className="w-3.5 h-3.5" />}
              <span>{doorsLocked ? 'باز کردن قفل درب‌ها' : 'قفل کردن درب‌ها'}</span>
            </button>
          </section>
        )}

        {activeTool === 'handle' && (
          <section className="space-y-2.5">
            <h3 className="text-[11px] font-extrabold text-slate-500">مدل و جهت دستگیره</h3>
            <div className="grid grid-cols-3 gap-1">
              {(
                [
                  { id: 'simple', label: 'ساده' },
                  { id: 'knob', label: 'قارچی' },
                  { id: 'hidden', label: 'مخفی' },
                ] as Array<{ id: HandleStyle; label: string }>
              ).map((st) => (
                <button
                  key={st.id}
                  type="button"
                  onClick={() => props.onSetHandleStyle(st.id)}
                  className={`h-8 rounded-lg border text-xs font-bold ${
                    props.handleStyle === st.id
                      ? 'bg-indigo-50 border-indigo-600 text-indigo-700'
                      : 'bg-white border-slate-200 text-slate-700'
                  }`}
                >
                  {st.label}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() =>
                props.onSetHandleOrient(props.handleOrient === 'vertical' ? 'horizontal' : 'vertical')
              }
              className="w-full h-9 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-800 font-bold inline-flex items-center justify-center gap-1.5"
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span>جهت: {props.handleOrient === 'vertical' ? 'عمودی' : 'افقی'}</span>
            </button>
          </section>
        )}

        {/* ۱ب. کارت انتخاب گروهی (Marquee Selection) */}
        {multiSelection &&
          multiSelection.boxIds.length +
            multiSelection.doorIds.length +
            multiSelection.openingIds.length +
            multiSelection.applianceIds.length >
            0 && (
            <section className="space-y-2 pt-2.5 border-t border-indigo-200 bg-indigo-50/70 -mx-1 px-2.5 py-2.5 rounded-xl">
              <div className="flex items-center justify-between">
                <h3 className="text-[11px] font-extrabold text-indigo-800">
                  انتخاب گروهی (
                  {multiSelection.boxIds.length} باکس · {multiSelection.doorIds.length} درب ·{' '}
                  {multiSelection.openingIds.length + multiSelection.applianceIds.length} تجهیز/بازشو)
                </h3>
                <button
                  type="button"
                  onClick={props.onClearMultiSelection}
                  className="text-[11px] font-bold text-slate-500 hover:text-slate-800"
                >
                  لغو
                </button>
              </div>
              {multiSelection.doorIds.length > 0 && (
                <div className="grid grid-cols-3 gap-1">
                  <button
                    type="button"
                    onClick={() => props.onBulkSetDoorKind('door', [])}
                    className="h-8 rounded-lg border border-indigo-200 bg-white hover:bg-indigo-50 text-[11px] font-bold text-slate-700"
                  >
                    همه درب
                  </button>
                  <button
                    type="button"
                    onClick={() => props.onBulkSetDoorKind('drawer', [0.333, 0.667])}
                    className="h-8 rounded-lg border border-indigo-200 bg-white hover:bg-indigo-50 text-[11px] font-bold text-slate-700"
                  >
                    همه کشو
                  </button>
                  <button
                    type="button"
                    onClick={props.onBulkEqualizeDoors}
                    className="h-8 rounded-lg border border-indigo-200 bg-white hover:bg-indigo-50 text-[11px] font-bold text-slate-700"
                  >
                    مساوی‌سازی
                  </button>
                </div>
              )}
              <button
                type="button"
                onClick={props.onBulkDelete}
                className="w-full h-8 rounded-lg border border-red-300 bg-red-600 hover:bg-red-700 text-white text-xs font-bold inline-flex items-center justify-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>حذف یکجای موارد انتخاب‌شده</span>
              </button>
            </section>
          )}

        {/* ۲. بازرس پنجره / درب / ستون انتخاب‌شده */}
        {selectedOpening && (
          <section className="space-y-2.5 pt-3 border-t border-slate-200">
            <div className="flex items-center justify-between">
              <h3 className="text-[11px] font-extrabold text-sky-700">
                {OPENING_LABELS[selectedOpening.kind]} انتخاب‌شده
              </h3>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <label className="block">
                <span className="text-[11px] text-slate-500 block mb-0.5">فاصله از دیوار</span>
                <input
                  type="number"
                  min={0}
                  max={activeWall?.length || 500}
                  value={selectedOpening.offsetX}
                  onChange={(e) => props.onUpdateOpeningNumeric('offsetX', Number(e.target.value))}
                  className="w-full h-8 px-2 border border-slate-300 rounded-md text-xs font-bold tabular-nums bg-slate-50"
                />
              </label>
              <label className="block">
                <span className="text-[11px] text-slate-500 block mb-0.5">عرض (cm)</span>
                <input
                  type="number"
                  min={20}
                  max={activeWall?.length || 500}
                  value={selectedOpening.width}
                  onChange={(e) => props.onUpdateOpeningNumeric('width', Number(e.target.value))}
                  className="w-full h-8 px-2 border border-slate-300 rounded-md text-xs font-bold tabular-nums bg-slate-50"
                />
              </label>
              {selectedOpening.kind === 'window' && (
                <label className="block">
                  <span className="text-[11px] text-slate-500 block mb-0.5">ارتفاع از کف</span>
                  <input
                    type="number"
                    min={0}
                    max={activeWall?.height || 265}
                    value={selectedOpening.elevY}
                    onChange={(e) => props.onUpdateOpeningNumeric('elevY', Number(e.target.value))}
                    className="w-full h-8 px-2 border border-slate-300 rounded-md text-xs font-bold tabular-nums bg-slate-50"
                  />
                </label>
              )}
              {selectedOpening.kind !== 'column' && (
                <label className="block">
                  <span className="text-[11px] text-slate-500 block mb-0.5">ارتفاع (cm)</span>
                  <input
                    type="number"
                    min={40}
                    max={activeWall?.height || 265}
                    value={selectedOpening.height}
                    onChange={(e) => props.onUpdateOpeningNumeric('height', Number(e.target.value))}
                    className="w-full h-8 px-2 border border-slate-300 rounded-md text-xs font-bold tabular-nums bg-slate-50"
                  />
                </label>
              )}
            </div>

            {selectedOpening.kind === 'door' && (
              <div className="grid grid-cols-2 gap-1">
                {SWING_LABELS.map((sw) => (
                  <button
                    key={sw.id}
                    type="button"
                    onClick={() => props.onChangeOpeningSwing(sw.id)}
                    className={`h-7 rounded border text-[11px] font-bold ${
                      selectedOpening.swingDir === sw.id
                        ? 'bg-sky-50 border-sky-600 text-sky-700'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    {sw.label}
                  </button>
                ))}
              </div>
            )}

            <button
              type="button"
              onClick={props.onDeleteSelectedOpening}
              className="w-full h-8 rounded-lg border border-red-200 bg-red-50 hover:bg-red-100 text-red-700 text-xs font-bold inline-flex items-center justify-center gap-1"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>حذف {OPENING_LABELS[selectedOpening.kind]}</span>
            </button>
          </section>
        )}

        {/* ۳. بازرس باکس و درب انتخاب‌شده */}
        {activeBox && (
          <section className="space-y-3 pt-3 border-t border-slate-200">
            <div className="flex items-center justify-between">
              <h3 className="text-[11px] font-extrabold text-slate-700">
                باکس: {activeBox.name}
              </h3>
              <span className="text-[11px] font-bold text-slate-400 tabular-nums">
                {activeBox.width}×{activeBox.height}
              </span>
            </div>

            {/* تبدیل نوع نما */}
            {selectedDoor && selectedDoor.kind !== 'fridge' && (
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold text-slate-500 block">تغییر نوع درب انتخاب‌شده</span>
                <div className="grid grid-cols-3 gap-1">
                  <button
                    type="button"
                    onClick={() => props.onSetDoorKind('door', [])}
                    className={`h-8 rounded-lg border text-[11px] font-bold inline-flex items-center justify-center gap-1 ${
                      selectedDoor.kind === 'door'
                        ? 'bg-indigo-50 border-indigo-600 text-indigo-700'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    <DoorClosed className="w-3.5 h-3.5" />
                    <span>درب</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => props.onSetDoorKind('drawer', [0.333, 0.667])}
                    className={`h-8 rounded-lg border text-[11px] font-bold inline-flex items-center justify-center gap-1 ${
                      isEq3Drawer
                        ? 'bg-indigo-50 border-indigo-600 text-indigo-700'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    <Rows3 className="w-3.5 h-3.5" />
                    <span>۳ کشو</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => props.onSetDoorKind('drawer', [0.22, 0.54])}
                    className={`h-8 rounded-lg border text-[11px] font-bold ${
                      isStepDrawer
                        ? 'bg-indigo-50 border-indigo-600 text-indigo-700'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    پلکانی
                  </button>
                  <button
                    type="button"
                    onClick={() => props.onSetDoorKind('lift', [])}
                    className={`h-8 rounded-lg border text-[11px] font-bold ${
                      selectedDoor.kind === 'lift'
                        ? 'bg-indigo-50 border-indigo-600 text-indigo-700'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    افقی
                  </button>
                  <button
                    type="button"
                    onClick={() => props.onSetDoorKind('open', [])}
                    className={`h-8 rounded-lg border text-[11px] font-bold inline-flex items-center justify-center gap-1 ${
                      selectedDoor.kind === 'open'
                        ? 'bg-indigo-50 border-indigo-600 text-indigo-700'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    <SquareDashed className="w-3.5 h-3.5" />
                    <span>قفسه</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => props.onSetDoorKind('rail', [])}
                    className={`h-8 rounded-lg border text-[11px] font-bold inline-flex items-center justify-center gap-1 ${
                      selectedDoor.kind === 'rail'
                        ? 'bg-indigo-50 border-indigo-600 text-indigo-700'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    <Shirt className="w-3.5 h-3.5" />
                    <span>رگال</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => props.onSetDoorKind('oven', [])}
                    className={`h-8 rounded-lg border text-[11px] font-bold col-span-3 ${
                      selectedDoor.kind === 'oven'
                        ? 'bg-indigo-50 border-indigo-600 text-indigo-700'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    فر توکار
                  </button>
                </div>
              </div>
            )}

            {/* ابزارهای تراز و تقسیم */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-bold text-slate-500 block">تراز و تقسیم درب‌ها</span>
              <button
                type="button"
                onClick={props.onEqualizeDoors}
                disabled={activeBox.doors.length < 2}
                className="w-full h-8 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40 text-slate-700 text-xs font-bold inline-flex items-center justify-center gap-1.5"
              >
                <AlignCenterHorizontal className="w-3.5 h-3.5" />
                <span>مساوی‌سازی درب‌ها</span>
              </button>

              <div className="grid grid-cols-4 gap-1">
                <button
                  type="button"
                  onClick={() => props.onDivideEvenly(2)}
                  aria-label="تقسیم به ۲ مساوی"
                  className="h-8 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-xs font-bold inline-flex items-center justify-center gap-0.5"
                >
                  <Columns2 className="w-3.5 h-3.5" />
                  <span>۲</span>
                </button>
                <button
                  type="button"
                  onClick={() => props.onDivideEvenly(3)}
                  aria-label="تقسیم به ۳ مساوی"
                  className="h-8 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-xs font-bold inline-flex items-center justify-center gap-0.5"
                >
                  <Columns3 className="w-3.5 h-3.5" />
                  <span>۳</span>
                </button>
                <button
                  type="button"
                  onClick={() => props.onDivideEvenly(4)}
                  aria-label="تقسیم به ۴ مساوی"
                  className="h-8 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-xs font-bold inline-flex items-center justify-center gap-0.5"
                >
                  <Columns4 className="w-3.5 h-3.5" />
                  <span>۴</span>
                </button>
                <button
                  type="button"
                  onClick={props.onMirrorBox}
                  aria-label="قرینه‌سازی"
                  className="h-8 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-[11px] font-bold inline-flex items-center justify-center"
                  title="قرینه چپ و راست"
                >
                  <FlipHorizontal2 className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-3 gap-1">
                <button
                  type="button"
                  onClick={() => props.onAlignBox('right')}
                  disabled={!activeWall}
                  aria-label="چسباندن به راست دیوار"
                  className="h-8 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 flex items-center justify-center"
                >
                  <AlignRight className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => props.onAlignBox('center')}
                  disabled={!activeWall}
                  aria-label="وسط دیوار"
                  className="h-8 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 flex items-center justify-center"
                >
                  <AlignCenterHorizontal className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => props.onAlignBox('left')}
                  disabled={!activeWall}
                  aria-label="چسباندن به چپ دیوار"
                  className="h-8 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 flex items-center justify-center"
                >
                  <AlignLeft className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-2 gap-1">
                <button
                  type="button"
                  onClick={() => props.onAddFiller('left')}
                  className="h-7 rounded border border-slate-200 bg-slate-50 hover:bg-slate-100 text-[11px] font-bold text-slate-700"
                >
                  + لقی ۴cm چپ
                </button>
                <button
                  type="button"
                  onClick={() => props.onAddFiller('right')}
                  className="h-7 rounded border border-slate-200 bg-slate-50 hover:bg-slate-100 text-[11px] font-bold text-slate-700"
                >
                  + لقی ۴cm راست
                </button>
              </div>
            </div>

            {/* ابعاد عددی دقیق */}
            <div className="grid grid-cols-2 gap-2">
              <label className="block">
                <span className="text-[11px] text-slate-500 block mb-0.5">عرض (cm)</span>
                <input
                  type="number"
                  min={30}
                  max={activeWall?.length || 500}
                  value={activeBox.width}
                  onChange={(e) => props.onUpdateBoxNumeric('width', Number(e.target.value))}
                  className="w-full h-8 px-2 border border-slate-300 rounded-md text-xs font-bold tabular-nums bg-slate-50"
                />
              </label>
              <label className="block">
                <span className="text-[11px] text-slate-500 block mb-0.5">ارتفاع (cm)</span>
                <input
                  type="number"
                  min={30}
                  max={activeWall?.height || 280}
                  value={activeBox.height}
                  onChange={(e) => props.onUpdateBoxNumeric('height', Number(e.target.value))}
                  className="w-full h-8 px-2 border border-slate-300 rounded-md text-xs font-bold tabular-nums bg-slate-50"
                />
              </label>
              <label className="block">
                <span className="text-[11px] text-slate-500 block mb-0.5">عمق (cm)</span>
                <input
                  type="number"
                  min={20}
                  max={90}
                  value={activeBox.depth}
                  onChange={(e) => props.onUpdateBoxNumeric('depth', Number(e.target.value))}
                  className="w-full h-8 px-2 border border-slate-300 rounded-md text-xs font-bold tabular-nums bg-slate-50"
                />
              </label>
              <label className="block">
                <span className="text-[11px] text-slate-500 block mb-0.5">فاصله از دیوار</span>
                <input
                  type="number"
                  min={0}
                  max={activeWall?.length || 500}
                  value={activeBox.offsetX}
                  onChange={(e) => props.onUpdateBoxNumeric('offsetX', Number(e.target.value))}
                  className="w-full h-8 px-2 border border-slate-300 rounded-md text-xs font-bold tabular-nums bg-slate-50"
                />
              </label>
            </div>

            {activeBox.type === 'base' &&
              activeWall?.appliances.some(
                (a) =>
                  (a.kind === 'dishwasher' || a.kind === 'washing') &&
                  a.offsetX >= activeBox.offsetX - 1 &&
                  a.offsetX + a.width <= activeBox.offsetX + activeBox.width + 1
              ) && (
                <button
                  type="button"
                  onClick={props.onOptimizeAppliances}
                  className="w-full h-8 rounded-lg border border-indigo-300 bg-indigo-50 hover:bg-indigo-100 text-indigo-800 text-xs font-bold"
                >
                  چیدمان بهینه تجهیزات (بدون پرتی)
                </button>
              )}

            <button
              type="button"
              onClick={props.onDeleteSelectedBox}
              aria-label="حذف باکس انتخاب‌شده"
              className="w-full h-8 rounded-lg border border-red-200 bg-red-50 hover:bg-red-100 text-red-700 text-xs font-bold inline-flex items-center justify-center gap-1"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>حذف باکس</span>
            </button>
          </section>
        )}
      </div>
    </aside>
  );
};
