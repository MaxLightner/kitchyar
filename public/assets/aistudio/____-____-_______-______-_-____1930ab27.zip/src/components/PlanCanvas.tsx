import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  APPLIANCE_CONFIGS,
  FRIDGE_MODELS,
  FRIDGE_MODEL_ORDER,
  OPENING_DEFAULTS,
} from '../cad/constants';
import {
  analyzeCornerJunction,
  collectSmartWallNodes,
  computeMultiWallSweep,
  detectCornerJunctions,
  getOutsideCornerBridges,
  getPlanPolygonForBox,
  getWallVectors,
  orientEmptyConnectedWallsFromSeed,
  snapWallNodePosition,
  SweepSegment,
  WallNodeRef,
} from '../cad/cornerLogic';
import { createEmptyBox, createWall } from '../cad/doorRules';
import {
  ApplianceKind,
  BoxKind,
  CabinetBox,
  DoorSwing,
  FridgeModel,
  OpeningKind,
  ToolId,
  Wall,
} from '../cad/types';

const APPLIANCE_ORDER: ApplianceKind[] = ['sink', 'gas', 'dishwasher', 'washing'];
const OPENING_ORDER: OpeningKind[] = ['window', 'door', 'column'];

interface PlanCanvasProps {
  walls: Wall[];
  cornerOwners: Record<string, string>;
  activeWallId: string | null;
  activeBoxId: string | null;
  selectedOpeningId: string | null;
  tool: ToolId;
  drawBoxKind: BoxKind;
  fridgeModel: FridgeModel;
  onFridgeModelChange: (m: FridgeModel) => void;
  applianceKind: ApplianceKind;
  onApplianceKindChange: (k: ApplianceKind) => void;
  openingKind: OpeningKind;
  onOpeningKindChange: (k: OpeningKind) => void;
  openingSwing: DoorSwing;
  hintText: string;
  onSelectWall: (wallId: string, boxId?: string | null) => void;
  onSelectOpening: (wallId: string, openingId: string) => void;
  onFlipActiveWallSide: () => void;
  onToggleCornerOwner: (cornerKey: string) => void;
  onAddWall: (wall: Wall) => void;
  onMoveWallNode: (refs: WallNodeRef[], x: number, y: number, commit: boolean) => void;
  onDeleteWall: (wallId: string) => void;
  onDeleteBox: (wallId: string, boxId: string) => void;
  onDeleteAppliance: (wallId: string, appId: string) => void;
  onDeleteOpening: (wallId: string, openingId: string) => void;
  onMoveOpening: (wallId: string, openingId: string, offsetX: number, commit: boolean) => void;
  onCreateBoxesFromSweep: (
    segments: SweepSegment[],
    kind: BoxKind,
    suggestedOwners?: Record<string, string>,
    flipOverrides?: Record<string, 1 | -1>
  ) => void;
  onPlaceApplianceFromPlan: (wallId: string, boxId: string, offsetX: number) => void;
  onPlaceFridgeFromPlan: (wallId: string, offsetX: number) => void;
  onPlaceOpeningFromPlan: (wallId: string, offsetX: number) => void;
  onToast: (msg: string) => void;
}

export const PlanCanvas: React.FC<PlanCanvasProps> = ({
  walls,
  cornerOwners,
  activeWallId,
  activeBoxId,
  selectedOpeningId,
  tool,
  drawBoxKind,
  fridgeModel,
  onFridgeModelChange,
  applianceKind,
  onApplianceKindChange,
  openingKind,
  onOpeningKindChange,
  openingSwing,
  hintText,
  onSelectWall,
  onSelectOpening,
  onFlipActiveWallSide,
  onToggleCornerOwner,
  onAddWall,
  onMoveWallNode,
  onDeleteWall,
  onDeleteBox,
  onDeleteAppliance,
  onDeleteOpening,
  onMoveOpening,
  onCreateBoxesFromSweep,
  onPlaceApplianceFromPlan,
  onPlaceFridgeFromPlan,
  onPlaceOpeningFromPlan,
  onToast,
}) => {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const paneRef = useRef<HTMLElement | null>(null);

  const [planScale, setPlanScale] = useState(0.6);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [wallDraw, setWallDraw] = useState<{
    startPt: { x: number; y: number } | null;
    currPt: { x: number; y: number } | null;
    lengthCm: number;
    snappedCorner: boolean;
  }>({ startPt: null, currPt: null, lengthCm: 0, snappedCorner: false });

  const [cabSweep, setCabSweep] = useState<{
    active: boolean;
    startWallId: string | null;
    startOffsetCm: number;
    hasDragged: boolean;
    flipOverrides: Record<string, 1 | -1>;
    segments: SweepSegment[];
    suggestedOwners: Record<string, string>;
  }>({
    active: false,
    startWallId: null,
    startOffsetCm: 0,
    hasDragged: false,
    flipOverrides: {},
    segments: [],
    suggestedOwners: {},
  });

  const [planHoverWall, setPlanHoverWall] = useState<{
    wallId: string;
    offsetCm: number;
    boxId: string | null;
  } | null>(null);

  const dragOp = useRef<
    | { mode: 'pan'; startX: number; startY: number; origX: number; origY: number }
    | {
        mode: 'move-opening';
        wallId: string;
        openingId: string;
        startPtCm: { x: number; y: number };
        origOffsetX: number;
      }
    | {
        mode: 'move-node';
        refs: WallNodeRef[];
        lastX: number;
        lastY: number;
      }
    | null
  >(null);

  const touchPinch = useRef<{
    dist: number;
    midX: number;
    midY: number;
    origScale: number;
    origPan: { x: number; y: number };
  } | null>(null);

  const displayWalls = useMemo(() => {
    if (!cabSweep.active || Object.keys(cabSweep.flipOverrides).length === 0) {
      return walls;
    }
    return walls.map((w) =>
      cabSweep.flipOverrides[w.id] ? { ...w, flipSide: cabSweep.flipOverrides[w.id] } : w
    );
  }, [walls, cabSweep.active, cabSweep.flipOverrides]);

  const smartNodes = useMemo(() => collectSmartWallNodes(displayWalls), [displayWalls]);

  const junctions = useMemo(
    () => detectCornerJunctions(displayWalls, cornerOwners),
    [displayWalls, cornerOwners]
  );

  const inside90Junctions = useMemo(() => {
    return junctions
      .map((j) => {
        const wA = displayWalls.find((w) => w.id === j.wallAId);
        const wB = displayWalls.find((w) => w.id === j.wallBId);
        if (!wA || !wB) return null;
        if (analyzeCornerJunction(wA, j.wallAEnd, wB, j.wallBEnd).kind !== 'inside-90') return null;
        const vA = getWallVectors(wA);
        const vB = getWallVectors(wB);
        const bx = vA.nx + vB.nx;
        const by = vA.ny + vB.ny;
        const blen = Math.hypot(bx, by) || 1;
        return {
          ...j,
          btnXCm: j.xCm + (bx / blen) * 28,
          btnYCm: j.yCm + (by / blen) * 28,
        };
      })
      .filter((x): x is NonNullable<typeof x> => x !== null);
  }, [junctions, displayWalls]);

  const outsideBridges = useMemo(
    () => getOutsideCornerBridges(displayWalls, cornerOwners),
    [displayWalls, cornerOwners]
  );

  const clientToCm = (clientX: number, clientY: number) => {
    const svg = svgRef.current;
    if (!svg) return { x: 0, y: 0 };
    const pt = svg.createSVGPoint();
    pt.x = clientX;
    pt.y = clientY;
    const ctm = svg.getScreenCTM();
    if (!ctm) return { x: 0, y: 0 };
    const svgPt = pt.matrixTransform(ctm.inverse());
    return { x: svgPt.x / planScale, y: svgPt.y / planScale };
  };

  const snapWallPoint = (
    raw: { x: number; y: number },
    startPt: { x: number; y: number } | null
  ) => {
    for (const w of walls) {
      if (Math.hypot(raw.x - w.x1Cm, raw.y - w.y1Cm) < 18) {
        return { x: w.x1Cm, y: w.y1Cm, corner: true };
      }
      if (Math.hypot(raw.x - w.x2Cm, raw.y - w.y2Cm) < 18) {
        return { x: w.x2Cm, y: w.y2Cm, corner: true };
      }
    }
    let sx = Math.round(raw.x / 10) * 10;
    let sy = Math.round(raw.y / 10) * 10;
    if (startPt) {
      const dx = sx - startPt.x;
      const dy = sy - startPt.y;
      if (Math.hypot(dx, dy) > 15) {
        const deg = Math.abs((Math.atan2(dy, dx) * 180) / Math.PI);
        if (deg < 12 || deg > 168) sy = startPt.y;
        else if (Math.abs(deg - 90) < 12) sx = startPt.x;
      }
    }
    return { x: sx, y: sy, corner: false };
  };

  const projectPointToWalls = (ptCm: { x: number; y: number }, wallList: Wall[] = walls) => {
    let best: { wall: Wall; offsetCm: number; perp: number; signedPerp: number; score: number } | null = null;
    for (const w of wallList) {
      const rad = (w.angle * Math.PI) / 180;
      const ux = Math.cos(rad);
      const uy = Math.sin(rad);
      const vx = ptCm.x - w.x1Cm;
      const vy = ptCm.y - w.y1Cm;
      const proj = vx * ux + vy * uy;
      const signedPerp = -vx * uy + vy * ux;
      const perp = Math.abs(signedPerp);
      if (proj >= -30 && proj <= w.length + 30 && perp < 85) {
        const clamped = Math.max(0, Math.min(w.length, Math.round(proj / 5) * 5));
        const outOfSpanPenalty = proj < 0 ? -proj : proj > w.length ? proj - w.length : 0;
        const score = perp + outOfSpanPenalty * 1.4;
        if (!best || score < best.score) {
          best = { wall: w, offsetCm: clamped, perp, signedPerp, score };
        }
      }
    }
    return best;
  };

  const handlePointerDown = (e: React.PointerEvent<SVGSVGElement>) => {
    if (e.button === 2) return;
    if (e.button === 1) {
      e.preventDefault();
      e.currentTarget.setPointerCapture(e.pointerId);
      dragOp.current = {
        mode: 'pan',
        startX: e.clientX,
        startY: e.clientY,
        origX: pan.x,
        origY: pan.y,
      };
      return;
    }

    const targetEl = e.target as Element;

    const cornerEl = targetEl.closest('[data-corner-key]');
    if (cornerEl) {
      const key = cornerEl.getAttribute('data-corner-key');
      if (key) {
        onToggleCornerOwner(key);
        return;
      }
    }

    const nodeEl = targetEl.closest('[data-wall-node]');
    if (nodeEl && (tool === 'select' || tool === 'wall') && !wallDraw.startPt) {
      const key = nodeEl.getAttribute('data-wall-node');
      const node = smartNodes.find((n) => n.key === key);
      if (node) {
        e.currentTarget.setPointerCapture(e.pointerId);
        dragOp.current = {
          mode: 'move-node',
          refs: node.refs,
          lastX: node.xCm,
          lastY: node.yCm,
        };
        return;
      }
    }

    const ptCm = clientToCm(e.clientX, e.clientY);

    if (tool === 'wall') {
      const snapped = snapWallPoint(ptCm, wallDraw.startPt);
      if (!wallDraw.startPt) {
        setWallDraw({
          startPt: { x: snapped.x, y: snapped.y },
          currPt: { x: snapped.x, y: snapped.y },
          lengthCm: 0,
          snappedCorner: snapped.corner,
        });
      } else {
        const len = Math.round(
          Math.hypot(snapped.x - wallDraw.startPt.x, snapped.y - wallDraw.startPt.y)
        );
        if (len >= 40) {
          const newW = createWall(
            `دیوار ${walls.length + 1} (${len})`,
            wallDraw.startPt.x,
            wallDraw.startPt.y,
            snapped.x,
            snapped.y,
            1
          );
          onAddWall(newW);
          setWallDraw({
            startPt: { x: snapped.x, y: snapped.y },
            currPt: { x: snapped.x, y: snapped.y },
            lengthCm: 0,
            snappedCorner: false,
          });
        }
      }
      return;
    }

    // Unified priority Eraser in Plan view!
    if (tool === 'eraser') {
      const appEl = targetEl.closest('[data-plan-app-id]');
      if (appEl) {
        const aId = appEl.getAttribute('data-plan-app-id');
        const wId = appEl.getAttribute('data-plan-wall-id');
        if (aId && wId) {
          onDeleteAppliance(wId, aId);
          return;
        }
      }
      const openEl = targetEl.closest('[data-plan-opening-id]');
      if (openEl) {
        const oId = openEl.getAttribute('data-plan-opening-id');
        const wId = openEl.getAttribute('data-plan-wall-id');
        if (oId && wId) {
          onDeleteOpening(wId, oId);
          return;
        }
      }
      const boxEl = targetEl.closest('[data-plan-box-id]');
      if (boxEl) {
        const bId = boxEl.getAttribute('data-plan-box-id');
        const wId = boxEl.getAttribute('data-plan-wall-id');
        if (bId && wId) {
          onDeleteBox(wId, bId);
          return;
        }
      }
      const wEl = targetEl.closest('[data-wall-click]');
      if (wEl) {
        const wId = wEl.getAttribute('data-wall-click');
        if (wId) onDeleteWall(wId);
        return;
      }
    }

    // Place Fridge directly in Plan view!
    if (tool === 'fridge') {
      const hit = projectPointToWalls(ptCm, walls);
      if (hit) {
        const cfg = FRIDGE_MODELS[fridgeModel];
        onPlaceFridgeFromPlan(hit.wall.id, hit.offsetCm - cfg.width / 2);
        return;
      }
    }

    // Place Sink / Gas / Dishwasher / Washing directly in Plan view!
    if (tool === 'appliance') {
      const hit = projectPointToWalls(ptCm, walls);
      if (hit) {
        const cfg = APPLIANCE_CONFIGS[applianceKind];
        const baseBox = hit.wall.boxes.find(
          (b) =>
            b.type === 'base' &&
            hit.offsetCm >= b.offsetX - 5 &&
            hit.offsetCm <= b.offsetX + b.width + 5
        );
        if (baseBox) {
          onPlaceApplianceFromPlan(hit.wall.id, baseBox.id, hit.offsetCm - cfg.width / 2);
        } else {
          onToast('روی یک باکس زمینی در پلان کلیک کنید');
        }
        return;
      }
    }

    // Place Window / Room Door / Column directly in Plan view!
    if (tool === 'opening') {
      const hit = projectPointToWalls(ptCm, walls);
      if (hit) {
        const def = OPENING_DEFAULTS[openingKind];
        onPlaceOpeningFromPlan(hit.wall.id, hit.offsetCm - def.width / 2);
        return;
      }
    }

    if (tool === 'cab-draw') {
      const hit = projectPointToWalls(ptCm, walls);
      if (hit) {
        e.currentTarget.setPointerCapture(e.pointerId);

        const flipOverrides: Record<string, 1 | -1> = {};
        let workingWalls = walls;
        if (hit.wall.boxes.length === 0 && Math.abs(hit.signedPerp) >= 3) {
          const desiredFlip: 1 | -1 = hit.signedPerp >= 0 ? 1 : -1;
          if (desiredFlip !== hit.wall.flipSide) {
            const cloned: Wall[] = walls.map((w) => ({ ...w }));
            orientEmptyConnectedWallsFromSeed(cloned, hit.wall.id, desiredFlip);
            cloned.forEach((cw, idx) => {
              if (cw.flipSide !== walls[idx].flipSide) {
                flipOverrides[cw.id] = cw.flipSide;
              }
            });
            workingWalls = cloned;
          }
        }

        const initial = computeMultiWallSweep(
          workingWalls,
          hit.wall.id,
          hit.offsetCm,
          hit.wall.id,
          hit.offsetCm,
          drawBoxKind,
          cornerOwners,
          false
        );

        setCabSweep({
          active: true,
          startWallId: hit.wall.id,
          startOffsetCm: hit.offsetCm,
          hasDragged: false,
          flipOverrides,
          segments: initial.segments,
          suggestedOwners: initial.suggestedOwners,
        });
        return;
      }
    }

    // Select & drag opening in Plan view
    const openSel = targetEl.closest('[data-plan-opening-id]');
    if (openSel) {
      const oId = openSel.getAttribute('data-plan-opening-id');
      const wId = openSel.getAttribute('data-plan-wall-id');
      const w = walls.find((x) => x.id === wId);
      const op = w?.openings?.find((o) => o.id === oId);
      if (w && op) {
        onSelectOpening(w.id, op.id);
        if (tool === 'select') {
          e.currentTarget.setPointerCapture(e.pointerId);
          dragOp.current = {
            mode: 'move-opening',
            wallId: w.id,
            openingId: op.id,
            startPtCm: ptCm,
            origOffsetX: op.offsetX,
          };
        }
        return;
      }
    }

    const boxSel = targetEl.closest('[data-plan-box-id]');
    if (boxSel) {
      const bId = boxSel.getAttribute('data-plan-box-id');
      const wId = boxSel.getAttribute('data-plan-wall-id');
      if (bId && wId) {
        onSelectWall(wId, bId);
        return;
      }
    }

    const wEl = targetEl.closest('[data-wall-click]');
    if (wEl) {
      const wId = wEl.getAttribute('data-wall-click');
      if (wId) {
        const w = walls.find((x) => x.id === wId);
        onSelectWall(wId, w?.boxes[0]?.id ?? null);
        return;
      }
    }

    e.currentTarget.setPointerCapture(e.pointerId);
    dragOp.current = {
      mode: 'pan',
      startX: e.clientX,
      startY: e.clientY,
      origX: pan.x,
      origY: pan.y,
    };
  };

  const handlePointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    const ptCm = clientToCm(e.clientX, e.clientY);

    if (tool === 'wall' && wallDraw.startPt) {
      const snapped = snapWallPoint(ptCm, wallDraw.startPt);
      setWallDraw((prev) => ({
        ...prev,
        currPt: { x: snapped.x, y: snapped.y },
        snappedCorner: snapped.corner,
        lengthCm: prev.startPt
          ? Math.round(Math.hypot(snapped.x - prev.startPt.x, snapped.y - prev.startPt.y))
          : 0,
      }));
      return;
    }

    if (cabSweep.active && cabSweep.startWallId) {
      const hit = projectPointToWalls(ptCm, displayWalls);
      if (hit) {
        const moved =
          cabSweep.hasDragged ||
          hit.wall.id !== cabSweep.startWallId ||
          Math.abs(hit.offsetCm - cabSweep.startOffsetCm) >= 8;

        const computed = computeMultiWallSweep(
          displayWalls,
          cabSweep.startWallId,
          cabSweep.startOffsetCm,
          hit.wall.id,
          hit.offsetCm,
          drawBoxKind,
          cornerOwners,
          moved
        );
        setCabSweep((prev) => ({
          ...prev,
          hasDragged: moved,
          segments: computed.segments,
          suggestedOwners: computed.suggestedOwners,
        }));
      }
      return;
    }

    const op = dragOp.current;
    if (op) {
      if (op.mode === 'pan') {
        setPan({
          x: op.origX + (e.clientX - op.startX),
          y: op.origY + (e.clientY - op.startY),
        });
      } else if (op.mode === 'move-opening') {
        const w = walls.find((x) => x.id === op.wallId);
        if (w) {
          const rad = (w.angle * Math.PI) / 180;
          const deltaProj =
            (ptCm.x - op.startPtCm.x) * Math.cos(rad) +
            (ptCm.y - op.startPtCm.y) * Math.sin(rad);
          onMoveOpening(
            op.wallId,
            op.openingId,
            Math.round((op.origOffsetX + deltaProj) / 5) * 5,
            false
          );
        }
      } else if (op.mode === 'move-node') {
        const snapped = snapWallNodePosition(walls, op.refs, ptCm.x, ptCm.y);
        op.lastX = snapped.x;
        op.lastY = snapped.y;
        onMoveWallNode(op.refs, snapped.x, snapped.y, false);
      }
      return;
    }

    // Hover ghost previews for fridge, appliance, and opening in Plan view
    if (tool === 'fridge' || tool === 'appliance' || tool === 'opening') {
      const hit = projectPointToWalls(ptCm, walls);
      if (hit) {
        const box = hit.wall.boxes.find(
          (b) =>
            b.type === 'base' &&
            hit.offsetCm >= b.offsetX - 5 &&
            hit.offsetCm <= b.offsetX + b.width + 5
        );
        setPlanHoverWall({
          wallId: hit.wall.id,
          offsetCm: hit.offsetCm,
          boxId: box?.id ?? null,
        });
      } else {
        setPlanHoverWall(null);
      }
    } else if (planHoverWall) {
      setPlanHoverWall(null);
    }
  };

  const handlePointerUp = (e: React.PointerEvent<SVGSVGElement>) => {
    if (cabSweep.active) {
      if (e.currentTarget.hasPointerCapture(e.pointerId)) {
        e.currentTarget.releasePointerCapture(e.pointerId);
      }
      const valid = cabSweep.segments.filter((seg) => seg.widthCm >= 30);
      const owners = cabSweep.suggestedOwners;
      const flips = cabSweep.flipOverrides;
      setCabSweep({
        active: false,
        startWallId: null,
        startOffsetCm: 0,
        hasDragged: false,
        flipOverrides: {},
        segments: [],
        suggestedOwners: {},
      });
      if (valid.length) {
        onCreateBoxesFromSweep(valid, drawBoxKind, owners, flips);
      }
      return;
    }

    if (dragOp.current) {
      if (e.currentTarget.hasPointerCapture(e.pointerId)) {
        e.currentTarget.releasePointerCapture(e.pointerId);
      }
      const op = dragOp.current;
      dragOp.current = null;
      if (op.mode === 'move-opening') {
        onMoveOpening(op.wallId, op.openingId, -1, true);
      } else if (op.mode === 'move-node') {
        onMoveWallNode(op.refs, op.lastX, op.lastY, true);
      }
    }
  };

  const handleTouchStart = (e: React.TouchEvent<SVGSVGElement>) => {
    if (e.touches.length === 2) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      touchPinch.current = {
        dist: Math.hypot(dx, dy),
        midX: (e.touches[0].clientX + e.touches[1].clientX) / 2,
        midY: (e.touches[0].clientY + e.touches[1].clientY) / 2,
        origScale: planScale,
        origPan: { ...pan },
      };
    }
  };

  const wheelHandlerRef = useRef<(e: WheelEvent) => void>(() => {});
  const touchMoveHandlerRef = useRef<(e: TouchEvent) => void>(() => {});

  wheelHandlerRef.current = (e: WheelEvent) => {
    e.preventDefault();
    const ptCm = clientToCm(e.clientX, e.clientY);
    const hit = projectPointToWalls(ptCm, walls);
    const dir = e.deltaY < 0 ? 1 : -1;

    if (hit && tool === 'fridge') {
      const idx = FRIDGE_MODEL_ORDER.indexOf(fridgeModel);
      const next = FRIDGE_MODEL_ORDER[(idx + (dir > 0 ? 1 : FRIDGE_MODEL_ORDER.length - 1)) % FRIDGE_MODEL_ORDER.length];
      onFridgeModelChange(next);
      return;
    }
    if (hit && tool === 'appliance') {
      const idx = APPLIANCE_ORDER.indexOf(applianceKind);
      const next = APPLIANCE_ORDER[(idx + (dir > 0 ? 1 : APPLIANCE_ORDER.length - 1)) % APPLIANCE_ORDER.length];
      onApplianceKindChange(next);
      return;
    }
    if (hit && tool === 'opening') {
      const idx = OPENING_ORDER.indexOf(openingKind);
      const next = OPENING_ORDER[(idx + (dir > 0 ? 1 : OPENING_ORDER.length - 1)) % OPENING_ORDER.length];
      onOpeningKindChange(next);
      return;
    }

    setPlanScale((v) =>
      +Math.max(0.3, Math.min(1.8, v + (e.deltaY < 0 ? 0.06 : -0.06))).toFixed(2)
    );
  };

  touchMoveHandlerRef.current = (e: TouchEvent) => {
    if (e.touches.length === 2 && touchPinch.current) {
      e.preventDefault();
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      const dist = Math.hypot(dx, dy);
      const midX = (e.touches[0].clientX + e.touches[1].clientX) / 2;
      const midY = (e.touches[0].clientY + e.touches[1].clientY) / 2;
      const ratio = dist / Math.max(10, touchPinch.current.dist);
      setPlanScale(
        +Math.max(0.3, Math.min(1.8, touchPinch.current.origScale * ratio)).toFixed(2)
      );
      setPan({
        x: touchPinch.current.origPan.x + (midX - touchPinch.current.midX),
        y: touchPinch.current.origPan.y + (midY - touchPinch.current.midY),
      });
    }
  };

  useEffect(() => {
    const svg = svgRef.current;
    if (!svg) return;
    const onWheel = (e: WheelEvent) => wheelHandlerRef.current(e);
    const onTouchMove = (e: TouchEvent) => touchMoveHandlerRef.current(e);
    svg.addEventListener('wheel', onWheel, { passive: false });
    svg.addEventListener('touchmove', onTouchMove, { passive: false });
    return () => {
      svg.removeEventListener('wheel', onWheel);
      svg.removeEventListener('touchmove', onTouchMove);
    };
  }, []);

  const pw = paneRef.current?.clientWidth || 900;
  const ph = paneRef.current?.clientHeight || 240;
  const viewBox = `${-pw / 2 - pan.x} ${-ph / 2 - pan.y} ${pw} ${ph}`;
  const s = planScale;

  const sweepPreviewData = useMemo(() => {
    if (!cabSweep.active || !cabSweep.segments.length) return null;
    const dummyMap = new Map<string, CabinetBox>();
    const tempWalls: Wall[] = displayWalls.map((w) => {
      const segs = cabSweep.segments.filter((seg) => seg.wallId === w.id);
      if (!segs.length) return w;
      const added = segs.map((seg, i) => {
        const d = createEmptyBox(drawBoxKind, seg.startCm, seg.widthCm);
        d.id = `preview_${w.id}_${i}`;
        dummyMap.set(d.id, d);
        return d;
      });
      return { ...w, boxes: [...w.boxes, ...added] };
    });

    const mergedOwners = { ...cornerOwners, ...cabSweep.suggestedOwners };
    const polys: Array<{ key: string; points: Array<{ x: number; y: number }> }> = [];
    for (const tw of tempWalls) {
      for (const b of tw.boxes) {
        if (!dummyMap.has(b.id)) continue;
        const pts = getPlanPolygonForBox(b, tw, tempWalls, mergedOwners);
        if (pts.length >= 3) polys.push({ key: b.id, points: pts });
      }
    }

    const previewBridges = getOutsideCornerBridges(tempWalls, mergedOwners);
    return { polys, previewBridges };
  }, [cabSweep.active, cabSweep.segments, cabSweep.suggestedOwners, displayWalls, drawBoxKind, cornerOwners]);

  return (
    <section
      ref={paneRef}
      className="relative h-full w-full plan-grid overflow-hidden select-none"
      aria-label="نمای پلان دو‌بعدی"
    >
      <div className="absolute top-2 inset-x-2.5 z-15 flex flex-wrap items-center justify-between gap-1.5 pointer-events-none">
        <div className="pointer-events-auto bg-white/95 border border-slate-300 rounded-lg px-2.5 py-1 text-[11px] font-bold text-slate-700 max-w-full sm:max-w-[58%] truncate">
          {hintText}
        </div>

        <div className="pointer-events-auto flex items-center gap-1 mr-auto">
          {tool === 'wall' && wallDraw.startPt && (
            <button
              type="button"
              onClick={() => {
                setWallDraw({ startPt: null, currPt: null, lengthCm: 0, snappedCorner: false });
                onToast('رسم دیوار متوقف شد');
              }}
              className="h-7 px-2.5 rounded-md bg-amber-100 border border-amber-400 text-amber-900 text-[11px] font-bold"
            >
              پایان دیوار
            </button>
          )}
          <button
            type="button"
            onClick={onFlipActiveWallSide}
            className="h-7 px-2 rounded-md bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 text-[11px] font-bold"
          >
            ⇄ چرخش نما
          </button>
          <button
            type="button"
            onClick={() => setPlanScale((v) => +Math.max(0.3, v - 0.1).toFixed(2))}
            aria-label="کوچک‌نمایی پلان"
            className="h-7 w-7 rounded-md bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-bold"
          >
            -
          </button>
          <button
            type="button"
            onClick={() => {
              setPan({ x: 0, y: 0 });
              setPlanScale(0.6);
            }}
            className="h-7 px-2 rounded-md bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 text-[11px] font-bold"
          >
            مرکز
          </button>
          <button
            type="button"
            onClick={() => setPlanScale((v) => +Math.min(1.8, v + 0.1).toFixed(2))}
            aria-label="بزرگ‌نمایی پلان"
            className="h-7 w-7 rounded-md bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-bold"
          >
            +
          </button>
        </div>
      </div>

      {walls.length === 0 && !wallDraw.startPt && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
          <div className="bg-white/95 border border-dashed border-slate-400 rounded-xl px-5 py-3 text-center text-slate-600 text-xs font-bold leading-relaxed">
            صفحه خالی است — ابزار <b>«دیوار»</b> را بزنید یا از بالا چیدمان آماده انتخاب کنید
          </div>
        </div>
      )}

      <svg
        ref={svgRef}
        data-testid="plan-svg"
        viewBox={viewBox}
        className="w-full h-full block touch-none"
        onContextMenu={(e) => {
          e.preventDefault();
          if (wallDraw.startPt) {
            setWallDraw({ startPt: null, currPt: null, lengthCm: 0, snappedCorner: false });
            onToast('رسم دیوار متوقف شد');
          }
        }}
        onTouchStart={handleTouchStart}
        onTouchEnd={() => {
          touchPinch.current = null;
        }}
        onPointerLeave={() => setPlanHoverWall(null)}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
      >
        {outsideBridges
          .filter((br) => !br.isWallCab)
          .map((br) => (
            <polygon
              key={br.key}
              points={br.points.map((p) => `${p.x * s},${p.y * s}`).join(' ')}
              fill="rgba(99,102,241,0.12)"
              stroke="#64748b"
              strokeWidth={1.1}
            />
          ))}

        {/* باکس‌های زمینی/قدی/یخچال */}
        {displayWalls.map((w) => {
          const isAct = w.id === activeWallId;
          return w.boxes
            .filter((b) => b.type !== 'wall' && b.type !== 'wall-deep')
            .map((b) => {
              const pts = getPlanPolygonForBox(b, w, displayWalls, cornerOwners);
              if (pts.length < 3) return null;
              const isBoxAct = isAct && b.id === activeBoxId;
              return (
                <polygon
                  key={b.id}
                  data-plan-box-id={b.id}
                  data-plan-wall-id={w.id}
                  style={{ cursor: tool === 'eraser' ? 'not-allowed' : 'pointer' }}
                  points={pts.map((p) => `${p.x * s},${p.y * s}`).join(' ')}
                  fill={
                    b.type === 'fridge'
                      ? 'rgba(100,116,139,0.22)'
                      : isBoxAct
                      ? 'rgba(79,70,229,0.22)'
                      : 'rgba(99,102,241,0.12)'
                  }
                  stroke={isBoxAct ? '#4f46e5' : '#64748b'}
                  strokeWidth={isBoxAct ? 1.8 : 1.2}
                />
              );
            });
        })}

        {/* باکس‌های هوایی */}
        {displayWalls.map((w) => {
          const isAct = w.id === activeWallId;
          return w.boxes
            .filter((b) => b.type === 'wall' || b.type === 'wall-deep')
            .map((b) => {
              const pts = getPlanPolygonForBox(b, w, displayWalls, cornerOwners);
              if (pts.length < 3) return null;
              const isBoxAct = isAct && b.id === activeBoxId;
              return (
                <polygon
                  key={b.id}
                  data-plan-box-id={b.id}
                  data-plan-wall-id={w.id}
                  style={{ cursor: tool === 'eraser' ? 'not-allowed' : 'pointer' }}
                  points={pts.map((p) => `${p.x * s},${p.y * s}`).join(' ')}
                  fill="rgba(14,165,233,0.12)"
                  stroke="#0284c7"
                  strokeWidth={isBoxAct ? 1.8 : 1.2}
                  strokeDasharray="4,3"
                />
              );
            });
        })}

        {/* دیوارها، بازشوها (پنجره، درب، ستون)، لوازم و برچسب‌ها */}
        {displayWalls.map((w) => {
          const isAct = w.id === activeWallId;
          const wLen = w.length * s;
          const wallThick = 11;
          const flip = w.flipSide || 1;
          const wallY = flip === 1 ? -wallThick : 0;
          const midX = wLen / 2;
          const openings = w.openings || [];

          return (
            <g key={w.id} transform={`translate(${w.x1Cm * s}, ${w.y1Cm * s}) rotate(${w.angle})`}>
              <g style={{ cursor: 'pointer' }} data-wall-click={w.id}>
                <rect
                  x={-5}
                  y={wallY - 7}
                  width={wLen + 10}
                  height={wallThick + 14}
                  fill="transparent"
                />
                <rect
                  x={-5}
                  y={wallY}
                  width={wLen + 10}
                  height={wallThick}
                  fill={isAct ? '#1e293b' : '#94a3b8'}
                  rx={3}
                />
              </g>

              {/* پنجره‌ها، درب‌های اتاق و ستون‌ها روی دیوار */}
              {openings.map((op) => {
                const ox = op.offsetX * s;
                const ow = op.width * s;
                const isOpSel = op.id === selectedOpeningId;

                if (op.kind === 'window') {
                  return (
                    <g
                      key={op.id}
                      data-plan-opening-id={op.id}
                      data-plan-wall-id={w.id}
                      style={{ cursor: tool === 'eraser' ? 'not-allowed' : 'move' }}
                    >
                      <rect
                        x={ox}
                        y={wallY - 1}
                        width={ow}
                        height={wallThick + 2}
                        fill="#e0f2fe"
                        stroke={isOpSel ? '#4f46e5' : '#0284c7'}
                        strokeWidth={isOpSel ? 2 : 1.4}
                      />
                      <line
                        x1={ox + 2}
                        y1={wallY + wallThick / 2}
                        x2={ox + ow - 2}
                        y2={wallY + wallThick / 2}
                        stroke="#0369a1"
                        strokeWidth={1.3}
                      />
                    </g>
                  );
                }

                if (op.kind === 'column') {
                  const cd = 35 * s;
                  const cy = flip === 1 ? 0 : -cd;
                  return (
                    <g
                      key={op.id}
                      data-plan-opening-id={op.id}
                      data-plan-wall-id={w.id}
                      style={{ cursor: tool === 'eraser' ? 'not-allowed' : 'move' }}
                    >
                      <rect
                        x={ox}
                        y={cy}
                        width={ow}
                        height={cd}
                        fill="#475569"
                        stroke={isOpSel ? '#4f46e5' : '#0f172a'}
                        strokeWidth={isOpSel ? 2 : 1.4}
                      />
                      <line x1={ox} y1={cy} x2={ox + ow} y2={cy + cd} stroke="#cbd5e1" strokeWidth={1} />
                      <line x1={ox + ow} y1={cy} x2={ox} y2={cy + cd} stroke="#cbd5e1" strokeWidth={1} />
                    </g>
                  );
                }

                // Doorway with architectural 90° swing arc
                const swing = op.swingDir || 'left-in';
                const inwardSign = flip === 1 ? 1 : -1;
                const swingsOut = swing.endsWith('-out');
                const dirSign = swingsOut ? -inwardSign : inwardSign;
                const hingeLeft = swing.startsWith('left');
                const hx = hingeLeft ? ox : ox + ow;
                const hy = dirSign > 0 ? 0 : wallY;
                const lx = hx;
                const ly = hy + dirSign * ow;
                const ex = hingeLeft ? ox + ow : ox;
                const ey = hy;
                const sweepFlag =
                  (hingeLeft && dirSign > 0) || (!hingeLeft && dirSign < 0) ? 0 : 1;

                return (
                  <g
                    key={op.id}
                    data-plan-opening-id={op.id}
                    data-plan-wall-id={w.id}
                    style={{ cursor: tool === 'eraser' ? 'not-allowed' : 'move' }}
                  >
                    <rect
                      x={ox}
                      y={wallY - 1}
                      width={ow}
                      height={wallThick + 2}
                      fill="#ffffff"
                      stroke={isOpSel ? '#4f46e5' : '#94a3b8'}
                      strokeWidth={isOpSel ? 1.8 : 1}
                    />
                    <line
                      x1={hx}
                      y1={hy}
                      x2={lx}
                      y2={ly}
                      stroke={isOpSel ? '#4f46e5' : '#0f172a'}
                      strokeWidth={2}
                    />
                    <path
                      d={`M ${lx} ${ly} A ${ow} ${ow} 0 0 ${sweepFlag} ${ex} ${ey}`}
                      fill="none"
                      stroke={isOpSel ? '#4f46e5' : '#64748b'}
                      strokeWidth={1.2}
                      strokeDasharray="3,2"
                    />
                  </g>
                );
              })}

              {/* لوازم آشپزخانه روی پلان */}
              {w.appliances.map((app) => {
                const ax = app.offsetX * s;
                const aw = app.width * s;
                const ad = (app.kind === 'dishwasher' || app.kind === 'washing' ? 54 : 46) * s;
                const ay = flip === 1 ? 6 * s : -(ad + 6 * s);
                const fill =
                  app.kind === 'sink'
                    ? '#ccfbf1'
                    : app.kind === 'gas'
                    ? '#1e293b'
                    : '#e0e7ff';
                const stroke =
                  app.kind === 'sink'
                    ? '#0f766e'
                    : app.kind === 'gas'
                    ? '#0f172a'
                    : '#4338ca';
                return (
                  <g
                    key={app.id}
                    data-plan-app-id={app.id}
                    data-plan-wall-id={w.id}
                    style={{ cursor: tool === 'eraser' ? 'not-allowed' : 'pointer' }}
                  >
                    <rect
                      x={ax}
                      y={ay}
                      width={aw}
                      height={ad}
                      rx={3}
                      fill={fill}
                      stroke={stroke}
                      strokeWidth={1.3}
                    />
                    {(app.kind === 'dishwasher' || app.kind === 'washing') && (
                      <text
                        x={ax + aw / 2}
                        y={ay + ad / 2 + 3}
                        fontSize={7.5}
                        fontWeight={800}
                        fill="#312e81"
                        textAnchor="middle"
                        pointerEvents="none"
                      >
                        {app.kind === 'dishwasher' ? 'ظرفشویی' : 'لباسشویی'}
                      </text>
                    )}
                  </g>
                );
              })}

              {/* پیش‌نمایش شبح درج تجهیز/یخچال/پنجره روی این دیوار در پلان */}
              {planHoverWall &&
                planHoverWall.wallId === w.id &&
                (() => {
                  if (tool === 'fridge') {
                    const cfg = FRIDGE_MODELS[fridgeModel];
                    const fx = Math.max(
                      0,
                      Math.min(w.length - cfg.width, planHoverWall.offsetCm - cfg.width / 2)
                    );
                    const fw = cfg.width * s;
                    const fd = cfg.depth * s;
                    const fy = flip === 1 ? 0 : -fd;
                    return (
                      <rect
                        x={fx * s}
                        y={fy}
                        width={fw}
                        height={fd}
                        fill="rgba(79,70,229,0.22)"
                        stroke="#4f46e5"
                        strokeWidth={1.8}
                        strokeDasharray="4,3"
                        pointerEvents="none"
                      />
                    );
                  }
                  if (tool === 'appliance') {
                    const cfg = APPLIANCE_CONFIGS[applianceKind];
                    const ax = Math.max(
                      0,
                      Math.min(w.length - cfg.width, planHoverWall.offsetCm - cfg.width / 2)
                    );
                    const aw = cfg.width * s;
                    const ad = cfg.depth * s;
                    const ay = flip === 1 ? 4 * s : -(ad + 4 * s);
                    return (
                      <rect
                        x={ax * s}
                        y={ay}
                        width={aw}
                        height={ad}
                        rx={3}
                        fill={planHoverWall.boxId ? 'rgba(15,118,110,0.22)' : 'rgba(220,38,38,0.18)'}
                        stroke={planHoverWall.boxId ? '#0f766e' : '#dc2626'}
                        strokeWidth={1.8}
                        strokeDasharray="4,3"
                        pointerEvents="none"
                      />
                    );
                  }
                  if (tool === 'opening') {
                    const def = OPENING_DEFAULTS[openingKind];
                    const ox = Math.max(
                      0,
                      Math.min(w.length - def.width, planHoverWall.offsetCm - def.width / 2)
                    );
                    return (
                      <rect
                        x={ox * s}
                        y={wallY - 2}
                        width={def.width * s}
                        height={wallThick + 4}
                        fill="rgba(2,132,199,0.28)"
                        stroke="#0284c7"
                        strokeWidth={1.8}
                        strokeDasharray="4,2"
                        pointerEvents="none"
                      />
                    );
                  }
                  return null;
                })()}

              {/* فلش و برچسب دیوار بیرون محیط دیوار */}
              <g style={{ cursor: 'pointer' }} data-wall-click={w.id}>
                {(() => {
                  const outSign = flip === 1 ? -1 : 1;
                  const wallOuterEdge = flip === 1 ? -wallThick : wallThick;
                  const isVerticalWall = Math.abs(Math.sin((w.angle * Math.PI) / 180)) > 0.5;
                  const aTipY = wallOuterEdge + outSign * 6;
                  const aBaseY = wallOuterEdge + outSign * 22;
                  const pillY = wallOuterEdge + outSign * (isVerticalWall ? 66 : 34);
                  const arrowHead =
                    outSign === -1
                      ? `-5,${aTipY - 7} 5,${aTipY - 7} 0,${aTipY}`
                      : `-5,${aTipY + 7} 5,${aTipY + 7} 0,${aTipY}`;
                  return (
                    <>
                      <line
                        x1={midX}
                        y1={aBaseY}
                        x2={midX}
                        y2={aTipY}
                        stroke={isAct ? '#ea580c' : '#94a3b8'}
                        strokeWidth={2.2}
                      />
                      <polygon
                        points={arrowHead}
                        transform={`translate(${midX}, 0)`}
                        fill={isAct ? '#ea580c' : '#94a3b8'}
                      />
                      <g transform={`translate(${midX}, ${pillY}) rotate(${-w.angle})`}>
                        <rect
                          x={-54}
                          y={-10}
                          width={108}
                          height={20}
                          rx={6}
                          fill={isAct ? '#4f46e5' : '#ffffff'}
                          stroke={isAct ? '#4f46e5' : '#cbd5e1'}
                          strokeWidth={1.3}
                        />
                        <text
                          x={0}
                          y={3.5}
                          fontSize={9.5}
                          fontWeight={800}
                          fill={isAct ? '#ffffff' : '#334155'}
                          textAnchor="middle"
                        >
                          {w.name}
                        </text>
                      </g>
                    </>
                  );
                })()}
              </g>

              <circle
                cx={0}
                cy={wallY + wallThick / 2}
                r={4.2}
                fill="#ffffff"
                stroke="#1e293b"
                strokeWidth={2}
              />
              <circle
                cx={wLen}
                cy={wallY + wallThick / 2}
                r={4.2}
                fill="#ffffff"
                stroke="#1e293b"
                strokeWidth={2}
              />
            </g>
          );
        })}

        {/* دکمه‌های تعاملی کنج */}
        {inside90Junctions.map((j) => (
          <g
            key={j.key}
            transform={`translate(${j.btnXCm * s}, ${j.btnYCm * s})`}
            data-corner-key={j.key}
            style={{ cursor: 'pointer' }}
          >
            <circle r={10} fill="#fff7ed" stroke="#ea580c" strokeWidth={1.6} />
            <text
              x={0}
              y={3.5}
              fontSize={9.5}
              fontWeight={800}
              fill="#c2410c"
              textAnchor="middle"
            >
              ⇄
            </text>
          </g>
        ))}

        {/* گره‌های هوشمند دیوار (درگ برای تغییر ابعاد و زاویه دیوارها پس از رسم) */}
        {(tool === 'select' || tool === 'wall') &&
          !wallDraw.startPt &&
          smartNodes.map((node) => (
            <g
              key={node.key}
              transform={`translate(${node.xCm * s}, ${node.yCm * s})`}
              data-wall-node={node.key}
              style={{ cursor: 'grab' }}
            >
              <circle r={11} fill="transparent" />
              <circle
                r={5.5}
                fill="#ffffff"
                stroke="#4f46e5"
                strokeWidth={2.2}
              />
              <circle r={2} fill="#4f46e5" />
            </g>
          ))}

        {/* پیش‌نمایش رسم دیوار */}
        {tool === 'wall' && wallDraw.startPt && wallDraw.currPt && (
          <g pointerEvents="none">
            <line
              x1={wallDraw.startPt.x * s}
              y1={wallDraw.startPt.y * s}
              x2={wallDraw.currPt.x * s}
              y2={wallDraw.currPt.y * s}
              stroke="#4f46e5"
              strokeWidth={7}
              strokeLinecap="round"
              opacity={0.7}
            />
            <circle cx={wallDraw.startPt.x * s} cy={wallDraw.startPt.y * s} r={6} fill="#4f46e5" />
            <circle
              cx={wallDraw.currPt.x * s}
              cy={wallDraw.currPt.y * s}
              r={6}
              fill={wallDraw.snappedCorner ? '#16a34a' : '#ea580c'}
            />
            <g
              transform={`translate(${
                ((wallDraw.startPt.x + wallDraw.currPt.x) / 2) * s
              }, ${((wallDraw.startPt.y + wallDraw.currPt.y) / 2) * s - 18})`}
            >
              <rect x={-40} y={-10} width={80} height={20} rx={6} fill="#0f172a" />
              <text
                x={0}
                y={3.5}
                fontSize={10}
                fontWeight={800}
                fill="#ffffff"
                textAnchor="middle"
              >
                {wallDraw.lengthCm} cm
              </text>
            </g>
          </g>
        )}

        {/* پیش‌نمایش زنده کشیدن کابینت */}
        {sweepPreviewData && (
          <g pointerEvents="none">
            {sweepPreviewData.polys.map((poly) => (
              <polygon
                key={poly.key}
                points={poly.points.map((p) => `${p.x * s},${p.y * s}`).join(' ')}
                fill="rgba(79,70,229,0.28)"
                stroke="#4f46e5"
                strokeWidth={2}
                strokeDasharray="5,3"
              />
            ))}
          </g>
        )}
      </svg>
    </section>
  );
};
