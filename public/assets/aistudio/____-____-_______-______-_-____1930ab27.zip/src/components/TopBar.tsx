import React from 'react';
import {
  FilePlus2,
  Lock,
  LockOpen,
  Redo2,
  Settings,
  Undo2,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import { PresetMode } from '../cad/presets';

interface TopBarProps {
  canUndo: boolean;
  canRedo: boolean;
  doorsLocked: boolean;
  onNewProject: () => void;
  onUndo: () => void;
  onRedo: () => void;
  onApplyPreset: (mode: PresetMode) => void;
  onToggleLock: () => void;
  onZoomFront: (delta: number) => void;
  onFitWall: () => void;
  onOpenSettings: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  canUndo,
  canRedo,
  doorsLocked,
  onNewProject,
  onUndo,
  onRedo,
  onApplyPreset,
  onToggleLock,
  onZoomFront,
  onFitWall,
  onOpenSettings,
}) => {
  return (
    <header className="h-12 bg-white border-b border-slate-200 flex items-center justify-between px-3 gap-4 shrink-0 z-30 overflow-x-auto no-scrollbar">
      {/* بخش راست: عنوان و مدیریت پروژه و تاریخچه */}
      <div className="flex items-center gap-2 shrink-0">
        <span className="text-sm font-extrabold text-slate-900 whitespace-nowrap shrink-0 pl-1">
          طراح کابینت
        </span>

        <div className="w-px h-5 bg-slate-200 shrink-0" />

        <button
          type="button"
          onClick={onNewProject}
          aria-label="پروژه جدید"
          className="h-8 px-2.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 active:scale-95 text-slate-800 text-xs font-bold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 transition"
        >
          <FilePlus2 className="w-3.5 h-3.5" />
          <span>جدید</span>
        </button>

        <button
          type="button"
          onClick={onUndo}
          disabled={!canUndo}
          aria-label="بازگشت"
          className="h-8 px-2.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 disabled:opacity-35 disabled:cursor-not-allowed active:scale-95 text-slate-800 text-xs font-bold inline-flex items-center gap-1 whitespace-nowrap shrink-0 transition"
        >
          <Undo2 className="w-3.5 h-3.5" />
          <span>بازگشت</span>
        </button>

        <button
          type="button"
          onClick={onRedo}
          disabled={!canRedo}
          aria-label="تکرار"
          title="تکرار عملیات"
          className="h-8 w-8 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 disabled:opacity-35 disabled:cursor-not-allowed active:scale-95 text-slate-800 inline-flex items-center justify-center shrink-0 transition"
        >
          <Redo2 className="w-3.5 h-3.5" />
        </button>

        <label className="sr-only" htmlFor="preset-selector">
          چیدمان آماده
        </label>
        <select
          id="preset-selector"
          aria-label="چیدمان آماده"
          value=""
          onChange={(e) => {
            const val = e.target.value as PresetMode;
            if (val) onApplyPreset(val);
          }}
          className="h-8 px-2.5 rounded-lg border border-slate-300 bg-slate-50 hover:bg-slate-100 text-slate-800 text-xs font-bold whitespace-nowrap shrink-0 cursor-pointer"
        >
          <option value="" disabled>
            چیدمان آماده ▾
          </option>
          <option value="single">تک‌دیوار</option>
          <option value="L">L-شکل</option>
          <option value="U">U-شکل</option>
          <option value="closet">کمد دیواری</option>
        </select>
      </div>

      {/* بخش چپ: قفل نما، بزرگنمایی نمای روبرو و تنظیمات پروژه */}
      <div className="flex items-center gap-2 shrink-0">
        <button
          type="button"
          onClick={onToggleLock}
          aria-pressed={doorsLocked}
          aria-label={doorsLocked ? 'درب‌ها قفل' : 'درب‌ها باز'}
          className={`h-8 px-3 rounded-lg border text-xs font-bold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 transition active:scale-95 ${
            doorsLocked
              ? 'bg-amber-50 border-amber-400 text-amber-800'
              : 'bg-white border-slate-300 text-slate-800 hover:bg-slate-50'
          }`}
        >
          {doorsLocked ? <Lock className="w-3.5 h-3.5" /> : <LockOpen className="w-3.5 h-3.5" />}
          <span>{doorsLocked ? 'درب‌ها قفل (اسکلت)' : 'درب‌ها باز'}</span>
        </button>

        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={() => onZoomFront(-0.25)}
            aria-label="کوچک‌نمایی نمای روبرو"
            className="h-8 w-8 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 inline-flex items-center justify-center shrink-0"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={onFitWall}
            aria-label="اندازه مناسب نمای روبرو"
            className="h-8 px-2.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold tabular-nums whitespace-nowrap shrink-0"
          >
            Fit
          </button>
          <button
            type="button"
            onClick={() => onZoomFront(0.25)}
            aria-label="بزرگ‌نمایی نمای روبرو"
            className="h-8 w-8 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 inline-flex items-center justify-center shrink-0"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
        </div>

        <button
          type="button"
          onClick={onOpenSettings}
          aria-label="تنظیمات استاندارد پروژه"
          className="h-8 px-3 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 active:scale-95 text-slate-800 text-xs font-bold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 transition"
        >
          <Settings className="w-3.5 h-3.5" />
          <span>تنظیمات</span>
        </button>
      </div>
    </header>
  );
};
