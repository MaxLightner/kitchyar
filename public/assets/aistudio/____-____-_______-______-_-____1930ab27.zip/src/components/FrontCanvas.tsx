import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  APPLIANCE_CONFIGS,
  DRAWER_PATTERNS,
  FRIDGE_MODELS,
  FRIDGE_MODEL_ORDER,
  LIFT_PATTERNS,
  OPENING_DEFAULTS,
  SHEET_MM,
} from '../cad/constants';
import { getCornerBlockedZonesForWall } from '../cad/cornerLogic';
import {
  applyDoorBrushPreview,
  clampBoxInternalsAfterResize,
  computeDoorBrushPreview,
  doesFridgeTouchCabinet,
  eraseDoorWithRule,
  getUnitsInBox,
  resizeDoorSafely,
  resizeDoorSeamCoupled,
  uid,
} from '../cad/doorRules';
import { updateOpeningGeometry } from '../cad/openingRules';
import {
  ApplianceItem,
  ApplianceKind,
  CabinetBox,
  DoorUnit,
  FridgeModel,
  HandleItem,
  HandleStyle,
  MultiSelection,
  OpeningKind,
  Orientation,
  ToolId,
  Wall,
  WallOpening,
} from '../cad/types';

const APPLIANCE_ORDER: ApplianceKind[] = ['sink', 'gas', 'dishwasher', 'washing'];
const OPENING_ORDER: OpeningKind[] = ['window', 'door', 'column'];

interface FrontCanvasProps {
  wall: Wall | null;
  allWalls: Wall[];
  cornerOwners: Record<string, string>;
  activeBoxId: string | null;
  selectedDoorId: string | null;
  selectedOpeningId: string | null;
  multiSelection?: MultiSelection;
  tool: ToolId;
  doorsLocked: boolean;
  doorOrient: Orientation;
  onDoorOrientChange: (o: Orientation) => void;
  doorTargetWidth: number;
  doorVertCount: number;
  onDoorVertCountChange: (c: number) => void;
  drawerPatIdx: number;
  onDrawerPatIdxChange: (i: number) => void;
  liftPatIdx: number;
  onLiftPatIdxChange: (i: number) => void;
  shelfCount: number;
  onShelfCountChange: (c: number) => void;
  handleStyle: HandleStyle;
  handleOrient: Orientation;
  onHandleOrientChange: (o: Orientation) => void;
  fridgeModel: FridgeModel;
  onFridgeModelChange: (m: FridgeModel) => void;
  applianceKind: ApplianceKind;
  onApplianceKindChange: (k: ApplianceKind) => void;
  openingKind: OpeningKind;
  onOpeningKindChange: (k: OpeningKind) => void;
  pxPerCm: number;
  pan: { x: number; y: number };
  onZoomAndPanChange: (nextScale: number, nextPan: { x: number; y: number }) => void;
  onPanChange: (next: { x: number; y: number }) => void;
  onSelectBoxAndDoor: (boxId: string | null, doorId: string | null) => void;
  onSelectOpening: (openingId: string | null) => void;
  onSetMultiSelection: (m?: MultiSelection) => void;
  onBulkDelete?: () => void;
  onMutateWall: (mutator: (wall: Wall) => void, commitHistory?: boolean, toastMsg?: string) => void;
  onPlaceAppliance: (boxId: string, desiredOffsetX: number) => void;
  onPlaceFridge: (desiredOffsetX: number) => void;
  onPlaceOpening: (desiredOffsetX: number, desiredElevY?: number) => void;
  onToast: (msg: string) => void;
}

interface ComputedSpot {
  spotId: string;
  boxId: string;
  doorId: string;
  rowIndex: number;
  xRatio: number;
  yRatio: number;
  x: number;
  y: number;
}

type DragOp =
  | { mode: 'pan'; startX: number; startY: number; origX: number; origY: number }
  | {
      mode: 'marquee';
      startPt: { x: number; y: number };
      currPt: { x: number; y: number };
    }
  | {
      mode: 'resize-box';
      side: 'left' | 'right' | 'top';
      boxId: string;
      startPt: { x: number; y: number };
      origX: number;
      origW: number;
      origH: number;
    }
  | {
      mode: 'move-box';
      boxId: string;
      startPt: { x: number; y: number };
      origX: number;
    }
  | {
      mode: 'resize-door';
      boxId: string;
      doorId: string;
      startPt: { x: number; y: number };
      origW: number;
    }
  | {
      mode: 'resize-door-seam';
      boxId: string;
      leftDoorId: string;
      lastX: number;
    }
  | {
      mode: 'move-app';
      appId: string;
      startPt: { x: number; y: number };
      origX: number;
    }
  | {
      mode: 'stretch-handle';
      boxId: string;
      handleId: string;
      orient: Orientation;
      startPt: { x: number; y: number };
      origLen: number;
    }
  | {
      mode: 'move-opening';
      openingId: string;
      startPt: { x: number; y: number };
      origX: number;
      origElev: number;
    }
  | {
      mode: 'resize-opening';
      openingId: string;
      side: 'left' | 'right' | 'top' | 'bottom';
      startPt: { x: number; y: number };
      origX: number;
      origW: number;
      origElev: number;
      origH: number;
    };

export const FrontCanvas: React.FC<FrontCanvasProps> = ({
  wall,
  allWalls,
  cornerOwners,
  activeBoxId,
  selectedDoorId,
  selectedOpeningId,
  multiSelection,
  tool,
  doorsLocked,
  doorOrient,
  onDoorOrientChange,
  doorTargetWidth,
  doorVertCount,
  onDoorVertCountChange,
  drawerPatIdx,
  onDrawerPatIdxChange,
  liftPatIdx,
  onLiftPatIdxChange,
  shelfCount,
  onShelfCountChange,
  handleStyle,
  handleOrient,
  onHandleOrientChange,
  fridgeModel,
  onFridgeModelChange,
  applianceKind,
  onApplianceKindChange,
  openingKind,
  onOpeningKindChange,
  pxPerCm,
  pan,
  onZoomAndPanChange,
  onPanChange,
  onSelectBoxAndDoor,
  onSelectOpening,
  onSetMultiSelection,
  onBulkDelete,
  onMutateWall,
  onPlaceAppliance,
  onPlaceFridge,
  onPlaceOpening,
  onToast,
}) => {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const paneRef = useRef<HTMLElement | null>(null);

  const [cursorPt, setCursorPt] = useState<{ x: number; y: number } | null>(null);
  const [spaceDown, setSpaceDown] = useState(false);
  const [marquee, setMarquee] = useState<{
    startX: number;
    startY: number;
    currX: number;
    currY: number;
  } | null>(null);

  const [doorHover, setDoorHover] = useState<{
    boxId: string;
    cursorCmInBox: number;
  } | null>(null);

  const [pencilHover, setPencilHover] = useState<{
    boxId: string;
    kind: 'seam' | 'shelf' | 'blocked';
    seamCm?: number;
    startCm?: number;
    endCm?: number;
    yRatio?: number;
    cursorCm?: number;
    blockedReason?: string;
  } | null>(null);

  const dragOp = useRef<DragOp | null>(null);
  const touchPinch = useRef<{
    dist: number;
    midX: number;
    midY: number;
    lastStepY: number;
    origScale: number;
    origPan: { x: number; y: number };
    overContext: boolean;
    contextBox: CabinetBox | null;
    overWallArea: boolean;
  } | null>(null);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' && !(e.target instanceof HTMLInputElement)) {
        setSpaceDown(true);
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'Space') setSpaceDown(false);
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
    };
  }, []);

  const blockedZones = useMemo(() => {
    if (!wall) return [];
    return getCornerBlockedZonesForWall(wall, allWalls, cornerOwners);
  }, [wall, allWalls, cornerOwners]);

  const pw = paneRef.current?.clientWidth || 900;
  const ph = paneRef.current?.clientHeight || 420;
  const viewBox = `${-pw / 2 - pan.x} ${-ph / 2 - pan.y} ${pw} ${ph}`;

  const s = pxPerCm;
  const wallW = (wall?.length || 300) * s;
  const wallH = (wall?.height || 265) * s;
  const originX = -wallW / 2;
  const floorY = wallH / 2 - 14;
  const tPx = (SHEET_MM / 10) * s;

  const clientToSvg = (clientX: number, clientY: number) => {
    const svg = svgRef.current;
    if (!svg) return { x: 0, y: 0 };
    const pt = svg.createSVGPoint();
    pt.x = clientX;
    pt.y = clientY;
    const ctm = svg.getScreenCTM();
    if (!ctm) return { x: 0, y: 0 };
    return pt.matrixTransform(ctm.inverse());
  };

  const hitTestBox = (pt: { x: number; y: number }): {
    box: CabinetBox;
    bx: number;
    by: number;
    bw: number;
    bodyH: number;
  } | null => {
    if (!wall) return null;
    for (let i = wall.boxes.length - 1; i >= 0; i--) {
      const b = wall.boxes[i];
      const bx = originX + b.offsetX * s;
      const bw = b.width * s;
      const bh = b.height * s;
      const by = floorY - b.elevY * s - bh;
      const bodyH = Math.max(14, bh - b.plinth * s);
      if (pt.x >= bx && pt.x <= bx + bw && pt.y >= by && pt.y <= by + bodyH) {
        return { box: b, bx, by, bw, bodyH };
      }
    }
    return null;
  };

  const computedSpots = useMemo<ComputedSpot[]>(() => {
    if (!wall || tool !== 'handle') return [];
    const spots: ComputedSpot[] = [];

    wall.boxes.forEach((box) => {
      const bx = originX + box.offsetX * s;
      const bh = box.height * s;
      const by = floorY - box.elevY * s - bh;
      const bodyH = Math.max(14, bh - box.plinth * s);
      const topPad = box.countertopCm * s;

      box.doors.forEach((door) => {
        if (door.kind === 'fridge' || door.kind === 'open') return;
        const dx = bx + door.startCm * s + 1.5;
        const dw = Math.max(6, door.widthCm * s - 3);
        const dy = by + topPad + 1.5;
        const dh = Math.max(8, bodyH - topPad - 3);

        if (door.kind === 'drawer' || (door.kind === 'lift' && door.drawerRatios.length > 0)) {
          const pts = [0, ...door.drawerRatios, 1];
          for (let r = 0; r < pts.length - 1; r++) {
            const ry = dy + pts[r] * dh;
            const rh = (pts[r + 1] - pts[r]) * dh;
            const rowPts =
              handleOrient === 'horizontal'
                ? [
                    { xr: 0.5, yr: 0.24 },
                    { xr: 0.5, yr: 0.5 },
                    { xr: 0.5, yr: 0.78 },
                  ]
                : [
                    { xr: 0.14, yr: 0.5 },
                    { xr: 0.86, yr: 0.5 },
                  ];
            rowPts.forEach((sp, i) => {
              spots.push({
                spotId: `${door.id}_r${r}_${i}`,
                boxId: box.id,
                doorId: door.id,
                rowIndex: r,
                xRatio: sp.xr,
                yRatio: sp.yr,
                x: dx + dw * sp.xr,
                y: ry + rh * sp.yr,
              });
            });
          }
        } else {
          const doorPts =
            handleOrient === 'vertical'
              ? [
                  { xr: 0.14, yr: 0.18 },
                  { xr: 0.14, yr: 0.5 },
                  { xr: 0.14, yr: 0.82 },
                  { xr: 0.86, yr: 0.18 },
                  { xr: 0.86, yr: 0.5 },
                  { xr: 0.86, yr: 0.82 },
                ]
              : [
                  { xr: 0.5, yr: 0.14 },
                  { xr: 0.5, yr: 0.5 },
                  { xr: 0.5, yr: 0.86 },
                ];
          doorPts.forEach((sp, i) => {
            spots.push({
              spotId: `${door.id}_r0_${i}`,
              boxId: box.id,
              doorId: door.id,
              rowIndex: 0,
              xRatio: sp.xr,
              yRatio: sp.yr,
              x: dx + dw * sp.xr,
              y: dy + dh * sp.yr,
            });
          });
        }
      });
    });
    return spots;
  }, [wall, tool, handleOrient, originX, floorY, s]);

  const doorPreview = useMemo(() => {
    if (!wall || tool !== 'doors' || doorsLocked || !doorHover) return null;
    const box = wall.boxes.find((b) => b.id === doorHover.boxId);
    if (!box) return null;
    return {
      box,
      result: computeDoorBrushPreview(
        box,
        doorHover.cursorCmInBox,
        doorOrient,
        doorVertCount,
        drawerPatIdx,
        liftPatIdx,
        blockedZones,
        doorTargetWidth
      ),
    };
  }, [
    wall,
    tool,
    doorsLocked,
    doorHover,
    doorOrient,
    doorVertCount,
    drawerPatIdx,
    liftPatIdx,
    blockedZones,
    doorTargetWidth,
  ]);

  const countertopSegments = useMemo(() => {
    if (!wall) return [];
    const baseBoxes = wall.boxes
      .filter((b) => b.countertopCm > 0)
      .sort((a, b) => a.offsetX - b.offsetX);
    const segs: Array<{ startCm: number; endCm: number; topElevCm: number; thicknessCm: number }> = [];
    for (const b of baseBoxes) {
      const topElev = b.elevY + b.height;
      const prev = segs[segs.length - 1];
      if (prev && Math.abs(prev.endCm - b.offsetX) <= 2 && prev.topElevCm === topElev) {
        prev.endCm = Math.max(prev.endCm, b.offsetX + b.width);
      } else {
        segs.push({
          startCm: b.offsetX,
          endCm: b.offsetX + b.width,
          topElevCm: topElev,
          thicknessCm: b.countertopCm,
        });
      }
    }
    return segs;
  }, [wall]);

  // Subtle architectural horizontal gap dimensions along base floor line
  const gapDimensions = useMemo(() => {
    if (!wall) return [];
    const intervals: Array<{ start: number; end: number }> = [];
    for (const b of wall.boxes) {
      if (b.type === 'wall' || b.type === 'wall-deep') continue;
      intervals.push({ start: b.offsetX, end: b.offsetX + b.width });
    }
    for (const op of wall.openings || []) {
      if (op.elevY < 90) intervals.push({ start: op.offsetX, end: op.offsetX + op.width });
    }
    for (const z of blockedZones) {
      if (z.tier === 'lower') intervals.push({ start: z.startCm, end: z.endCm });
    }
    if (!intervals.length) return [];
    intervals.sort((a, b) => a.start - b.start);
    const merged: Array<{ start: number; end: number }> = [];
    for (const iv of intervals) {
      if (!merged.length || iv.start > merged[merged.length - 1].end + 0.5) {
        merged.push({ ...iv });
      } else {
        merged[merged.length - 1].end = Math.max(merged[merged.length - 1].end, iv.end);
      }
    }
    const gaps: Array<{ start: number; end: number; len: number }> = [];
    let cur = 0;
    for (const m of merged) {
      if (m.start - cur >= 8) {
        gaps.push({ start: cur, end: m.start, len: Math.round(m.start - cur) });
      }
      cur = Math.max(cur, m.end);
    }
    if (wall.length - cur >= 8) {
      gaps.push({ start: cur, end: wall.length, len: Math.round(wall.length - cur) });
    }
    return gaps;
  }, [wall, blockedZones]);

  const wheelHandlerRef = useRef<(e: WheelEvent) => void>(() => {});
  const touchMoveHandlerRef = useRef<(e: TouchEvent) => void>(() => {});

  const stepToolOption = (
    dir: number,
    contextBox: CabinetBox | null,
    overWallArea: boolean
  ): boolean => {
    if (tool === 'doors' && contextBox && contextBox.type !== 'fridge') {
      if (doorOrient === 'vertical') {
        onDoorVertCountChange(Math.max(1, Math.min(4, doorVertCount + dir)));
      } else if (contextBox.type === 'wall' || contextBox.type === 'wall-deep') {
        onLiftPatIdxChange((liftPatIdx + (dir > 0 ? 1 : LIFT_PATTERNS.length - 1)) % LIFT_PATTERNS.length);
      } else {
        onDrawerPatIdxChange(
          (drawerPatIdx + (dir > 0 ? 1 : DRAWER_PATTERNS.length - 1)) % DRAWER_PATTERNS.length
        );
      }
      return true;
    }
    if (tool === 'appliance' && contextBox && contextBox.type === 'base') {
      const idx = APPLIANCE_ORDER.indexOf(applianceKind);
      onApplianceKindChange(
        APPLIANCE_ORDER[(idx + (dir > 0 ? 1 : APPLIANCE_ORDER.length - 1)) % APPLIANCE_ORDER.length]
      );
      return true;
    }
    if (tool === 'fridge' && overWallArea) {
      const idx = FRIDGE_MODEL_ORDER.indexOf(fridgeModel);
      onFridgeModelChange(
        FRIDGE_MODEL_ORDER[(idx + (dir > 0 ? 1 : FRIDGE_MODEL_ORDER.length - 1)) % FRIDGE_MODEL_ORDER.length]
      );
      return true;
    }
    if (tool === 'opening' && overWallArea) {
      const idx = OPENING_ORDER.indexOf(openingKind);
      onOpeningKindChange(
        OPENING_ORDER[(idx + (dir > 0 ? 1 : OPENING_ORDER.length - 1)) % OPENING_ORDER.length]
      );
      return true;
    }
    if ((tool === 'pencil' || tool === 'skeleton') && contextBox && contextBox.type !== 'fridge') {
      onShelfCountChange(Math.max(1, Math.min(4, shelfCount + dir)));
      return true;
    }
    return false;
  };

  wheelHandlerRef.current = (e: WheelEvent) => {
    e.preventDefault();
    const pt = clientToSvg(e.clientX, e.clientY);
    const boxHit = hitTestBox(pt);
    const overWallArea =
      !!wall && pt.x >= originX && pt.x <= originX + wallW && pt.y >= floorY - wallH && pt.y <= floorY;
    const dir = e.deltaY < 0 ? 1 : -1;

    if (e.shiftKey) {
      if (tool === 'doors') {
        onDoorVertCountChange(Math.max(1, Math.min(4, doorVertCount + dir)));
        return;
      }
      if (tool === 'fridge') {
        stepToolOption(dir, boxHit?.box || null, true);
        return;
      }
    }

    if (stepToolOption(dir, boxHit?.box || null, overWallArea)) {
      return;
    }

    const svg = svgRef.current;
    if (!svg) return;
    const rect = svg.getBoundingClientRect();
    const cx = e.clientX - rect.left - rect.width / 2;
    const cy = e.clientY - rect.top - rect.height / 2;
    const factor = e.deltaY < 0 ? 1.1 : 0.91;
    const nextS = +Math.max(0.6, Math.min(5.2, pxPerCm * factor)).toFixed(2);
    const ratio = nextS / pxPerCm;
    const nextPan = {
      x: Math.round(cx - (cx - pan.x) * ratio),
      y: Math.round(cy - (cy - pan.y) * ratio),
    };
    onZoomAndPanChange(nextS, nextPan);
  };

  const handleTouchStart = (e: React.TouchEvent<SVGSVGElement>) => {
    if (e.touches.length === 2) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      const midX = (e.touches[0].clientX + e.touches[1].clientX) / 2;
      const midY = (e.touches[0].clientY + e.touches[1].clientY) / 2;
      const pt = clientToSvg(midX, midY);
      const boxHit = hitTestBox(pt);
      const overWallArea =
        !!wall && pt.x >= originX && pt.x <= originX + wallW && pt.y >= floorY - wallH && pt.y <= floorY;
      const overContext =
        ((tool === 'doors' || tool === 'pencil' || tool === 'skeleton') &&
          !!boxHit &&
          boxHit.box.type !== 'fridge') ||
        (tool === 'appliance' && boxHit?.box.type === 'base') ||
        ((tool === 'fridge' || tool === 'opening') && overWallArea);

      touchPinch.current = {
        dist: Math.hypot(dx, dy),
        midX,
        midY,
        lastStepY: midY,
        origScale: pxPerCm,
        origPan: { ...pan },
        overContext,
        contextBox: boxHit?.box || null,
        overWallArea,
      };
    }
  };

  touchMoveHandlerRef.current = (e: TouchEvent) => {
    if (e.touches.length === 2 && touchPinch.current) {
      e.preventDefault();
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      const dist = Math.hypot(dx, dy);
      const midX = (e.touches[0].clientX + e.touches[1].clientX) / 2;
      const midY = (e.touches[0].clientY + e.touches[1].clientY) / 2;

      const distDelta = Math.abs(dist - touchPinch.current.dist);
      if (distDelta > 16) {
        const ratio = dist / Math.max(10, touchPinch.current.dist);
        const nextS = +Math.max(0.6, Math.min(5.2, touchPinch.current.origScale * ratio)).toFixed(2);
        onZoomAndPanChange(nextS, {
          x: touchPinch.current.origPan.x + (midX - touchPinch.current.midX),
          y: touchPinch.current.origPan.y + (midY - touchPinch.current.midY),
        });
      } else if (touchPinch.current.overContext) {
        const stepDelta = midY - touchPinch.current.lastStepY;
        if (Math.abs(stepDelta) >= 30) {
          stepToolOption(
            stepDelta < 0 ? 1 : -1,
            touchPinch.current.contextBox,
            touchPinch.current.overWallArea
          );
          touchPinch.current.lastStepY = midY;
        }
      } else {
        onPanChange({
          x: touchPinch.current.origPan.x + (midX - touchPinch.current.midX),
          y: touchPinch.current.origPan.y + (midY - touchPinch.current.midY),
        });
      }
    }
  };

  useEffect(() => {
    const svg = svgRef.current;
    if (!svg) return;
    const onWheel = (e: WheelEvent) => wheelHandlerRef.current(e);
    const onTouchMove = (e: TouchEvent) => touchMoveHandlerRef.current(e);
    svg.addEventListener('wheel', onWheel, { passive: false });
    svg.addEventListener('touchmove', onTouchMove, { passive: false });
    return () => {
      svg.removeEventListener('wheel', onWheel);
      svg.removeEventListener('touchmove', onTouchMove);
    };
  }, []);

  const handlePointerDown = (e: React.PointerEvent<SVGSVGElement>) => {
    if (e.button === 2 || !wall) return;

    // Middle-click or Space + Left-click always pans cleanly in ANY tool!
    if (e.button === 1 || spaceDown) {
      e.preventDefault();
      e.currentTarget.setPointerCapture(e.pointerId);
      dragOp.current = {
        mode: 'pan',
        startX: e.clientX,
        startY: e.clientY,
        origX: pan.x,
        origY: pan.y,
      };
      return;
    }

    const target = e.target as Element;
    const pt = clientToSvg(e.clientX, e.clientY);
    const hit = hitTestBox(pt);

    // 0. Unified Priority Eraser Tool (must run before any resize/select handle checks!)
    if (tool === 'eraser') {
      const handEl = target.closest('[data-handle-id]');
      if (handEl && hit) {
        const hId = handEl.getAttribute('data-handle-id');
        onMutateWall((w) => {
          const b = w.boxes.find((x) => x.id === hit.box.id);
          if (b) b.handles = b.handles.filter((h) => h.id !== hId);
        }, true, 'دستگیره حذف شد');
        return;
      }
      const shelfEl = target.closest('[data-shelf-id]');
      if (shelfEl && hit) {
        const sId = shelfEl.getAttribute('data-shelf-id');
        onMutateWall((w) => {
          const b = w.boxes.find((x) => x.id === hit.box.id);
          if (b) b.shelves = b.shelves.filter((sh) => sh.id !== sId);
        }, true, 'طبقه حذف شد');
        return;
      }
      const unitEl = target.closest('[data-unit-div]');
      if (unitEl && hit) {
        const uCm = Number(unitEl.getAttribute('data-unit-div'));
        onMutateWall((w) => {
          const b = w.boxes.find((x) => x.id === hit.box.id);
          if (b) b.unitDividers = b.unitDividers.filter((u) => u !== uCm);
        }, true, 'دیواره یونیت حذف شد');
        return;
      }
      const openDel = target.closest('[data-opening-id]');
      if (openDel) {
        const oId = openDel.getAttribute('data-opening-id');
        onMutateWall((w) => {
          w.openings = (w.openings || []).filter((o) => o.id !== oId);
        }, true, 'پنجره / درب / ستون حذف شد');
        onSelectOpening(null);
        return;
      }
      const appDel = target.closest('[data-app-id]');
      if (appDel) {
        const aId = appDel.getAttribute('data-app-id');
        onMutateWall((w) => {
          w.appliances = w.appliances.filter((a) => a.id !== aId);
        }, true, 'تجهیز حذف شد');
        return;
      }
      const doorEl = target.closest('[data-door-id]');
      if (doorEl && hit && hit.box.type !== 'fridge') {
        const dId = doorEl.getAttribute('data-door-id')!;
        let msg = '';
        onMutateWall((w) => {
          const b = w.boxes.find((x) => x.id === hit.box.id);
          if (b) msg = eraseDoorWithRule(b, dId);
        }, true);
        if (msg) onToast(msg);
        return;
      }
      if (hit) {
        onMutateWall((w) => {
          w.boxes = w.boxes.filter((x) => x.id !== hit.box.id);
        }, true, 'باکس حذف شد');
        onSelectBoxAndDoor(null, null);
        return;
      }
      return;
    }

    // 1. Interactive Opening Resize Handles
    const openHandleEl = target.closest('[data-opening-handle]');
    if (openHandleEl) {
      const oId = openHandleEl.getAttribute('data-opening-id');
      const side = openHandleEl.getAttribute('data-opening-handle') as 'left' | 'right' | 'top' | 'bottom';
      const op = wall.openings?.find((o) => o.id === oId);
      if (op) {
        e.currentTarget.setPointerCapture(e.pointerId);
        dragOp.current = {
          mode: 'resize-opening',
          openingId: op.id,
          side,
          startPt: pt,
          origX: op.offsetX,
          origW: op.width,
          origElev: op.elevY,
          origH: op.height,
        };
        return;
      }
    }

    // 2. Box resize handles
    const boxHandleEl = target.closest('[data-box-handle]');
    if (boxHandleEl) {
      const bId = boxHandleEl.getAttribute('data-box-id');
      const side = boxHandleEl.getAttribute('data-box-handle') as 'left' | 'right' | 'top';
      const box = wall.boxes.find((b) => b.id === bId);
      if (box) {
        e.currentTarget.setPointerCapture(e.pointerId);
        dragOp.current = {
          mode: 'resize-box',
          side,
          boxId: box.id,
          startPt: pt,
          origX: box.offsetX,
          origW: box.width,
          origH: box.height,
        };
        return;
      }
    }

    // 3a. Coupled door seam resize handle (between touching doors)
    const doorSeamEl = target.closest('[data-door-seam]');
    if (doorSeamEl) {
      const dId = doorSeamEl.getAttribute('data-door-seam');
      const bId = doorSeamEl.getAttribute('data-box-id');
      if (dId && bId) {
        e.currentTarget.setPointerCapture(e.pointerId);
        dragOp.current = {
          mode: 'resize-door-seam',
          boxId: bId,
          leftDoorId: dId,
          lastX: pt.x,
        };
        return;
      }
    }

    // 3b. Standalone door resize handle
    const doorResizeEl = target.closest('[data-door-resize]');
    if (doorResizeEl) {
      const dId = doorResizeEl.getAttribute('data-door-resize');
      const bId = doorResizeEl.getAttribute('data-box-id');
      const box = wall.boxes.find((b) => b.id === bId);
      const door = box?.doors.find((d) => d.id === dId);
      if (box && door) {
        e.currentTarget.setPointerCapture(e.pointerId);
        dragOp.current = {
          mode: 'resize-door',
          boxId: box.id,
          doorId: door.id,
          startPt: pt,
          origW: door.widthCm,
        };
        return;
      }
    }

    // 4. Drag appliance
    const appEl = target.closest('[data-app-id]');
    if (appEl && tool === 'select') {
      const appId = appEl.getAttribute('data-app-id');
      const app = wall.appliances.find((a) => a.id === appId);
      if (app) {
        e.currentTarget.setPointerCapture(e.pointerId);
        dragOp.current = {
          mode: 'move-app',
          appId: app.id,
          startPt: pt,
          origX: app.offsetX,
        };
        return;
      }
    }

    // 4b. Click/Drag Opening in Select mode
    const openEl = target.closest('[data-opening-id]');
    if (openEl && (tool === 'select' || tool === 'opening')) {
      const oId = openEl.getAttribute('data-opening-id');
      const op = wall.openings?.find((o) => o.id === oId);
      if (op) {
        onSelectOpening(op.id);
        e.currentTarget.setPointerCapture(e.pointerId);
        dragOp.current = {
          mode: 'move-opening',
          openingId: op.id,
          startPt: pt,
          origX: op.offsetX,
          origElev: op.elevY,
        };
        return;
      }
    }

    // 5. Handle Tool
    if (tool === 'handle') {
      if (!hit) {
        onHandleOrientChange(handleOrient === 'vertical' ? 'horizontal' : 'vertical');
        onToast(`جهت دستگیره: ${handleOrient === 'vertical' ? 'افقی' : 'عمودی'}`);
        return;
      }

      const handEl = target.closest('[data-handle-id]');
      if (handEl) {
        const hId = handEl.getAttribute('data-handle-id');
        const hObj = hit.box.handles.find((h) => h.id === hId);
        if (hObj) {
          e.currentTarget.setPointerCapture(e.pointerId);
          dragOp.current = {
            mode: 'stretch-handle',
            boxId: hit.box.id,
            handleId: hObj.id,
            orient: hObj.orient,
            startPt: pt,
            origLen: hObj.lengthCm || 16,
          };
          return;
        }
      }

      const spotEl = target.closest('[data-hand-spot]');
      if (spotEl) {
        const sp = computedSpots.find(
          (x) => x.spotId === spotEl.getAttribute('data-hand-spot')
        );
        if (sp) {
          const newH: HandleItem = {
            id: uid('hand'),
            doorId: sp.doorId,
            rowIndex: sp.rowIndex,
            xRatio: sp.xRatio,
            yRatio: sp.yRatio,
            orient: handleOrient,
            style: handleStyle,
            lengthCm: 16,
          };
          onMutateWall((w) => {
            const b = w.boxes.find((x) => x.id === sp.boxId);
            if (!b) return;
            b.handles = b.handles.filter(
              (h) => !(h.doorId === sp.doorId && h.rowIndex === sp.rowIndex)
            );
            b.handles.push(newH);
          }, true);
          e.currentTarget.setPointerCapture(e.pointerId);
          dragOp.current = {
            mode: 'stretch-handle',
            boxId: sp.boxId,
            handleId: newH.id,
            orient: newH.orient,
            startPt: pt,
            origLen: 16,
          };
          return;
        }
      }
      return;
    }

    // 6. Select Mode (click item to select/move, drag empty background for Marquee Box Selection)
    if (tool === 'select') {
      if (hit) {
        const doorEl = target.closest('[data-door-id]');
        const doorId = doorEl?.getAttribute('data-door-id') || hit.box.doors[0]?.id || null;
        onSetMultiSelection(undefined);
        onSelectBoxAndDoor(hit.box.id, doorId);
        e.currentTarget.setPointerCapture(e.pointerId);
        dragOp.current = {
          mode: 'move-box',
          boxId: hit.box.id,
          startPt: pt,
          origX: hit.box.offsetX,
        };
        return;
      }
      onSelectBoxAndDoor(null, null);
      onSelectOpening(null);
      onSetMultiSelection(undefined);
      e.currentTarget.setPointerCapture(e.pointerId);
      setMarquee({ startX: pt.x, startY: pt.y, currX: pt.x, currY: pt.y });
      dragOp.current = {
        mode: 'marquee',
        startPt: pt,
        currPt: pt,
      };
      return;
    }

    // 7. Door Brush Mode (`doors`)
    if (tool === 'doors') {
      if (doorsLocked) {
        onToast('درب‌ها قفل هستند؛ برای تغییر درب قفل را باز کنید');
        return;
      }
      if (!hit) {
        const next = doorOrient === 'vertical' ? 'horizontal' : 'vertical';
        onDoorOrientChange(next);
        onToast(`جهت براش درب: ${next === 'vertical' ? 'عمودی (درب)' : 'افقی (کشو / جک‌دار)'}`);
        return;
      }
      const cursorCm = (pt.x - hit.bx) / s;
      const prev = computeDoorBrushPreview(
        hit.box,
        cursorCm,
        doorOrient,
        doorVertCount,
        drawerPatIdx,
        liftPatIdx,
        blockedZones,
        doorTargetWidth
      );
      if (!prev.ok) {
        onToast(prev.reason || 'امکان درب‌گذاری در این بخش نیست');
        return;
      }
      let newSelDoorId: string | null = null;
      onMutateWall((w) => {
        const b = w.boxes.find((x) => x.id === hit.box.id);
        if (!b) return;
        const res = applyDoorBrushPreview(b, cursorCm, prev);
        newSelDoorId = res.selectedDoorId;
      }, true);
      onSelectBoxAndDoor(hit.box.id, newSelDoorId);
      return;
    }

    // 8. Pencil / Skeleton Mode
    if (tool === 'pencil' || tool === 'skeleton') {
      if (!hit) return;
      onSelectBoxAndDoor(hit.box.id, null);
      const clickCm = (pt.x - hit.bx) / s;

      let nearSeamCm: number | null = null;
      for (const d of hit.box.doors) {
        if (d.startCm > 2 && Math.abs(clickCm - d.startCm) < 8) nearSeamCm = d.startCm;
        const endCm = d.startCm + d.widthCm;
        if (endCm < hit.box.width - 2 && Math.abs(clickCm - endCm) < 8) nearSeamCm = endCm;
      }

      if (nearSeamCm !== null) {
        const seam = +nearSeamCm.toFixed(1);
        if (hit.box.unitDividers.some((u) => Math.abs(u - seam) < 1)) {
          onToast('روی این درز قبلاً دیواره یونیت ثبت شده است');
          return;
        }
        onMutateWall((w) => {
          const b = w.boxes.find((x) => x.id === hit.box.id);
          if (!b) return;
          b.unitDividers.push(seam);
          b.unitDividers.sort((a, c) => a - c);
        }, true, 'دیواره یونیت مستقل (32mm) ثبت شد');
      } else {
        const units = getUnitsInBox(hit.box, blockedZones);
        const targetUnit = units.find(
          (u) => clickCm >= u.startCm - 0.5 && clickCm <= u.endCm + 0.5
        );
        if (!targetUnit) {
          onToast('این بخش در محدوده کنج قرار دارد');
          return;
        }
        if (!targetUnit.canHaveShelves) {
          onToast(targetUnit.blockedReason || 'امکان طبقه‌گذاری در این بخش وجود ندارد');
          return;
        }
        const startCm = targetUnit.startCm;
        const endCm = targetUnit.endCm;

        if (shelfCount === 1) {
          const yRatio = Math.max(
            0.15,
            Math.min(0.85, +((pt.y - hit.by) / hit.bodyH).toFixed(2))
          );
          onMutateWall((w) => {
            const b = w.boxes.find((x) => x.id === hit.box.id);
            if (b) b.shelves.push({ id: uid('sh'), startCm, endCm, yRatio });
          }, true, `طبقه داخلی در یونیت ${Math.round(endCm - startCm)}cm اضافه شد`);
        } else {
          onMutateWall((w) => {
            const b = w.boxes.find((x) => x.id === hit.box.id);
            if (!b) return;
            for (let i = 1; i <= shelfCount; i++) {
              const r = +(i / (shelfCount + 1)).toFixed(2);
              b.shelves.push({ id: uid('sh'), startCm, endCm, yRatio: r });
            }
          }, true, `${shelfCount} طبقه منظم در یونیت اضافه شد`);
        }
      }
      return;
    }

    // 9. Appliance Tool
    if (tool === 'appliance') {
      const clickXCm = (pt.x - originX) / s;
      let targetBase: CabinetBox | undefined = hit && hit.box.type === 'base' ? hit.box : undefined;

      if (!targetBase) {
        const clickedAppEl = target.closest('[data-app-id]');
        const clickedAppId = clickedAppEl?.getAttribute('data-app-id');
        const clickedApp = clickedAppId
          ? wall.appliances.find((a) => a.id === clickedAppId)
          : undefined;
        if (clickedApp) {
          targetBase = wall.boxes.find(
            (b) =>
              b.type === 'base' &&
              clickedApp.offsetX >= b.offsetX - 5 &&
              clickedApp.offsetX + clickedApp.width <= b.offsetX + b.width + 5
          );
        }
      }

      if (!targetBase) {
        targetBase = wall.boxes.find((b) => {
          if (b.type !== 'base') return false;
          const bx = originX + b.offsetX * s;
          const bw = b.width * s;
          const bh = b.height * s;
          const by = floorY - b.elevY * s - bh;
          return pt.x >= bx && pt.x <= bx + bw && pt.y >= by - 36 * s && pt.y <= by + bh;
        });
      }

      if (targetBase) {
        const cfg = APPLIANCE_CONFIGS[applianceKind];
        const desiredOffset = clickXCm - cfg.width / 2;
        onPlaceAppliance(targetBase.id, desiredOffset);
      } else {
        onToast('لطفاً روی یک باکس زمینی کلیک کنید');
      }
      return;
    }

    // 10. Fridge Placement directly in Front view
    if (tool === 'fridge') {
      const cfg = FRIDGE_MODELS[fridgeModel];
      const desiredOffset = (pt.x - originX) / s - cfg.width / 2;
      onPlaceFridge(desiredOffset);
      return;
    }

    // 11. Opening Placement directly in Front view
    if (tool === 'opening') {
      const def = OPENING_DEFAULTS[openingKind];
      const desiredOffset = (pt.x - originX) / s - def.width / 2;
      const desiredElev =
        openingKind === 'window'
          ? Math.max(20, Math.round((floorY - pt.y) / s - def.height / 2))
          : 0;
      onPlaceOpening(desiredOffset, desiredElev);
      return;
    }

    // Fallback pan
    e.currentTarget.setPointerCapture(e.pointerId);
    dragOp.current = {
      mode: 'pan',
      startX: e.clientX,
      startY: e.clientY,
      origX: pan.x,
      origY: pan.y,
    };
  };

  const handlePointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    if (!wall) return;
    const pt = clientToSvg(e.clientX, e.clientY);
    setCursorPt(pt);

    if (!dragOp.current) {
      if (tool === 'doors' && !doorsLocked) {
        const hit = hitTestBox(pt);
        if (hit && hit.box.type !== 'fridge') {
          setDoorHover({
            boxId: hit.box.id,
            cursorCmInBox: (pt.x - hit.bx) / s,
          });
        } else {
          setDoorHover(null);
        }
      } else if (tool === 'pencil' || tool === 'skeleton') {
        const hit = hitTestBox(pt);
        if (hit && hit.box.type !== 'fridge') {
          const clickCm = (pt.x - hit.bx) / s;
          let nearSeamCm: number | null = null;
          for (const d of hit.box.doors) {
            if (d.startCm > 2 && Math.abs(clickCm - d.startCm) < 8) nearSeamCm = d.startCm;
            const endCm = d.startCm + d.widthCm;
            if (endCm < hit.box.width - 2 && Math.abs(clickCm - endCm) < 8) nearSeamCm = endCm;
          }
          if (nearSeamCm !== null) {
            setPencilHover({ boxId: hit.box.id, kind: 'seam', seamCm: +nearSeamCm.toFixed(1) });
          } else {
            const units = getUnitsInBox(hit.box, blockedZones);
            const targetUnit = units.find(
              (u) => clickCm >= u.startCm - 0.5 && clickCm <= u.endCm + 0.5
            );
            if (!targetUnit || !targetUnit.canHaveShelves) {
              setPencilHover({
                boxId: hit.box.id,
                kind: 'blocked',
                cursorCm: clickCm,
                blockedReason: targetUnit?.blockedReason || 'محدوده کنج',
              });
            } else {
              setPencilHover({
                boxId: hit.box.id,
                kind: 'shelf',
                startCm: targetUnit.startCm,
                endCm: targetUnit.endCm,
                yRatio: Math.max(
                  0.15,
                  Math.min(0.85, +((pt.y - hit.by) / hit.bodyH).toFixed(2))
                ),
              });
            }
          }
        } else {
          setPencilHover(null);
        }
      } else {
        if (doorHover) setDoorHover(null);
        if (pencilHover) setPencilHover(null);
      }
      return;
    }

    const op = dragOp.current;
    if (op.mode === 'pan') {
      onPanChange({
        x: op.origX + (e.clientX - op.startX),
        y: op.origY + (e.clientY - op.startY),
      });
    } else if (op.mode === 'marquee') {
      op.currPt = pt;
      setMarquee({ startX: op.startPt.x, startY: op.startPt.y, currX: pt.x, currY: pt.y });
    } else if (op.mode === 'resize-box') {
      const dxCm = Math.round((pt.x - op.startPt.x) / s);
      const dyCm = Math.round((pt.y - op.startPt.y) / s);
      onMutateWall((w) => {
        const b = w.boxes.find((x) => x.id === op.boxId);
        if (!b) return;
        if (op.side === 'right') {
          b.width = Math.max(40, Math.min(w.length - b.offsetX, op.origW + dxCm));
        } else if (op.side === 'left') {
          const newOff = Math.max(0, Math.min(op.origX + op.origW - 40, op.origX + dxCm));
          b.width = op.origW + (op.origX - newOff);
          b.offsetX = newOff;
        } else if (op.side === 'top') {
          b.height = Math.max(40, Math.min(w.height - b.elevY, op.origH - dyCm));
        }
        clampBoxInternalsAfterResize(b);
      }, false);
    } else if (op.mode === 'move-box') {
      const dxCm = Math.round(((pt.x - op.startPt.x) / s) / 5) * 5;
      onMutateWall((w) => {
        const b = w.boxes.find((x) => x.id === op.boxId);
        if (!b) return;
        b.offsetX = Math.max(0, Math.min(w.length - b.width, op.origX + dxCm));
      }, false);
    } else if (op.mode === 'resize-door-seam') {
      const deltaCm = Math.round((pt.x - op.lastX) / s);
      if (Math.abs(deltaCm) >= 1) {
        let applied = 0;
        onMutateWall((w) => {
          const b = w.boxes.find((x) => x.id === op.boxId);
          if (!b) return;
          applied = resizeDoorSeamCoupled(b, op.leftDoorId, deltaCm);
        }, false);
        if (applied !== 0) {
          op.lastX += applied * s;
        }
      }
    } else if (op.mode === 'resize-door') {
      const dxCm = Math.round((pt.x - op.startPt.x) / s);
      onMutateWall((w) => {
        const b = w.boxes.find((x) => x.id === op.boxId);
        if (!b) return;
        resizeDoorSafely(b, op.doorId, op.origW + dxCm, blockedZones);
      }, false);
    } else if (op.mode === 'move-app') {
      const dxCm = Math.round(((pt.x - op.startPt.x) / s) / 5) * 5;
      onMutateWall((w) => {
        const a = w.appliances.find((x) => x.id === op.appId);
        if (!a) return;
        a.offsetX = Math.max(0, Math.min(w.length - a.width, op.origX + dxCm));
      }, false);
    } else if (op.mode === 'stretch-handle') {
      onMutateWall((w) => {
        const b = w.boxes.find((x) => x.id === op.boxId);
        const h = b?.handles.find((x) => x.id === op.handleId);
        if (!b || !h) return;
        const deltaCm =
          op.orient === 'vertical'
            ? ((pt.y - op.startPt.y) / s) * 2
            : ((pt.x - op.startPt.x) / s) * 2;
        const maxLen = op.orient === 'vertical' ? Math.max(16, b.height - 20) : 54;
        h.lengthCm = Math.round(Math.max(8, Math.min(maxLen, op.origLen + deltaCm)));
      }, false);
    } else if (op.mode === 'move-opening') {
      const dxCm = Math.round(((pt.x - op.startPt.x) / s) / 5) * 5;
      const dyCm = Math.round(((op.startPt.y - pt.y) / s) / 5) * 5;
      onMutateWall((w) => {
        const opening = w.openings?.find((o) => o.id === op.openingId);
        if (!opening) return;
        updateOpeningGeometry(opening, w, {
          offsetX: op.origX + dxCm,
          elevY: opening.kind === 'window' ? op.origElev + dyCm : 0,
        });
      }, false);
    } else if (op.mode === 'resize-opening') {
      const dxCm = Math.round((pt.x - op.startPt.x) / s);
      const dyCm = Math.round((op.startPt.y - pt.y) / s);
      onMutateWall((w) => {
        const opening = w.openings?.find((o) => o.id === op.openingId);
        if (!opening) return;
        if (op.side === 'right') {
          updateOpeningGeometry(opening, w, { width: op.origW + dxCm });
        } else if (op.side === 'left') {
          const newX = Math.max(0, Math.min(op.origX + op.origW - 20, op.origX + dxCm));
          updateOpeningGeometry(opening, w, {
            offsetX: newX,
            width: op.origW + (op.origX - newX),
          });
        } else if (op.side === 'top') {
          updateOpeningGeometry(opening, w, { height: op.origH + dyCm });
        } else if (op.side === 'bottom' && opening.kind === 'window') {
          const newElev = Math.max(0, Math.min(op.origElev + op.origH - 40, op.origElev + dyCm));
          updateOpeningGeometry(opening, w, {
            elevY: newElev,
            height: op.origH + (op.origElev - newElev),
          });
        }
      }, false);
    }
  };

  const handlePointerUp = (e: React.PointerEvent<SVGSVGElement>) => {
    if (!dragOp.current) return;
    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
    const op = dragOp.current;
    dragOp.current = null;

    if (op.mode === 'marquee') {
      setMarquee(null);
      if (!wall) return;
      const rx1 = Math.min(op.startPt.x, op.currPt.x);
      const rx2 = Math.max(op.startPt.x, op.currPt.x);
      const ry1 = Math.min(op.startPt.y, op.currPt.y);
      const ry2 = Math.max(op.startPt.y, op.currPt.y);
      if (Math.hypot(rx2 - rx1, ry2 - ry1) < 8) {
        onSetMultiSelection(undefined);
        return;
      }

      const intersects = (x1: number, y1: number, x2: number, y2: number) =>
        x1 <= rx2 && x2 >= rx1 && y1 <= ry2 && y2 >= ry1;

      const boxIds: string[] = [];
      const doorIds: string[] = [];
      const openingIds: string[] = [];
      const applianceIds: string[] = [];

      for (const b of wall.boxes) {
        const bx = originX + b.offsetX * s;
        const bw = b.width * s;
        const bh = b.height * s;
        const by = floorY - b.elevY * s - bh;
        const bodyH = Math.max(14, bh - b.plinth * s);
        const topPad = b.countertopCm * s;

        if (intersects(bx, by, bx + bw, by + bh)) {
          const overlapW = Math.min(rx2, bx + bw) - Math.max(rx1, bx);
          if (overlapW >= bw * 0.72 || b.doors.length === 0) {
            boxIds.push(b.id);
          }
        }
        for (const d of b.doors) {
          const dx = bx + d.startCm * s;
          const dw = d.widthCm * s;
          const dy = by + topPad;
          const dh = Math.max(8, bodyH - topPad);
          if (intersects(dx, dy, dx + dw, dy + dh)) {
            doorIds.push(d.id);
          }
        }
      }

      for (const opItem of wall.openings || []) {
        const ox = originX + opItem.offsetX * s;
        const ow = opItem.width * s;
        const oh = opItem.height * s;
        const oy = floorY - opItem.elevY * s - oh;
        if (intersects(ox, oy, ox + ow, oy + oh)) {
          openingIds.push(opItem.id);
        }
      }

      for (const app of wall.appliances) {
        const ax = originX + app.offsetX * s;
        const aw = app.width * s;
        const ay = floorY - 92 * s;
        const ah = 86 * s;
        if (intersects(ax, ay, ax + aw, ay + ah)) {
          applianceIds.push(app.id);
        }
      }

      const total = boxIds.length + doorIds.length + openingIds.length + applianceIds.length;
      if (total > 0) {
        onSetMultiSelection({ boxIds, doorIds, openingIds, applianceIds });
      } else {
        onSetMultiSelection(undefined);
      }
      return;
    }

    if (op.mode !== 'pan') {
      onMutateWall(() => {}, true);
    }
  };

  const renderDoorUnit = (box: CabinetBox, door: DoorUnit, bx: number, by: number, bodyH: number) => {
    const topPad = box.countertopCm * s;
    const dx = bx + door.startCm * s + 1.5;
    const dw = Math.max(6, door.widthCm * s - 3);
    const dy = by + topPad + 1.5;
    const dh = Math.max(8, bodyH - topPad - 3);
    const isDoorSel =
      door.id === selectedDoorId || Boolean(multiSelection?.doorIds.includes(door.id));
    const opacity = doorsLocked ? 0.42 : 0.96;
    const hasTouchingRightNeighbor = box.doors.some(
      (other) =>
        other.id !== door.id &&
        other.kind !== 'fridge' &&
        Math.abs(other.startCm - (door.startCm + door.widthCm)) <= 1.5
    );

    return (
      <g key={door.id} opacity={opacity} data-door-id={door.id} data-box-id={box.id}>
        {door.kind === 'fridge' ? (
          (() => {
            const fm = box.fridgeModel || (door.widthCm >= 110 ? 'twin' : door.widthCm <= 78 ? 'single' : 'side-by-side');
            if (fm === 'single') {
              return (
                <>
                  <rect x={dx} y={dy} width={dw} height={dh} rx={3} fill="#cbd5e1" stroke="#475569" strokeWidth={1.5} />
                  <line x1={dx} y1={dy + dh * 0.68} x2={dx + dw} y2={dy + dh * 0.68} stroke="#64748b" strokeWidth={1.3} />
                  <line x1={dx + 8} y1={dy + dh * 0.48} x2={dx + 8} y2={dy + dh * 0.62} stroke="#334155" strokeWidth={2.2} strokeLinecap="round" />
                  <text x={dx + dw / 2} y={dy + dh * 0.34} fontSize={9.5} fontWeight={800} fill="#334155" textAnchor="middle" pointerEvents="none">
                    یخچال ({Math.round(door.widthCm)})
                  </text>
                </>
              );
            }
            if (fm === 'twin') {
              return (
                <>
                  <rect x={dx} y={dy} width={dw / 2 - 1} height={dh} rx={3} fill="#cbd5e1" stroke="#475569" strokeWidth={1.5} />
                  <rect x={dx + dw / 2 + 1} y={dy} width={dw / 2 - 1} height={dh} rx={3} fill="#cbd5e1" stroke="#475569" strokeWidth={1.5} />
                  <line x1={dx + dw / 2 - 8} y1={dy + dh * 0.32} x2={dx + dw / 2 - 8} y2={dy + dh * 0.56} stroke="#334155" strokeWidth={2.2} strokeLinecap="round" />
                  <line x1={dx + dw / 2 + 8} y1={dy + dh * 0.32} x2={dx + dw / 2 + 8} y2={dy + dh * 0.56} stroke="#334155" strokeWidth={2.2} strokeLinecap="round" />
                  <text x={dx + dw / 2} y={dy + dh * 0.22} fontSize={9.5} fontWeight={800} fill="#334155" textAnchor="middle" pointerEvents="none">
                    دوقلو ({Math.round(door.widthCm)})
                  </text>
                </>
              );
            }
            // side-by-side
            return (
              <>
                <rect x={dx} y={dy} width={dw} height={dh} rx={3} fill="#cbd5e1" stroke="#475569" strokeWidth={1.5} />
                <line x1={dx + dw / 2} y1={dy} x2={dx + dw / 2} y2={dy + dh} stroke="#64748b" strokeWidth={1.4} />
                <rect x={dx + dw * 0.14} y={dy + dh * 0.32} width={dw * 0.22} height={dh * 0.22} rx={2} fill="#334155" />
                <text x={dx + dw / 2} y={dy + dh * 0.2} fontSize={9.5} fontWeight={800} fill="#334155" textAnchor="middle" pointerEvents="none">
                  ساید ({Math.round(door.widthCm)})
                </text>
              </>
            );
          })()
        ) : door.kind === 'open' ? (
          <>
            <rect
              x={dx}
              y={dy}
              width={dw}
              height={dh}
              rx={2}
              fill="rgba(241,245,249,0.55)"
              stroke={isDoorSel ? '#4f46e5' : '#94a3b8'}
              strokeDasharray="3,2"
            />
            <text
              x={dx + dw / 2}
              y={dy + dh / 2}
              fontSize={9}
              fontWeight={700}
              fill="#64748b"
              textAnchor="middle"
              pointerEvents="none"
            >
              قفسه باز
            </text>
          </>
        ) : door.kind === 'rail' ? (
          <>
            <rect
              x={dx}
              y={dy}
              width={dw}
              height={dh}
              rx={2}
              fill="#e2e8f0"
              stroke={isDoorSel ? '#4f46e5' : '#64748b'}
              strokeWidth={isDoorSel ? 1.8 : 1.3}
            />
            <line x1={dx + 5} y1={dy + 22} x2={dx + dw - 5} y2={dy + 22} stroke="#334155" strokeWidth={2.6} />
            <path d={`M ${dx + dw / 2} ${dy + 22} v 6 l -7 6 h 14 l -7 -6`} fill="none" stroke="#475569" strokeWidth={1.4} />
          </>
        ) : door.kind === 'oven' ? (
          <>
            <rect
              x={dx}
              y={dy}
              width={dw}
              height={dh}
              rx={2.5}
              fill="#e2e8f0"
              stroke={isDoorSel ? '#4f46e5' : '#64748b'}
              strokeWidth={isDoorSel ? 1.8 : 1.3}
            />
            <rect
              x={dx + 5}
              y={dy + dh * 0.34}
              width={Math.max(10, dw - 10)}
              height={Math.min(dh * 0.38, 62)}
              rx={3}
              fill="#1e293b"
            />
            <rect
              x={dx + 10}
              y={dy + dh * 0.34 + 10}
              width={Math.max(6, dw - 20)}
              height={Math.max(10, Math.min(dh * 0.38, 62) - 18)}
              rx={2}
              fill="#334155"
            />
          </>
        ) : door.kind === 'drawer' ? (
          (() => {
            const pts = [0, ...(door.drawerRatios.length ? door.drawerRatios : [0.333, 0.667]), 1];
            return (
              <>
                {pts.slice(0, -1).map((r, i) => {
                  const sy = dy + r * dh + 1;
                  const sh = Math.max(6, (pts[i + 1] - r) * dh - 2);
                  return (
                    <rect
                      key={i}
                      x={dx}
                      y={sy}
                      width={dw}
                      height={sh}
                      rx={2}
                      fill="#dbe3ee"
                      stroke={isDoorSel ? '#4f46e5' : '#64748b'}
                      strokeWidth={isDoorSel ? 1.8 : 1.3}
                    />
                  );
                })}
                <text
                  x={dx + dw / 2}
                  y={dy + dh - 5}
                  fontSize={8.5}
                  fontWeight={800}
                  fill="#475569"
                  textAnchor="middle"
                  pointerEvents="none"
                >
                  کشو ({Math.round(door.widthCm)})
                </text>
              </>
            );
          })()
        ) : door.kind === 'lift' ? (
          (() => {
            const pts = [0, ...door.drawerRatios, 1];
            return (
              <>
                {pts.slice(0, -1).map((r, i) => {
                  const sy = dy + r * dh + 1;
                  const sh = Math.max(6, (pts[i + 1] - r) * dh - 2);
                  return (
                    <g key={i}>
                      <rect
                        x={dx}
                        y={sy}
                        width={dw}
                        height={sh}
                        rx={2}
                        fill="#e0f2fe"
                        stroke={isDoorSel ? '#4f46e5' : '#0284c7'}
                        strokeWidth={isDoorSel ? 1.8 : 1.3}
                      />
                      <line
                        x1={dx + dw * 0.35}
                        y1={sy + sh - 5}
                        x2={dx + dw * 0.65}
                        y2={sy + sh - 5}
                        stroke="#0369a1"
                        strokeWidth={1.6}
                      />
                    </g>
                  );
                })}
                <text
                  x={dx + dw / 2}
                  y={dy + 13}
                  fontSize={8.5}
                  fontWeight={800}
                  fill="#0369a1"
                  textAnchor="middle"
                  pointerEvents="none"
                >
                  افقی {Math.round(door.widthCm)}
                </text>
              </>
            );
          })()
        ) : (
          <>
            <rect
              x={dx}
              y={dy}
              width={dw}
              height={dh}
              rx={2.5}
              fill="#e2e8f0"
              stroke={isDoorSel ? '#4f46e5' : '#64748b'}
              strokeWidth={isDoorSel ? 1.8 : 1.3}
            />
            <text
              x={dx + dw / 2}
              y={dy + dh / 2 + 3.5}
              fontSize={9.5}
              fontWeight={800}
              fill="#334155"
              textAnchor="middle"
              pointerEvents="none"
            >
              {Math.round(door.widthCm)} cm
            </text>
          </>
        )}

        {!doorsLocked &&
          tool === 'select' &&
          door.kind !== 'fridge' &&
          (hasTouchingRightNeighbor ? (
            <rect
              x={dx + dw - 3.5}
              y={dy + dh / 2 - 14}
              width={7}
              height={28}
              rx={3.5}
              fill="#059669"
              stroke="#ffffff"
              strokeWidth={1.3}
              style={{ cursor: 'col-resize' }}
              data-door-seam={door.id}
              data-box-id={box.id}
            />
          ) : (
            <rect
              x={dx + dw - 3.5}
              y={dy + dh / 2 - 12}
              width={7}
              height={24}
              rx={3.5}
              fill="#4f46e5"
              stroke="#ffffff"
              strokeWidth={1.2}
              style={{ cursor: 'ew-resize' }}
              data-door-resize={door.id}
              data-box-id={box.id}
            />
          ))}
      </g>
    );
  };

  return (
    <section
      ref={paneRef}
      className="relative flex-1 min-h-[200px] front-grid overflow-hidden select-none"
      aria-label="نمای روبرو"
    >
      {/* عنوان دیوار بدون شلوغی */}
      <div className="absolute top-2 right-2.5 z-15 bg-white/95 border border-slate-300 rounded-lg px-2.5 py-1 text-xs font-extrabold text-slate-800 tabular-nums pointer-events-none max-w-[calc(100%-20px)] truncate">
        {wall
          ? `${wall.name} — طول ${wall.length} cm · ارتفاع ${wall.height} cm · زوم ${Math.round(
              (pxPerCm / 2.1) * 100
            )}٪`
          : 'دیواری انتخاب نشده'}
      </div>

      {multiSelection &&
        multiSelection.boxIds.length +
          multiSelection.doorIds.length +
          multiSelection.openingIds.length +
          multiSelection.applianceIds.length >
          0 && (
          <div className="absolute bottom-2.5 left-1/2 -translate-x-1/2 z-20 flex items-center gap-2 bg-slate-900/95 text-white px-3 py-1.5 rounded-xl shadow-lg text-xs font-bold">
            <span>
              انتخاب گروهی:{' '}
              {multiSelection.boxIds.length +
                multiSelection.doorIds.length +
                multiSelection.openingIds.length +
                multiSelection.applianceIds.length}{' '}
              مورد
            </span>
            {onBulkDelete && (
              <button
                type="button"
                onClick={onBulkDelete}
                className="px-2.5 py-1 rounded-lg bg-red-600 hover:bg-red-500 text-white font-extrabold"
              >
                حذف یکجا
              </button>
            )}
            <button
              type="button"
              onClick={() => onSetMultiSelection(undefined)}
              className="px-2 py-1 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-100"
            >
              لغو
            </button>
          </div>
        )}

      {wall && wall.boxes.length === 0 && (wall.openings || []).length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
          <div className="bg-white/95 border border-dashed border-slate-400 rounded-xl px-5 py-3 text-center text-slate-600 text-xs font-bold">
            روی این دیوار باکسی نیست — از پایین ابزار <b>«باکس کابینت»</b> یا <b>«یخچال / پنجره»</b> را بزنید
          </div>
        </div>
      )}

      <svg
        ref={svgRef}
        data-testid="front-svg"
        viewBox={viewBox}
        className="w-full h-full block touch-none"
        style={{ cursor: spaceDown ? 'grab' : tool === 'eraser' ? 'not-allowed' : undefined }}
        onContextMenu={(e) => e.preventDefault()}
        onTouchStart={handleTouchStart}
        onTouchEnd={() => {
          touchPinch.current = null;
        }}
        onPointerLeave={() => {
          setDoorHover(null);
          setPencilHover(null);
          setCursorPt(null);
        }}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
      >
        <defs>
          <pattern
            id="corner-hatch"
            width="8"
            height="8"
            patternTransform="rotate(45 0 0)"
            patternUnits="userSpaceOnUse"
          >
            <line x1="0" y1="0" x2="0" y2="8" stroke="#dc2626" strokeWidth="1.4" opacity="0.45" />
          </pattern>
          <pattern
            id="column-hatch"
            width="8"
            height="8"
            patternTransform="rotate(45 0 0)"
            patternUnits="userSpaceOnUse"
          >
            <line x1="0" y1="0" x2="0" y2="8" stroke="#475569" strokeWidth="1.8" opacity="0.45" />
          </pattern>
        </defs>

        {wall && (
          <>
            {/* دیوار پس‌زمینه و خط کف */}
            <rect
              x={originX}
              y={floorY - wallH}
              width={wallW}
              height={wallH}
              fill="#ffffff"
              fillOpacity={0.78}
              stroke="#cbd5e1"
              strokeWidth={1.5}
              strokeDasharray="6,4"
            />
            <line
              x1={originX - 24}
              y1={floorY}
              x2={originX + wallW + 24}
              y2={floorY}
              stroke="#334155"
              strokeWidth={2.5}
            />

            {/* پنجره‌ها، درب‌های اتاق و ستون‌ها در نمای روبرو */}
            {(wall.openings || []).map((op: WallOpening) => {
              const ox = originX + op.offsetX * s;
              const ow = op.width * s;
              const oh = op.height * s;
              const oy = floorY - op.elevY * s - oh;
              const isSel =
                op.id === selectedOpeningId || Boolean(multiSelection?.openingIds.includes(op.id));

              return (
                <g
                  key={op.id}
                  data-opening-id={op.id}
                  style={{ cursor: tool === 'eraser' ? 'not-allowed' : 'move' }}
                >
                  {op.kind === 'window' ? (
                    <>
                      <rect
                        x={ox}
                        y={oy}
                        width={ow}
                        height={oh}
                        fill="#e0f2fe"
                        fillOpacity={0.75}
                        stroke={isSel ? '#4f46e5' : '#0284c7'}
                        strokeWidth={isSel ? 2.4 : 1.8}
                      />
                      <rect
                        x={ox + 5}
                        y={oy + 5}
                        width={Math.max(4, ow - 10)}
                        height={Math.max(4, oh - 10)}
                        fill="none"
                        stroke="#7dd3fc"
                        strokeWidth={1.2}
                      />
                      <line
                        x1={ox + ow / 2}
                        y1={oy + 5}
                        x2={ox + ow / 2}
                        y2={oy + oh - 5}
                        stroke="#0284c7"
                        strokeWidth={1.3}
                      />
                      <text
                        x={ox + ow / 2}
                        y={oy + oh / 2 + 3}
                        fontSize={9.5}
                        fontWeight={800}
                        fill="#0369a1"
                        textAnchor="middle"
                        pointerEvents="none"
                      >
                        پنجره {op.width}×{op.height} (کف {op.elevY})
                      </text>
                    </>
                  ) : op.kind === 'column' ? (
                    <>
                      <rect
                        x={ox}
                        y={oy}
                        width={ow}
                        height={oh}
                        fill="url(#column-hatch)"
                        stroke={isSel ? '#4f46e5' : '#334155'}
                        strokeWidth={isSel ? 2.4 : 1.8}
                      />
                      <text
                        x={ox + ow / 2}
                        y={oy + oh / 2}
                        fontSize={9.5}
                        fontWeight={800}
                        fill="#0f172a"
                        textAnchor="middle"
                        pointerEvents="none"
                      >
                        ستون {op.width}
                      </text>
                    </>
                  ) : (
                    <>
                      <rect
                        x={ox}
                        y={oy}
                        width={ow}
                        height={oh}
                        fill="#f1f5f9"
                        stroke={isSel ? '#4f46e5' : '#475569'}
                        strokeWidth={isSel ? 2.4 : 1.8}
                      />
                      <rect
                        x={ox + 5}
                        y={oy + 5}
                        width={Math.max(6, ow - 10)}
                        height={Math.max(6, oh - 5)}
                        fill="#e2e8f0"
                        stroke="#94a3b8"
                        strokeWidth={1}
                      />
                      <circle
                        cx={op.swingDir?.startsWith('left') ? ox + ow - 12 : ox + 12}
                        cy={oy + oh * 0.54}
                        r={3}
                        fill="#334155"
                      />
                      <text
                        x={ox + ow / 2}
                        y={oy + 22}
                        fontSize={9.5}
                        fontWeight={800}
                        fill="#334155"
                        textAnchor="middle"
                        pointerEvents="none"
                      >
                        درب {op.width}×{op.height}
                      </text>
                    </>
                  )}

                  {/* دستگیره‌های تغییر اندازه تعاملی پنجره / درب / ستون */}
                  {(isSel || tool === 'select' || tool === 'opening') && (
                    <>
                      <rect
                        x={ox - 4}
                        y={oy + oh / 2 - 12}
                        width={8}
                        height={24}
                        rx={4}
                        fill="#0284c7"
                        stroke="#ffffff"
                        strokeWidth={1.3}
                        style={{ cursor: 'ew-resize' }}
                        data-opening-handle="left"
                        data-opening-id={op.id}
                      />
                      <rect
                        x={ox + ow - 4}
                        y={oy + oh / 2 - 12}
                        width={8}
                        height={24}
                        rx={4}
                        fill="#0284c7"
                        stroke="#ffffff"
                        strokeWidth={1.3}
                        style={{ cursor: 'ew-resize' }}
                        data-opening-handle="right"
                        data-opening-id={op.id}
                      />
                      {op.kind !== 'column' && (
                        <rect
                          x={ox + ow / 2 - 12}
                          y={oy - 4}
                          width={24}
                          height={8}
                          rx={4}
                          fill="#0284c7"
                          stroke="#ffffff"
                          strokeWidth={1.3}
                          style={{ cursor: 'ns-resize' }}
                          data-opening-handle="top"
                          data-opening-id={op.id}
                        />
                      )}
                      {op.kind === 'window' && (
                        <rect
                          x={ox + ow / 2 - 12}
                          y={oy + oh - 4}
                          width={24}
                          height={8}
                          rx={4}
                          fill="#0284c7"
                          stroke="#ffffff"
                          strokeWidth={1.3}
                          style={{ cursor: 'ns-resize' }}
                          data-opening-handle="bottom"
                          data-opening-id={op.id}
                        />
                      )}
                    </>
                  )}
                </g>
              );
            })}

            {/* باکس‌های کابینت */}
            {wall.boxes.map((box) => {
              const isAct =
                box.id === activeBoxId || Boolean(multiSelection?.boxIds.includes(box.id));
              const bx = originX + box.offsetX * s;
              const bw = box.width * s;
              const bh = box.height * s;
              const by = floorY - box.elevY * s - bh;
              const plinthPx = box.plinth * s;
              const bodyH = Math.max(14, bh - plinthPx);
              const topPad = box.countertopCm * s;
              const fridgeFrame =
                box.type === 'fridge' && (box.hasFridgeFrame || doesFridgeTouchCabinet(wall, box));

              return (
                <g key={box.id} data-box-id={box.id}>
                  <rect
                    x={bx}
                    y={by}
                    width={bw}
                    height={bodyH}
                    rx={2}
                    fill={box.type === 'wall-deep' ? '#f8fafc' : '#ffffff'}
                    stroke={isAct ? '#4f46e5' : box.type === 'wall-deep' ? '#0284c7' : '#64748b'}
                    strokeWidth={isAct ? 2.2 : 1.5}
                  />

                  {fridgeFrame && (
                    <>
                      <rect x={bx} y={by} width={Math.max(3, 2 * s)} height={bodyH} fill="#64748b" />
                      <rect
                        x={bx + bw - Math.max(3, 2 * s)}
                        y={by}
                        width={Math.max(3, 2 * s)}
                        height={bodyH}
                        fill="#64748b"
                      />
                    </>
                  )}

                  {plinthPx > 0 && (
                    <rect
                      x={bx + 2}
                      y={by + bodyH}
                      width={Math.max(4, bw - 4)}
                      height={plinthPx}
                      fill="#cbd5e1"
                      stroke="#94a3b8"
                      strokeWidth={1}
                    />
                  )}

                  {box.doors.map((door) => renderDoorUnit(box, door, bx, by, bodyH))}

                  {box.unitDividers.map((uCm) => {
                    const ux = bx + uCm * s;
                    return (
                      <g key={uCm} data-unit-div={uCm} data-box-id={box.id}>
                        <rect
                          x={ux - tPx}
                          y={by + topPad}
                          width={tPx * 2}
                          height={bodyH - topPad}
                          fill="#ede9fe"
                          stroke="#7c3aed"
                          strokeWidth={1.4}
                        />
                        <line
                          x1={ux}
                          y1={by + topPad}
                          x2={ux}
                          y2={by + bodyH}
                          stroke="#7c3aed"
                          strokeWidth={1.2}
                        />
                      </g>
                    );
                  })}

                  {box.shelves.map((sh) => {
                    const sx = bx + sh.startCm * s + tPx;
                    const sw = Math.max(6, (sh.endCm - sh.startCm) * s - tPx * 2);
                    const sy = by + topPad + (bodyH - topPad) * sh.yRatio;
                    return (
                      <g key={sh.id} data-shelf-id={sh.id} data-box-id={box.id}>
                        <rect
                          x={sx}
                          y={sy - tPx / 2}
                          width={sw}
                          height={tPx}
                          fill="#fef3c7"
                          stroke="#d97706"
                          strokeWidth={1.2}
                        />
                      </g>
                    );
                  })}

                  {box.handles.map((h) => {
                    const door = box.doors.find((d) => d.id === h.doorId);
                    if (!door) return null;
                    const dx = bx + door.startCm * s + 1.5;
                    const dw = Math.max(6, door.widthCm * s - 3);
                    const dy = by + topPad + 1.5;
                    const dh = Math.max(8, bodyH - topPad - 3);

                    let rowY = dy;
                    let rowH = dh;
                    if (
                      door.kind === 'drawer' ||
                      (door.kind === 'lift' && door.drawerRatios.length > 0)
                    ) {
                      const pts = [0, ...door.drawerRatios, 1];
                      const r = Math.min(pts.length - 2, Math.max(0, h.rowIndex));
                      rowY = dy + pts[r] * dh;
                      rowH = (pts[r + 1] - pts[r]) * dh;
                    }

                    const cx = dx + dw * h.xRatio;
                    const cy = rowY + rowH * h.yRatio;
                    const lenPx = (h.lengthCm || 16) * s;

                    return (
                      <g
                        key={h.id}
                        style={{ cursor: 'pointer' }}
                        data-handle-id={h.id}
                        data-box-id={box.id}
                      >
                        {h.style === 'knob' ? (
                          <circle cx={cx} cy={cy} r={4.5} fill="#0f172a" stroke="#ffffff" strokeWidth={1.2} />
                        ) : h.style === 'hidden' ? (
                          h.orient === 'vertical' ? (
                            <line x1={cx} y1={rowY + 3} x2={cx} y2={rowY + rowH - 3} stroke="#0f172a" strokeWidth={3} strokeDasharray="4,2" />
                          ) : (
                            <line x1={dx + 3} y1={cy} x2={dx + dw - 3} y2={cy} stroke="#0f172a" strokeWidth={3} strokeDasharray="4,2" />
                          )
                        ) : h.orient === 'vertical' ? (
                          <rect x={cx - 2} y={cy - lenPx / 2} width={4} height={lenPx} rx={2} fill="#0f172a" />
                        ) : (
                          <rect x={cx - lenPx / 2} y={cy - 2} width={lenPx} height={4} rx={2} fill="#0f172a" />
                        )}
                      </g>
                    );
                  })}

                  {isAct && tool === 'select' && (
                    <>
                      <rect
                        x={bx - 5}
                        y={by + bodyH / 2 - 14}
                        width={8}
                        height={28}
                        rx={4}
                        fill="#ef4444"
                        stroke="#ffffff"
                        strokeWidth={1.5}
                        style={{ cursor: 'ew-resize' }}
                        data-box-handle="left"
                        data-box-id={box.id}
                      />
                      <rect
                        x={bx + bw - 3}
                        y={by + bodyH / 2 - 14}
                        width={8}
                        height={28}
                        rx={4}
                        fill="#ef4444"
                        stroke="#ffffff"
                        strokeWidth={1.5}
                        style={{ cursor: 'ew-resize' }}
                        data-box-handle="right"
                        data-box-id={box.id}
                      />
                      <rect
                        x={bx + bw / 2 - 14}
                        y={by - 5}
                        width={28}
                        height={8}
                        rx={4}
                        fill="#3b82f6"
                        stroke="#ffffff"
                        strokeWidth={1.5}
                        style={{ cursor: 'ns-resize' }}
                        data-box-handle="top"
                        data-box-id={box.id}
                      />
                    </>
                  )}

                  {(() => {
                    const labelY =
                      box.type === 'base' || box.type === 'fridge'
                        ? floorY + 8
                        : box.type === 'wall'
                        ? by + bodyH + 4
                        : by - 22;
                    return (
                      <g pointerEvents="none">
                        <rect
                          x={bx + bw / 2 - 54}
                          y={labelY}
                          width={108}
                          height={16}
                          rx={4}
                          fill="#ffffff"
                          stroke={isAct ? '#4f46e5' : '#cbd5e1'}
                          strokeWidth={1}
                        />
                        <text
                          x={bx + bw / 2}
                          y={labelY + 11}
                          fontSize={9}
                          fontWeight={800}
                          fill="#1e293b"
                          textAnchor="middle"
                        >
                          {`${box.width}×${box.height} · عمق ${box.depth}`}
                        </text>
                      </g>
                    );
                  })()}
                </g>
              );
            })}

            {/* صفحه رو / تاپس پیوسته روی زمینی‌ها */}
            {countertopSegments.map((seg, idx) => {
              const cx = originX + seg.startCm * s;
              const cw = (seg.endCm - seg.startCm) * s;
              const ch = seg.thicknessCm * s;
              const cy = floorY - seg.topElevCm * s;
              return (
                <rect
                  key={idx}
                  x={cx - 1}
                  y={cy}
                  width={cw + 2}
                  height={ch}
                  rx={1.5}
                  fill="#334155"
                  stroke="#0f172a"
                  strokeWidth={1}
                  pointerEvents="none"
                />
              );
            })}

            {/* خط‌کش فواصل خالی روی دیوار */}
            {gapDimensions.map((g, idx) => {
              const gx1 = originX + g.start * s;
              const gx2 = originX + g.end * s;
              const gy = floorY - 12;
              return (
                <g key={idx} pointerEvents="none" opacity={0.7}>
                  <line x1={gx1 + 2} y1={gy} x2={gx2 - 2} y2={gy} stroke="#64748b" strokeWidth={1} strokeDasharray="3,2" />
                  <text x={(gx1 + gx2) / 2} y={gy - 4} fontSize={8.5} fontWeight={800} fill="#475569" textAnchor="middle">
                    {g.len < 45 ? `${g.len}cm` : `فضای خالی ${g.len}cm`}
                  </text>
                </g>
              );
            })}

            {/* نواحی کنج */}
            {blockedZones.map((z, idx) => {
              const zx = originX + z.startCm * s;
              const zw = (z.endCm - z.startCm) * s;
              const zElev =
                z.tier === 'lower' ? 0 : z.tier === 'wall-lower' ? 145 : 190;
              const zH = z.tier === 'lower' ? 86 : z.tier === 'wall-lower' ? 75 : 45;
              const zy = floorY - (zElev + zH) * s;
              const heightPx = zH * s;

              return (
                <g key={`${z.cornerKey}_${z.tier}_${idx}`} pointerEvents="none">
                  <rect
                    x={zx}
                    y={zy}
                    width={zw}
                    height={heightPx}
                    fill="url(#corner-hatch)"
                    stroke="#dc2626"
                    strokeWidth={1.4}
                    strokeDasharray="5,3"
                  />
                  <rect
                    x={zx + zw / 2 - 42}
                    y={zy + heightPx / 2 - 11}
                    width={84}
                    height={22}
                    rx={6}
                    fill="rgba(255,255,255,0.92)"
                    stroke="#fca5a5"
                  />
                  <text
                    x={zx + zw / 2}
                    y={zy + heightPx / 2 + 3.5}
                    fontSize={9}
                    fontWeight={800}
                    fill="#b91c1c"
                    textAnchor="middle"
                  >
                    {z.role === 'blind-behind'
                      ? `کنج کور ${z.depthCm}`
                      : `عمق کنج ${z.depthCm}`}
                  </text>
                </g>
              );
            })}

            {/* لوازم آشپزخانه: سینک، گاز، ظرفشویی، لباسشویی و هود */}
            {wall.appliances.map((app: ApplianceItem) => {
              const underBox =
                wall.boxes.find(
                  (b) =>
                    b.type === 'base' &&
                    app.offsetX >= b.offsetX - 5 &&
                    app.offsetX + app.width <= b.offsetX + b.width + 5
                ) || wall.boxes.find((b) => b.type === 'base');
              const topY = underBox
                ? floorY - (underBox.elevY + underBox.height) * s
                : floorY - 86 * s;
              const plinthPx = (underBox?.plinth ?? 10) * s;
              const topPad = (underBox?.countertopCm ?? 4) * s;
              const bodyBotY = floorY - plinthPx;
              const ax = originX + app.offsetX * s;
              const aw = app.width * s;

              const isAppMulti = Boolean(multiSelection?.applianceIds.includes(app.id));

              return (
                <g
                  key={app.id}
                  style={{ cursor: tool === 'eraser' ? 'not-allowed' : 'grab' }}
                  data-app-id={app.id}
                >
                  {isAppMulti && (
                    <rect
                      x={ax - 2}
                      y={topY - 10}
                      width={aw + 4}
                      height={bodyBotY - topY + 12}
                      rx={4}
                      fill="rgba(79,70,229,0.10)"
                      stroke="#4f46e5"
                      strokeWidth={1.8}
                      strokeDasharray="4,2"
                      pointerEvents="none"
                    />
                  )}
                  {app.kind === 'sink' ? (
                    <>
                      <rect x={ax} y={topY - 4} width={aw} height={4} fill="#0f766e" rx={1} />
                      <path
                        d={`M ${ax + aw * 0.45} ${topY - 4} L ${ax + aw * 0.45} ${
                          topY - 22
                        } C ${ax + aw * 0.45} ${topY - 31}, ${ax + aw * 0.58} ${
                          topY - 31
                        }, ${ax + aw * 0.58} ${topY - 18}`}
                        fill="none"
                        stroke="#0f766e"
                        strokeWidth={2.5}
                      />
                    </>
                  ) : app.kind === 'gas' ? (
                    <>
                      <rect x={ax} y={topY - 5} width={aw} height={5} fill="#0f172a" rx={1} />
                      <line
                        x1={ax + aw * 0.15}
                        y1={topY - 7}
                        x2={ax + aw * 0.85}
                        y2={topY - 7}
                        stroke="#dc2626"
                        strokeWidth={2}
                        strokeDasharray="6,8"
                      />
                      {app.hoodKind === 'chimney' ? (
                        <path
                          d={`M ${ax + aw * 0.1} ${floorY - 150 * s} L ${ax + aw * 0.9} ${
                            floorY - 150 * s
                          } L ${ax + aw * 0.65} ${floorY - 180 * s} L ${ax + aw * 0.65} ${
                            floorY - 220 * s
                          } L ${ax + aw * 0.35} ${floorY - 220 * s} L ${ax + aw * 0.35} ${
                            floorY - 180 * s
                          } Z`}
                          fill="#cbd5e1"
                          stroke="#475569"
                          strokeWidth={1.4}
                        />
                      ) : (
                        <rect
                          x={ax + aw * 0.1}
                          y={floorY - 148 * s}
                          width={aw * 0.8}
                          height={4}
                          fill="#475569"
                          rx={1}
                        />
                      )}
                    </>
                  ) : (
                    // Built-in Dishwasher or Washing machine under continuous countertop
                    (() => {
                      const my = topY + topPad + 2;
                      const mh = Math.max(16, bodyBotY - my - 2);
                      return (
                        <>
                          <rect
                            x={ax + 2}
                            y={my}
                            width={aw - 4}
                            height={mh}
                            rx={3}
                            fill="#eef2ff"
                            stroke="#4338ca"
                            strokeWidth={1.4}
                          />
                          <line x1={ax + 4} y1={my + mh * 0.16} x2={ax + aw - 4} y2={my + mh * 0.16} stroke="#6366f1" strokeWidth={1.2} />
                          {app.kind === 'washing' && (
                            <circle
                              cx={ax + aw / 2}
                              cy={my + mh * 0.58}
                              r={Math.min(aw, mh) * 0.28}
                              fill="#ffffff"
                              stroke="#4338ca"
                              strokeWidth={2}
                            />
                          )}
                          <text
                            x={ax + aw / 2}
                            y={my + mh * (app.kind === 'washing' ? 0.12 : 0.55)}
                            fontSize={8.5}
                            fontWeight={800}
                            fill="#312e81"
                            textAnchor="middle"
                            pointerEvents="none"
                          >
                            {app.kind === 'dishwasher' ? 'ماشین ظرفشویی' : 'ماشین لباسشویی'}
                          </text>
                        </>
                      );
                    })()
                  )}
                </g>
              );
            })}

            {/* نقاط داغ دستگیره */}
            {tool === 'handle' &&
              computedSpots.map((sp) => (
                <circle
                  key={sp.spotId}
                  cx={sp.x}
                  cy={sp.y}
                  r={5.5}
                  fill="rgba(79,70,229,0.22)"
                  stroke="#4f46e5"
                  strokeWidth={1.6}
                  style={{ cursor: 'pointer' }}
                  data-hand-spot={sp.spotId}
                />
              ))}

            {/* مستطیل شبح کم‌رنگ دنبال‌کننده موس برای براش درب */}
            {tool === 'doors' && !doorsLocked && cursorPt && !doorPreview && (
              <g pointerEvents="none" opacity={0.45}>
                {(() => {
                  const gw = doorTargetWidth * s;
                  const gh = (doorOrient === 'vertical' ? 72 : 42) * s;
                  const gx = cursorPt.x - gw / 2;
                  const gy = cursorPt.y - gh / 2;
                  return (
                    <>
                      <rect
                        x={gx}
                        y={gy}
                        width={gw}
                        height={gh}
                        rx={3}
                        fill="rgba(79,70,229,0.12)"
                        stroke="#4f46e5"
                        strokeWidth={1.4}
                        strokeDasharray="5,3"
                      />
                      {doorOrient === 'horizontal' && (
                        <>
                          <line x1={gx} y1={gy + gh * 0.33} x2={gx + gw} y2={gy + gh * 0.33} stroke="#4f46e5" strokeWidth={1} strokeDasharray="3,2" />
                          <line x1={gx} y1={gy + gh * 0.66} x2={gx + gw} y2={gy + gh * 0.66} stroke="#4f46e5" strokeWidth={1} strokeDasharray="3,2" />
                        </>
                      )}
                      <text x={cursorPt.x} y={cursorPt.y + 3} fontSize={8.5} fontWeight={800} fill="#4338ca" textAnchor="middle">
                        {doorOrient === 'vertical' ? `درب ${doorTargetWidth}cm` : `کشو/افقی ${doorTargetWidth}cm`}
                      </text>
                    </>
                  );
                })()}
              </g>
            )}

            {/* شبح یخچال یا پنجره/درب هنگام حرکت موس در نمای روبرو */}
            {tool === 'fridge' && cursorPt && (
              <g pointerEvents="none" opacity={0.45}>
                {(() => {
                  const cfg = FRIDGE_MODELS[fridgeModel];
                  const fw = cfg.width * s;
                  const fh = cfg.height * s;
                  return (
                    <rect
                      x={cursorPt.x - fw / 2}
                      y={floorY - fh}
                      width={fw}
                      height={fh}
                      rx={3}
                      fill="rgba(79,70,229,0.14)"
                      stroke="#4f46e5"
                      strokeWidth={1.6}
                      strokeDasharray="5,3"
                    />
                  );
                })()}
              </g>
            )}

            {tool === 'opening' && cursorPt && (
              <g pointerEvents="none" opacity={0.45}>
                {(() => {
                  const def = OPENING_DEFAULTS[openingKind];
                  const ow = def.width * s;
                  const oh = def.height * s;
                  const oy =
                    openingKind === 'window'
                      ? cursorPt.y - oh / 2
                      : floorY - oh;
                  return (
                    <rect
                      x={cursorPt.x - ow / 2}
                      y={oy}
                      width={ow}
                      height={oh}
                      fill="rgba(2,132,199,0.16)"
                      stroke="#0284c7"
                      strokeWidth={1.6}
                      strokeDasharray="5,3"
                    />
                  );
                })()}
              </g>
            )}

            {/* پیش‌نمایش زنده براش درب‌گذاری روی باکس */}
            {doorPreview && (
              <g pointerEvents="none">
                {doorPreview.result.ok ? (
                  doorPreview.result.items.map((it, idx) => {
                    const b = doorPreview.box;
                    const bx = originX + b.offsetX * s;
                    const bh = b.height * s;
                    const by = floorY - b.elevY * s - bh;
                    const bodyH = Math.max(14, bh - b.plinth * s);
                    const topPad = b.countertopCm * s;
                    const px = bx + it.startCm * s + 1.5;
                    const pwPx = Math.max(6, it.widthCm * s - 3);
                    const py = by + topPad + 1.5;
                    const phPx = Math.max(8, bodyH - topPad - 3);
                    const pts =
                      it.drawerRatios.length > 0 ? [0, ...it.drawerRatios, 1] : [0, 1];

                    return (
                      <g key={idx}>
                        <rect
                          x={px}
                          y={py}
                          width={pwPx}
                          height={phPx}
                          rx={3}
                          fill="rgba(79,70,229,0.14)"
                          stroke="#4f46e5"
                          strokeWidth={1.8}
                          strokeDasharray="6,3"
                        />
                        {pts.slice(1, -1).map((r, ri) => (
                          <line
                            key={ri}
                            x1={px}
                            y1={py + phPx * r}
                            x2={px + pwPx}
                            y2={py + phPx * r}
                            stroke="#4f46e5"
                            strokeWidth={1.6}
                            strokeDasharray="4,3"
                          />
                        ))}
                        <text
                          x={px + pwPx / 2}
                          y={py + phPx / 2 + 4}
                          fontSize={10}
                          fontWeight={800}
                          fill="#312e81"
                          textAnchor="middle"
                        >
                          {Math.round(it.widthCm)}cm
                        </text>
                      </g>
                    );
                  })
                ) : (
                  (() => {
                    const b = doorPreview.box;
                    const bx = originX + b.offsetX * s;
                    const bh = b.height * s;
                    const by = floorY - b.elevY * s - bh;
                    return (
                      <g transform={`translate(${bx + (doorHover?.cursorCmInBox || 0) * s}, ${by + 20})`}>
                        <rect x={-56} y={-11} width={112} height={22} rx={6} fill="#dc2626" />
                        <text x={0} y={3.5} fontSize={9} fontWeight={800} fill="#ffffff" textAnchor="middle">
                          غیرمجاز / خارج از بازه
                        </text>
                      </g>
                    );
                  })()
                )}
              </g>
            )}

            {/* پیش‌نمایش مداد یونیت‌بندی و طبقه‌بندی */}
            {(tool === 'pencil' || tool === 'skeleton') &&
              pencilHover &&
              (() => {
                const b = wall.boxes.find((x) => x.id === pencilHover.boxId);
                if (!b) return null;
                const bx = originX + b.offsetX * s;
                const bh = b.height * s;
                const by = floorY - b.elevY * s - bh;
                const bodyH = Math.max(14, bh - b.plinth * s);
                const topPad = b.countertopCm * s;

                if (pencilHover.kind === 'seam' && pencilHover.seamCm !== undefined) {
                  const ux = bx + pencilHover.seamCm * s;
                  return (
                    <g pointerEvents="none">
                      <rect
                        x={ux - tPx}
                        y={by + topPad}
                        width={tPx * 2}
                        height={bodyH - topPad}
                        fill="rgba(124,58,237,0.35)"
                        stroke="#7c3aed"
                        strokeWidth={2}
                      />
                    </g>
                  );
                }

                if (pencilHover.kind === 'blocked') {
                  const tx = bx + (pencilHover.cursorCm ?? b.width / 2) * s;
                  const msg =
                    pencilHover.blockedReason?.includes('کشو')
                      ? 'کشو طبقه ندارد'
                      : 'ابتدا مرز یونیت را تعیین کنید';
                  return (
                    <g transform={`translate(${tx}, ${by + bodyH * 0.45})`} pointerEvents="none">
                      <rect x={-64} y={-11} width={128} height={22} rx={6} fill="#b45309" />
                      <text x={0} y={3.5} fontSize={9} fontWeight={800} fill="#ffffff" textAnchor="middle">
                        {msg}
                      </text>
                    </g>
                  );
                }

                if (
                  pencilHover.kind === 'shelf' &&
                  pencilHover.startCm !== undefined &&
                  pencilHover.endCm !== undefined
                ) {
                  const sx = bx + pencilHover.startCm * s + tPx;
                  const sw = Math.max(8, (pencilHover.endCm - pencilHover.startCm) * s - tPx * 2);
                  const ratios =
                    shelfCount === 1
                      ? [pencilHover.yRatio ?? 0.5]
                      : Array.from({ length: shelfCount }, (_, i) => (i + 1) / (shelfCount + 1));

                  return (
                    <g pointerEvents="none">
                      {ratios.map((r, i) => (
                        <line
                          key={i}
                          x1={sx}
                          y1={by + topPad + (bodyH - topPad) * r}
                          x2={sx + sw}
                          y2={by + topPad + (bodyH - topPad) * r}
                          stroke="#d97706"
                          strokeWidth={2.5}
                          strokeDasharray="5,3"
                        />
                      ))}
                    </g>
                  );
                }
                return null;
              })()}

            {/* مستطیل انتخاب گروهی (Marquee Box Selection) */}
            {marquee && (
              <rect
                x={Math.min(marquee.startX, marquee.currX)}
                y={Math.min(marquee.startY, marquee.currY)}
                width={Math.abs(marquee.currX - marquee.startX)}
                height={Math.abs(marquee.currY - marquee.startY)}
                fill="rgba(79,70,229,0.12)"
                stroke="#4f46e5"
                strokeWidth={1.6}
                strokeDasharray="5,3"
                pointerEvents="none"
              />
            )}
          </>
        )}
      </svg>
    </section>
  );
};
