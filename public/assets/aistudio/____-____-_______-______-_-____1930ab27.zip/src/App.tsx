import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  APPLIANCE_CONFIGS,
  BOX_PRESETS,
  CORNER_FILLER_CM,
  DEFAULT_PROJECT_SETTINGS,
  OPENING_DEFAULTS,
} from './cad/constants';
import {
  clampBoxInternalsAfterResize,
  createEmptyBox,
  divideBoxEvenlyRespectingCorners,
  equalizeDoorsInBox,
  eraseDoorWithRule,
  mirrorBoxLayout,
  optimizeBoxWithAppliances,
  placeApplianceWithCabinetRules,
  placeFridgeOnWall,
} from './cad/doorRules';
import {
  analyzeCornerJunction,
  autoOrientWallsOnAdd,
  detectCornerJunctions,
  getBoxTier,
  getCornerBlockedZonesForWall,
  moveSmartWallNode,
  SweepSegment,
  toggleCornerOwner,
  WallNodeRef,
} from './cad/cornerLogic';
import {
  createWallOpening,
  findCollidingOpening,
  OPENING_LABELS,
  updateOpeningGeometry,
} from './cad/openingRules';
import { buildPresetProject, PresetMode } from './cad/presets';
import {
  ApplianceKind,
  BoxKind,
  DoorKind,
  DoorSwing,
  FridgeModel,
  HandleStyle,
  MultiSelection,
  OpeningKind,
  Orientation,
  ProjectSettings,
  ProjectState,
  ToolId,
  Wall,
} from './cad/types';
import { BottomDock } from './components/BottomDock';
import { FrontCanvas } from './components/FrontCanvas';
import { PlanCanvas } from './components/PlanCanvas';
import { SettingsModal } from './components/SettingsModal';
import { SideInspector } from './components/SideInspector';
import { TopBar } from './components/TopBar';

const STORAGE_KEY = 'cabinet_cad_project_v2';

function cloneProject(p: ProjectState): ProjectState {
  return JSON.parse(JSON.stringify(p));
}

function normalizeProject(raw: ProjectState): ProjectState {
  return {
    ...raw,
    selectedOpeningId: raw.selectedOpeningId ?? null,
    settings: {
      ...DEFAULT_PROJECT_SETTINGS,
      ...(raw.settings || {}),
    },
    walls: (raw.walls || []).map((w) => ({
      ...w,
      boxes: w.boxes || [],
      appliances: w.appliances || [],
      openings: w.openings || [],
    })),
  };
}

function loadInitialProject(): ProjectState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as ProjectState;
      if (parsed && Array.isArray(parsed.walls)) {
        return normalizeProject(parsed);
      }
    }
  } catch {
    // fallback to preset
  }
  return buildPresetProject('L');
}

function subtractBlockedIntervals(
  startCm: number,
  endCm: number,
  blocked: Array<{ start: number; end: number }>
): Array<{ start: number; end: number }> {
  let spans = [{ start: startCm, end: endCm }];
  for (const b of blocked) {
    const next: Array<{ start: number; end: number }> = [];
    for (const sp of spans) {
      if (b.end <= sp.start + 1 || b.start >= sp.end - 1) {
        next.push(sp);
      } else {
        if (b.start - sp.start >= 30) next.push({ start: sp.start, end: b.start });
        if (sp.end - b.end >= 30) next.push({ start: b.end, end: sp.end });
      }
    }
    spans = next;
  }
  return spans;
}

export default function App() {
  const [project, setProject] = useState<ProjectState>(() => loadInitialProject());
  const [history, setHistory] = useState<string[]>(() => [JSON.stringify(loadInitialProject())]);
  const [historyIdx, setHistoryIdx] = useState<number>(0);

  const [tool, setTool] = useState<ToolId>('doors');
  const [inspectorCollapsed, setInspectorCollapsed] = useState<boolean>(() =>
    typeof window !== 'undefined' ? window.innerWidth < 768 : false
  );
  const [settingsOpen, setSettingsOpen] = useState(false);

  // Tool options live cleanly in state and are controlled from SideInspector
  const [drawBoxKind, setDrawBoxKind] = useState<BoxKind>('base');
  const [doorOrient, setDoorOrient] = useState<Orientation>('vertical');
  const [doorTargetWidth, setDoorTargetWidth] = useState<number>(60);
  const [doorVertCount, setDoorVertCount] = useState<number>(1);
  const [drawerPatIdx, setDrawerPatIdx] = useState<number>(1);
  const [liftPatIdx, setLiftPatIdx] = useState<number>(0);
  const [shelfCount, setShelfCount] = useState<number>(1);
  const [handleStyle, setHandleStyle] = useState<HandleStyle>('simple');
  const [handleOrient, setHandleOrient] = useState<Orientation>('vertical');
  const [fridgeModel, setFridgeModel] = useState<FridgeModel>('side-by-side');
  const [fridgeHasFrame, setFridgeHasFrame] = useState<boolean>(true);
  const [applianceKind, setApplianceKind] = useState<ApplianceKind>('sink');
  const [hoodKind, setHoodKind] = useState<'hidden' | 'chimney'>('hidden');
  const [openingKind, setOpeningKind] = useState<OpeningKind>('window');
  const [openingSwing, setOpeningSwing] = useState<DoorSwing>('left-in');

  const [pxPerCm, setPxPerCm] = useState(2.1);
  const [frontPan, setFrontPan] = useState({ x: 0, y: 0 });
  const [topHeightPct, setTopHeightPct] = useState(34);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    const onResize = () => {
      if (window.innerWidth < 768) {
        setInspectorCollapsed(true);
      }
    };
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  const toastTimer = useRef<number | null>(null);
  const workspaceRef = useRef<HTMLDivElement | null>(null);
  const splitDragging = useRef(false);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 2400);
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(project));
    } catch {
      // ignore quota errors
    }
  }, [project]);

  const commitState = useCallback(
    (next: ProjectState, pushHist = true) => {
      setProject(next);
      if (pushHist) {
        const snap = JSON.stringify(next);
        setHistory((prev) => {
          const sliced = prev.slice(0, historyIdx + 1);
          if (sliced[sliced.length - 1] === snap) return sliced;
          const appended = [...sliced, snap];
          if (appended.length > 50) appended.shift();
          setHistoryIdx(appended.length - 1);
          return appended;
        });
      }
    },
    [historyIdx]
  );

  const handleUndo = useCallback(() => {
    if (historyIdx <= 0) return;
    const prevIdx = historyIdx - 1;
    const restored = normalizeProject(JSON.parse(history[prevIdx]) as ProjectState);
    setProject(restored);
    setHistoryIdx(prevIdx);
    showToast('آخرین عملیات لغو شد');
  }, [history, historyIdx, showToast]);

  const handleRedo = useCallback(() => {
    if (historyIdx >= history.length - 1) return;
    const nextIdx = historyIdx + 1;
    const restored = normalizeProject(JSON.parse(history[nextIdx]) as ProjectState);
    setProject(restored);
    setHistoryIdx(nextIdx);
    showToast('عملیات تکرار شد');
  }, [history, historyIdx, showToast]);

  const activeWall = useMemo(
    () => project.walls.find((w) => w.id === project.activeWallId) || project.walls[0] || null,
    [project.walls, project.activeWallId]
  );

  const activeBox = useMemo(() => {
    if (!activeWall || !activeWall.boxes.length || !project.activeBoxId) return null;
    return activeWall.boxes.find((b) => b.id === project.activeBoxId) || null;
  }, [activeWall, project.activeBoxId]);

  const selectedDoor = useMemo(() => {
    if (!activeBox || !activeBox.doors.length || !project.selectedDoorId) return null;
    return activeBox.doors.find((d) => d.id === project.selectedDoorId) || null;
  }, [activeBox, project.selectedDoorId]);

  const selectedOpening = useMemo(() => {
    if (!activeWall || !project.selectedOpeningId) return null;
    return (activeWall.openings || []).find((o) => o.id === project.selectedOpeningId) || null;
  }, [activeWall, project.selectedOpeningId]);

  const fitWallToView = useCallback(
    (w: Wall | null) => {
      if (!w) return;
      const ws = workspaceRef.current;
      const pw = ws?.clientWidth || 900;
      const ph = (ws?.clientHeight || 600) * ((100 - topHeightPct) / 100);
      const sx = (pw * 0.78) / Math.max(w.length, 100);
      const sy = (ph * 0.74) / Math.max(w.height, 100);
      setPxPerCm(+Math.max(0.75, Math.min(3.5, Math.min(sx, sy))).toFixed(2));
      setFrontPan({ x: 0, y: 0 });
    },
    [topHeightPct]
  );

  useEffect(() => {
    fitWallToView(activeWall);
    // Initial fit on mount
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSelectTool = (nextTool: ToolId) => {
    setTool(nextTool);

    if ((nextTool === 'pencil' || nextTool === 'skeleton') && !project.doorsLocked) {
      const next = cloneProject(project);
      next.doorsLocked = true;
      commitState(next, true);
      showToast('درب‌ها قفل شدند: روی درز دو درب = دیواره یونیت | وسط درب = طبقه');
    } else if (nextTool === 'doors' && project.doorsLocked) {
      const next = cloneProject(project);
      next.doorsLocked = false;
      commitState(next, true);
    }
  };

  const handleToggleLock = () => {
    const next = cloneProject(project);
    next.doorsLocked = !next.doorsLocked;
    commitState(next, true);
    if (next.doorsLocked) {
      setTool('pencil');
      showToast('درب‌ها قفل شدند برای یونیت‌بندی و طبقه‌بندی');
    } else {
      setTool('doors');
      showToast('درب‌ها باز شدند');
    }
  };

  const handleApplyPreset = (mode: PresetMode) => {
    const fresh = buildPresetProject(mode);
    const snap = JSON.stringify(fresh);
    setProject(fresh);
    setHistory([snap]);
    setHistoryIdx(0);
    setTool('doors');
    fitWallToView(fresh.walls[0] || null);
    showToast(mode === 'closet' ? 'الگوی کمد دیواری بارگذاری شد' : `چیدمان ${mode} بارگذاری شد`);
  };

  const handleNewProject = () => {
    const empty: ProjectState = {
      walls: [],
      cornerOwners: {},
      activeWallId: null,
      activeBoxId: null,
      selectedDoorId: null,
      selectedOpeningId: null,
      doorsLocked: false,
      settings: project.settings || { ...DEFAULT_PROJECT_SETTINGS },
    };
    const snap = JSON.stringify(empty);
    setProject(empty);
    setHistory([snap]);
    setHistoryIdx(0);
    setTool('wall');
    showToast('صفحه خالی شد؛ ابزار رسم دیوار فعال است');
  };

  const mutateActiveWall = useCallback(
    (mutator: (wall: Wall) => void, commitHistory = true, toastMsg?: string) => {
      setProject((prev) => {
        const next = cloneProject(prev);
        const w = next.walls.find((x) => x.id === next.activeWallId) || next.walls[0];
        if (!w) return prev;
        if (!w.openings) w.openings = [];
        mutator(w);
        if (commitHistory) {
          const snap = JSON.stringify(next);
          setHistory((h) => {
            const sliced = h.slice(0, historyIdx + 1);
            if (sliced[sliced.length - 1] === snap) return sliced;
            const appended = [...sliced, snap];
            if (appended.length > 50) appended.shift();
            setHistoryIdx(appended.length - 1);
            return appended;
          });
        }
        return next;
      });
      if (toastMsg) showToast(toastMsg);
    },
    [historyIdx, showToast]
  );

  const handleCreateBoxesFromSweep = (
    segments: SweepSegment[],
    kind: BoxKind,
    suggestedOwners?: Record<string, string>,
    flipOverrides?: Record<string, 1 | -1>
  ) => {
    const next = cloneProject(project);
    const settings = next.settings || DEFAULT_PROJECT_SETTINGS;

    if (flipOverrides) {
      for (const w of next.walls) {
        if (flipOverrides[w.id]) {
          w.flipSide = flipOverrides[w.id];
        }
      }
    }

    if (suggestedOwners) {
      for (const [key, ownerId] of Object.entries(suggestedOwners)) {
        if (!next.cornerOwners[key]) {
          next.cornerOwners[key] = ownerId;
        }
      }
    }

    // Align single-wall corner touch ownership cleanly
    if (segments.length === 1) {
      const seg = segments[0];
      const w = next.walls.find((x) => x.id === seg.wallId);
      if (w) {
        const tier = kind === 'wall' ? 'wall-lower' : kind === 'wall-deep' ? 'wall-upper' : 'lower';
        const depthSetback = kind === 'wall' ? 32 : kind === 'wall-deep' ? 58 : kind === 'fridge' ? 70 : 60;
        const junctions = detectCornerJunctions(next.walls, next.cornerOwners);
        for (const j of junctions) {
          const isA = j.wallAId === w.id;
          const isB = j.wallBId === w.id;
          if (!isA && !isB) continue;
          const myEnd = isA ? j.wallAEnd : j.wallBEnd;
          const otherId = isA ? j.wallBId : j.wallAId;
          const otherEnd = isA ? j.wallBEnd : j.wallAEnd;
          const otherWall = next.walls.find((x) => x.id === otherId);
          if (!otherWall) continue;
          const geom = analyzeCornerJunction(w, myEnd, otherWall, otherEnd);
          if (geom.kind !== 'inside-90') continue;

          const touchesCorner =
            (myEnd === 'start' && seg.startCm <= 5) ||
            (myEnd === 'end' && seg.startCm + seg.widthCm >= w.length - 5);
          if (!touchesCorner) continue;

          const otherHasCornerBox = otherWall.boxes.some((ob) => {
            if (getBoxTier(ob) !== tier) return false;
            return otherEnd === 'start' ? ob.offsetX <= 5 : ob.offsetX + ob.width >= otherWall.length - 5;
          });

          if (otherHasCornerBox) {
            next.cornerOwners[j.key] = otherWall.id;
            if (myEnd === 'start' && seg.startCm < depthSetback) {
              const delta = depthSetback - seg.startCm;
              seg.startCm = depthSetback;
              seg.widthCm = Math.max(0, seg.widthCm - delta);
            } else if (myEnd === 'end' && seg.startCm + seg.widthCm > w.length - depthSetback) {
              seg.widthCm = Math.max(0, w.length - depthSetback - seg.startCm);
            }
          } else if (!next.cornerOwners[j.key]) {
            next.cornerOwners[j.key] = w.id;
          }
        }
      }
    }

    let firstBoxId: string | null = null;
    let firstWallId: string | null = null;
    let blockedByOpening = false;

    const boxPreset = BOX_PRESETS[kind] || BOX_PRESETS.base;
    const candElevY = kind === 'wall' ? settings.wallCabElevCm : boxPreset.elevY;
    const candH =
      kind === 'base'
        ? settings.baseHeightCm
        : kind === 'wall'
        ? settings.wallCabHeightCm
        : boxPreset.height;

    segments.forEach((seg) => {
      if (seg.widthCm < 30) return;
      const w = next.walls.find((x) => x.id === seg.wallId);
      if (!w) return;

      const newTier = kind === 'wall' ? 'wall-lower' : kind === 'wall-deep' ? 'wall-upper' : 'lower';
      const blockedSpans: Array<{ start: number; end: number }> = [];

      for (const existing of w.boxes) {
        if (getBoxTier(existing) !== newTier) continue;
        blockedSpans.push({ start: existing.offsetX, end: existing.offsetX + existing.width });
      }
      for (const op of w.openings || []) {
        const opTop = op.elevY + op.height;
        const boxTop = candElevY + candH;
        if (candElevY < opTop - 1 && boxTop > op.elevY + 1) {
          blockedSpans.push({ start: op.offsetX, end: op.offsetX + op.width });
          blockedByOpening = true;
        }
      }

      const validSpans = subtractBlockedIntervals(seg.startCm, seg.startCm + seg.widthCm, blockedSpans);
      validSpans.forEach((sp) => {
        const finalW = Math.round(sp.end - sp.start);
        if (finalW < 30) return;
        const box = createEmptyBox(kind, sp.start, finalW, { settings });
        w.boxes.push(box);
        if (!firstBoxId) {
          firstBoxId = box.id;
          firstWallId = w.id;
        }
      });
    });

    if (firstBoxId && firstWallId) {
      next.activeWallId = firstWallId;
      next.activeBoxId = firstBoxId;
      next.selectedDoorId = null;
      next.selectedOpeningId = null;
      commitState(next, true);
      const w = next.walls.find((x) => x.id === firstWallId) || null;
      fitWallToView(w);
      setTool('doors');
      showToast(segments.length > 1 ? 'کابینت پیوسته در کنج ساخته شد' : 'باکس جدید اضافه شد');
    } else if (blockedByOpening) {
      showToast('این بخش با پنجره، درب ورودی یا ستون دیوار تداخل دارد');
    }
  };

  const handleToggleCornerOwner = (cornerKey: string) => {
    const next = cloneProject(project);
    next.cornerOwners = toggleCornerOwner(next.walls, next.cornerOwners, cornerKey);
    commitState(next, true);
    showToast('جهت و اولویت کنج دیوارها جابجا شد');
  };

  const handlePlaceAppliance = (wallId: string, boxId: string, desiredOffsetX: number) => {
    const next = cloneProject(project);
    const w = next.walls.find((x) => x.id === wallId);
    const box = w?.boxes.find((b) => b.id === boxId);
    if (!w || !box) return;

    const res = placeApplianceWithCabinetRules(
      w,
      next.walls,
      applianceKind,
      box,
      desiredOffsetX,
      next.cornerOwners,
      hoodKind
    );
    if (!res.ok) {
      showToast(res.message);
      return;
    }
    const wallChanged = next.activeWallId !== w.id;
    next.activeWallId = w.id;
    next.activeBoxId = box.id;
    next.selectedDoorId = null;
    next.selectedOpeningId = null;
    commitState(next, true);
    if (wallChanged) fitWallToView(w);
    showToast(res.message);
  };

  const handlePlaceFridge = (wallId: string, desiredOffsetX: number) => {
    const next = cloneProject(project);
    const w = next.walls.find((x) => x.id === wallId);
    if (!w) return;

    const res = placeFridgeOnWall(
      w,
      next.walls,
      fridgeModel,
      desiredOffsetX,
      next.cornerOwners,
      fridgeHasFrame,
      next.settings || DEFAULT_PROJECT_SETTINGS
    );
    if (!res.ok) {
      showToast(res.message);
      return;
    }

    const wallChanged = next.activeWallId !== w.id;
    next.activeWallId = w.id;
    next.activeBoxId = res.fridgeId ?? null;
    next.selectedDoorId = null;
    next.selectedOpeningId = null;
    commitState(next, true);
    if (wallChanged) fitWallToView(w);
    showToast(res.message);
  };

  const handlePlaceOpening = (wallId: string, desiredOffsetX: number, desiredElevY?: number) => {
    const next = cloneProject(project);
    const w = next.walls.find((x) => x.id === wallId);
    if (!w) return;
    if (!w.openings) w.openings = [];

    const op = createWallOpening(openingKind, desiredOffsetX, w, {
      elevY: desiredElevY ?? OPENING_DEFAULTS[openingKind].elevY,
      swingDir: openingSwing,
    });

    const overlap = findCollidingOpening(w, op.offsetX, op.offsetX + op.width, op.elevY, op.height);
    if (overlap) {
      showToast('در این محدوده قبلاً پنجره، درب یا ستون قرار گرفته است');
      return;
    }

    w.openings.push(op);
    const wallChanged = next.activeWallId !== w.id;
    next.activeWallId = w.id;
    next.selectedOpeningId = op.id;
    next.activeBoxId = null;
    next.selectedDoorId = null;
    commitState(next, true);
    if (wallChanged) fitWallToView(w);
    showToast(`${OPENING_LABELS[openingKind]} ثبت شد؛ لبه‌ها را بکشید تا اندازه دقیق شود`);
  };

  const handleMoveOpening = (
    wallId: string,
    openingId: string,
    offsetX: number,
    commit: boolean
  ) => {
    if (commit && offsetX < 0) {
      commitState(cloneProject(project), true);
      return;
    }
    const next = cloneProject(project);
    const w = next.walls.find((x) => x.id === wallId);
    const op = w?.openings?.find((o) => o.id === openingId);
    if (!w || !op) return;
    if (offsetX >= 0) {
      updateOpeningGeometry(op, w, { offsetX });
    }
    commitState(next, commit);
  };

  const handleUpdateOpeningNumeric = (
    field: 'offsetX' | 'width' | 'elevY' | 'height',
    val: number
  ) => {
    if (!selectedOpening || Number.isNaN(val)) return;
    mutateActiveWall((w) => {
      const op = w.openings?.find((o) => o.id === selectedOpening.id);
      if (op) updateOpeningGeometry(op, w, { [field]: val });
    }, true);
  };

  const handleChangeOpeningSwing = (swing: DoorSwing) => {
    if (!selectedOpening) return;
    mutateActiveWall((w) => {
      const op = w.openings?.find((o) => o.id === selectedOpening.id);
      if (op) updateOpeningGeometry(op, w, { swingDir: swing });
    }, true, 'جهت بازشوی درب تغییر یافت');
  };

  const handleDeleteOpening = (wallId: string, openingId: string) => {
    const next = cloneProject(project);
    const w = next.walls.find((x) => x.id === wallId);
    if (!w) return;
    w.openings = (w.openings || []).filter((o) => o.id !== openingId);
    if (next.selectedOpeningId === openingId) next.selectedOpeningId = null;
    commitState(next, true);
    showToast('پنجره / درب / ستون حذف شد');
  };

  const handleDeleteBoxFromPlan = (wallId: string, boxId: string) => {
    const next = cloneProject(project);
    const w = next.walls.find((x) => x.id === wallId);
    if (!w) return;
    w.boxes = w.boxes.filter((b) => b.id !== boxId);
    if (next.activeBoxId === boxId) {
      next.activeBoxId = null;
      next.selectedDoorId = null;
    }
    commitState(next, true);
    showToast('باکس از پلان حذف شد');
  };

  const handleDeleteApplianceFromPlan = (wallId: string, appId: string) => {
    const next = cloneProject(project);
    const w = next.walls.find((x) => x.id === wallId);
    if (!w) return;
    w.appliances = w.appliances.filter((a) => a.id !== appId);
    commitState(next, true);
    showToast('تجهیز حذف شد');
  };

  const handleSetDoorKind = (kind: DoorKind, drawerRatios: number[] = []) => {
    if (!selectedDoor || !activeBox) return;
    mutateActiveWall((w) => {
      const b = w.boxes.find((x) => x.id === activeBox.id);
      const d = b?.doors.find((x) => x.id === selectedDoor.id);
      if (!d) return;
      d.kind = kind;
      d.drawerRatios = [...drawerRatios];
      if (b) b.handles = b.handles.filter((h) => h.doorId !== d.id);
    }, true);
  };

  const handleDivideEvenly = (count: number) => {
    if (!activeWall || !activeBox) return;
    const next = cloneProject(project);
    const w = next.walls.find((x) => x.id === activeWall.id);
    const b = w?.boxes.find((x) => x.id === activeBox.id);
    if (!w || !b) return;
    const blocked = getCornerBlockedZonesForWall(w, next.walls, next.cornerOwners);
    const res = divideBoxEvenlyRespectingCorners(b, count, blocked);
    if (!res.ok) {
      showToast(res.message);
      return;
    }
    next.selectedDoorId = b.doors[0]?.id ?? null;
    commitState(next, true);
    showToast(res.message);
  };

  const handleEqualizeDoors = () => {
    if (!activeWall || !activeBox) return;
    const next = cloneProject(project);
    const w = next.walls.find((x) => x.id === activeWall.id);
    const b = w?.boxes.find((x) => x.id === activeBox.id);
    if (!w || !b) return;
    const blocked = getCornerBlockedZonesForWall(w, next.walls, next.cornerOwners);
    const res = equalizeDoorsInBox(b, blocked);
    if (!res.ok) {
      showToast(res.message);
      return;
    }
    commitState(next, true);
    showToast(res.message);
  };

  const handleMirrorBox = () => {
    if (!activeBox) return;
    mutateActiveWall((w) => {
      const b = w.boxes.find((x) => x.id === activeBox.id);
      if (b) mirrorBoxLayout(b);
    }, true, 'چیدمان باکس قرینه شد');
  };

  const handleAlignBox = (pos: 'left' | 'center' | 'right') => {
    if (!activeWall || !activeBox) return;
    mutateActiveWall((w) => {
      const b = w.boxes.find((x) => x.id === activeBox.id);
      if (!b) return;
      if (pos === 'left') b.offsetX = 0;
      else if (pos === 'right') b.offsetX = Math.max(0, w.length - b.width);
      else b.offsetX = Math.max(0, Math.round((w.length - b.width) / 2));
    }, true, 'موقعیت باکس تراز شد');
  };

  const handleAddFiller = (side: 'left' | 'right') => {
    if (!activeBox) return;
    if (activeBox.width - CORNER_FILLER_CM < 30) {
      showToast('عرض باکس پس از لقی‌گذاری نباید کمتر از ۳۰cm شود');
      return;
    }
    mutateActiveWall((w) => {
      const b = w.boxes.find((x) => x.id === activeBox.id);
      if (!b) return;
      b.width = Math.max(30, b.width - CORNER_FILLER_CM);
      if (side === 'left') {
        b.offsetX = Math.min(w.length - b.width, b.offsetX + CORNER_FILLER_CM);
      }
      clampBoxInternalsAfterResize(b);
    }, true, `لقی ${CORNER_FILLER_CM}cm در سمت ${side === 'left' ? 'چپ' : 'راست'} اعمال شد`);
  };

  const handleUpdateBoxNumeric = (
    field: 'width' | 'height' | 'offsetX' | 'elevY' | 'depth',
    val: number
  ) => {
    if (!activeBox || Number.isNaN(val)) return;
    mutateActiveWall((w) => {
      const b = w.boxes.find((x) => x.id === activeBox.id);
      if (!b) return;
      if (field === 'width') {
        b.width = Math.max(30, Math.min(w.length - b.offsetX, Math.round(val)));
        clampBoxInternalsAfterResize(b);
      } else if (field === 'height') {
        b.height = Math.max(30, Math.min(w.height - b.elevY, Math.round(val)));
      } else if (field === 'depth') {
        b.depth = Math.max(20, Math.min(90, Math.round(val)));
      } else if (field === 'offsetX') {
        b.offsetX = Math.max(0, Math.min(w.length - b.width, Math.round(val)));
      } else if (field === 'elevY') {
        b.elevY = Math.max(0, Math.min(w.height - b.height, Math.round(val)));
      }
    }, true);
  };

  const handleDeleteSelectedBox = () => {
    if (!activeBox) return;
    const deletedId = activeBox.id;
    const next = cloneProject(project);
    const w = next.walls.find((x) => x.id === next.activeWallId) || next.walls[0];
    if (!w) return;
    w.boxes = w.boxes.filter((b) => b.id !== deletedId);
    if (next.activeBoxId === deletedId) {
      next.activeBoxId = null;
      next.selectedDoorId = null;
    }
    commitState(next, true);
    showToast('باکس حذف شد');
  };

  const handleMoveWallNode = (
    refs: WallNodeRef[],
    x: number,
    y: number,
    commit: boolean
  ) => {
    const next = cloneProject(project);
    const ok = moveSmartWallNode(next.walls, refs, x, y);
    if (!ok) {
      if (commit) showToast('حداقل طول مجاز دیوار ۴۰ سانتی‌متر است');
      return;
    }
    commitState(next, commit);
  };

  const handleOptimizeAppliances = () => {
    if (!activeWall || !activeBox) return;
    const next = cloneProject(project);
    const w = next.walls.find((x) => x.id === activeWall.id);
    const b = w?.boxes.find((x) => x.id === activeBox.id);
    if (!w || !b) return;
    const res = optimizeBoxWithAppliances(w, next.walls, b, next.cornerOwners);
    if (!res.ok) {
      showToast(res.message);
      return;
    }
    commitState(next, true);
    showToast(res.message);
  };

  const handleSetMultiSelection = useCallback((m?: MultiSelection) => {
    setProject((p) => ({ ...p, multiSelection: m }));
  }, []);

  const handleBulkDelete = useCallback(() => {
    const ms = project.multiSelection;
    if (!ms) return;
    const total = ms.boxIds.length + ms.doorIds.length + ms.openingIds.length + ms.applianceIds.length;
    if (total === 0) return;

    const next = cloneProject(project);
    const w = next.walls.find((x) => x.id === next.activeWallId) || next.walls[0];
    if (!w) return;

    const boxSet = new Set(ms.boxIds);
    const doorSet = new Set(ms.doorIds);
    const opSet = new Set(ms.openingIds);
    const appSet = new Set(ms.applianceIds);

    w.boxes = w.boxes.filter((b) => !boxSet.has(b.id));
    for (const b of w.boxes) {
      for (const dId of ms.doorIds) {
        if (b.doors.some((d) => d.id === dId)) {
          eraseDoorWithRule(b, dId);
        }
      }
      b.doors = b.doors.filter((d) => !doorSet.has(d.id));
    }
    w.openings = (w.openings || []).filter((o) => !opSet.has(o.id));
    w.appliances = w.appliances.filter((a) => !appSet.has(a.id));

    if (next.activeBoxId && boxSet.has(next.activeBoxId)) {
      next.activeBoxId = null;
      next.selectedDoorId = null;
    }
    if (next.selectedOpeningId && opSet.has(next.selectedOpeningId)) {
      next.selectedOpeningId = null;
    }
    next.multiSelection = undefined;
    commitState(next, true);
    showToast('موارد انتخاب‌شده با هم حذف شدند');
  }, [project, commitState, showToast]);

  const handleBulkSetDoorKind = (kind: DoorKind, ratios: number[] = []) => {
    const ms = project.multiSelection;
    if (!ms || !ms.doorIds.length) return;
    const doorSet = new Set(ms.doorIds);
    mutateActiveWall((w) => {
      for (const b of w.boxes) {
        for (const d of b.doors) {
          if (doorSet.has(d.id) && d.kind !== 'fridge') {
            d.kind = kind;
            d.drawerRatios = [...ratios];
            b.handles = b.handles.filter((h) => h.doorId !== d.id);
          }
        }
      }
    }, true, 'نوع درب‌های انتخاب‌شده به‌صورت گروهی تغییر یافت');
  };

  const handleBulkEqualizeDoors = () => {
    const ms = project.multiSelection;
    if (!ms) return;
    const next = cloneProject(project);
    const w = next.walls.find((x) => x.id === next.activeWallId) || next.walls[0];
    if (!w) return;
    const blocked = getCornerBlockedZonesForWall(w, next.walls, next.cornerOwners);
    const doorSet = new Set(ms.doorIds);
    const boxSet = new Set(ms.boxIds);
    let count = 0;
    for (const b of w.boxes) {
      if (boxSet.has(b.id) || b.doors.some((d) => doorSet.has(d.id))) {
        const res = equalizeDoorsInBox(b, blocked);
        if (res.ok) count++;
      }
    }
    if (count > 0) {
      commitState(next, true);
      showToast('درب‌های باکس‌های انتخاب‌شده مساوی‌سازی شدند');
    }
  };

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.tagName === 'SELECT')
      ) {
        return;
      }
      if (e.key === 'Delete' || e.key === 'Backspace') {
        const ms = project.multiSelection;
        const hasMulti =
          ms &&
          ms.boxIds.length + ms.doorIds.length + ms.openingIds.length + ms.applianceIds.length > 0;
        if (hasMulti) {
          e.preventDefault();
          handleBulkDelete();
        } else if (activeWall && project.selectedOpeningId) {
          e.preventDefault();
          handleDeleteOpening(activeWall.id, project.selectedOpeningId);
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [project.multiSelection, project.selectedOpeningId, activeWall, handleBulkDelete]);

  const handleSaveSettings = (nextSettings: ProjectSettings, applyToExisting: boolean) => {
    const next = cloneProject(project);
    next.settings = nextSettings;
    if (applyToExisting) {
      next.walls.forEach((w) => {
        w.height = nextSettings.wallHeightCm;
        w.boxes.forEach((b) => {
          if (b.type === 'base') {
            b.height = nextSettings.baseHeightCm;
            b.plinth = nextSettings.plinthCm;
            b.countertopCm = nextSettings.countertopCm;
          } else if (b.type === 'wall') {
            b.elevY = nextSettings.wallCabElevCm;
            b.height = nextSettings.wallCabHeightCm;
          }
        });
        (w.openings || []).forEach((op) => {
          if (op.kind === 'column') op.height = nextSettings.wallHeightCm;
          else updateOpeningGeometry(op, w, {});
        });
      });
    }
    commitState(next, true);
    setSettingsOpen(false);
    fitWallToView(next.walls.find((w) => w.id === next.activeWallId) || next.walls[0] || null);
    showToast('تنظیمات استاندارد پروژه ذخیره شد');
  };

  const hintText = useMemo(() => {
    const map: Record<ToolId, string> = {
      select: 'انتخاب و تراز: درگ خالی = انتخاب گروهی | گره‌های آبی = تغییر دیوار | وسط درب‌ها = ریسایز زوجی',
      wall: 'رسم دیوار: کلیک و ادامه دهید (یا گره‌های آبی را بکشید برای تغییر ابعاد دیوار)',
      'cab-draw': 'کشیدن کابینت: نوع باکس را از پنل راست انتخاب کرده و روی دیوار بکشید',
      fridge: 'درج یخچال: اسکرول روی دیوار = تغییر مدل | کلیک روی کابینت = برش خودکار فضا',
      appliance: `درج ${APPLIANCE_CONFIGS[applianceKind].shortLabel}: اسکرول روی باکس = تغییر نوع | کلیک روی تجهیز قبلی = جایگزینی`,
      opening: `درج ${OPENING_LABELS[openingKind]}: اسکرول روی دیوار = تغییر نوع | کلیک = ثبت`,
      doors: `درب‌گذاری (${doorTargetWidth}cm): اسکرول روی باکس = تعداد/کشو | اسکرول بیرون = زوم | کلیک بیرون = چرخش`,
      pencil: 'مداد اسکلت: اسکرول روی باکس = تعداد طبقه | درز دو درب = دیواره یونیت | وسط دهانه = طبقه',
      skeleton: 'قفل نما: اسکرول روی باکس = تعداد طبقه | مرز دو درب = دیواره یونیت',
      handle: 'دستگیره: کلیک بیرون باکس = چرخش ۹۰° | درگ روی دستگیره = تغییر طول',
      eraser: 'پاک‌کن یکپارچه: حذف دستگیره، طبقه، یونیت، پنجره/درب، تجهیز، درب، باکس یا دیوار خالی',
    };
    return map[tool];
  }, [tool, applianceKind, openingKind, doorTargetWidth]);

  return (
    <div className="w-screen h-screen flex flex-col overflow-hidden bg-slate-50 text-slate-900">
      <TopBar
        canUndo={historyIdx > 0}
        canRedo={historyIdx < history.length - 1}
        doorsLocked={project.doorsLocked}
        onNewProject={handleNewProject}
        onUndo={handleUndo}
        onRedo={handleRedo}
        onApplyPreset={handleApplyPreset}
        onToggleLock={handleToggleLock}
        onZoomFront={(d) =>
          setPxPerCm((v) => +Math.max(0.6, Math.min(5.2, v + d)).toFixed(2))
        }
        onFitWall={() => fitWallToView(activeWall)}
        onOpenSettings={() => setSettingsOpen(true)}
      />

      <div className="flex-1 flex overflow-hidden relative">
        <SideInspector
          collapsed={inspectorCollapsed}
          onToggleCollapse={() => setInspectorCollapsed((c) => !c)}
          activeTool={tool}
          activeWall={activeWall}
          activeBox={activeBox}
          selectedDoor={selectedDoor}
          selectedOpening={selectedOpening}
          multiSelection={project.multiSelection}
          doorsLocked={project.doorsLocked}
          drawBoxKind={drawBoxKind}
          onSelectDrawBoxKind={setDrawBoxKind}
          doorOrient={doorOrient}
          onSetDoorOrient={setDoorOrient}
          doorTargetWidth={doorTargetWidth}
          onSetDoorTargetWidth={setDoorTargetWidth}
          doorVertCount={doorVertCount}
          onSetDoorVertCount={setDoorVertCount}
          drawerPatIdx={drawerPatIdx}
          onSetDrawerPatIdx={setDrawerPatIdx}
          liftPatIdx={liftPatIdx}
          onSetLiftPatIdx={setLiftPatIdx}
          shelfCount={shelfCount}
          onSetShelfCount={setShelfCount}
          handleStyle={handleStyle}
          onSetHandleStyle={(s) => {
            setHandleStyle(s);
            showToast(`نوع دستگیره: ${s === 'simple' ? 'ساده' : s === 'knob' ? 'قارچی' : 'مخفی'}`);
          }}
          handleOrient={handleOrient}
          onSetHandleOrient={setHandleOrient}
          fridgeModel={fridgeModel}
          onSetFridgeModel={setFridgeModel}
          fridgeHasFrame={fridgeHasFrame}
          onSetFridgeHasFrame={setFridgeHasFrame}
          applianceKind={applianceKind}
          onSetApplianceKind={setApplianceKind}
          hoodKind={hoodKind}
          onSetHoodKind={setHoodKind}
          openingKind={openingKind}
          onSetOpeningKind={setOpeningKind}
          openingSwing={openingSwing}
          onSetOpeningSwing={setOpeningSwing}
          onToggleLock={handleToggleLock}
          onSetDoorKind={handleSetDoorKind}
          onDivideEvenly={handleDivideEvenly}
          onEqualizeDoors={handleEqualizeDoors}
          onMirrorBox={handleMirrorBox}
          onAlignBox={handleAlignBox}
          onAddFiller={handleAddFiller}
          onUpdateBoxNumeric={handleUpdateBoxNumeric}
          onDeleteSelectedBox={handleDeleteSelectedBox}
          onUpdateOpeningNumeric={handleUpdateOpeningNumeric}
          onChangeOpeningSwing={handleChangeOpeningSwing}
          onDeleteSelectedOpening={() => {
            if (activeWall && selectedOpening) {
              handleDeleteOpening(activeWall.id, selectedOpening.id);
            }
          }}
          onOptimizeAppliances={handleOptimizeAppliances}
          onBulkDelete={handleBulkDelete}
          onBulkSetDoorKind={handleBulkSetDoorKind}
          onBulkEqualizeDoors={handleBulkEqualizeDoors}
          onClearMultiSelection={() => handleSetMultiSelection(undefined)}
        />

        <main
          ref={workspaceRef}
          className="flex-1 flex flex-col overflow-hidden relative"
          onPointerMove={(e) => {
            if (!splitDragging.current || !workspaceRef.current) return;
            const rect = workspaceRef.current.getBoundingClientRect();
            const pct = ((e.clientY - rect.top) / rect.height) * 100;
            setTopHeightPct(Math.max(18, Math.min(72, pct)));
          }}
          onPointerUp={() => {
            splitDragging.current = false;
          }}
        >
          <div style={{ height: `${topHeightPct}%` }} className="min-h-[110px] shrink-0">
              <PlanCanvas
              walls={project.walls}
              cornerOwners={project.cornerOwners}
              activeWallId={activeWall?.id ?? null}
              activeBoxId={activeBox?.id ?? null}
              selectedOpeningId={project.selectedOpeningId ?? null}
              tool={tool}
              drawBoxKind={drawBoxKind}
              fridgeModel={fridgeModel}
              onFridgeModelChange={setFridgeModel}
              applianceKind={applianceKind}
              onApplianceKindChange={setApplianceKind}
              openingKind={openingKind}
              onOpeningKindChange={setOpeningKind}
              openingSwing={openingSwing}
              hintText={hintText}
              onSelectWall={(wallId, boxId) => {
                const w = project.walls.find((x) => x.id === wallId) || null;
                setProject((p) => ({
                  ...p,
                  activeWallId: wallId,
                  activeBoxId: boxId ?? null,
                  selectedDoorId: null,
                  selectedOpeningId: null,
                  multiSelection: undefined,
                }));
                fitWallToView(w);
              }}
              onSelectOpening={(wallId, openingId) => {
                const w = project.walls.find((x) => x.id === wallId) || null;
                setProject((p) => ({
                  ...p,
                  activeWallId: wallId,
                  activeBoxId: null,
                  selectedDoorId: null,
                  selectedOpeningId: openingId,
                  multiSelection: undefined,
                }));
                if (w && w.id !== activeWall?.id) fitWallToView(w);
              }}
              onFlipActiveWallSide={() =>
                mutateActiveWall((w) => {
                  w.flipSide = w.flipSide === 1 ? -1 : 1;
                }, true)
              }
              onToggleCornerOwner={handleToggleCornerOwner}
              onAddWall={(wall) => {
                const next = cloneProject(project);
                const st = next.settings || DEFAULT_PROJECT_SETTINGS;
                wall.height = st.wallHeightCm;
                const oriented = autoOrientWallsOnAdd(next.walls, wall);
                next.walls.push(oriented);
                next.activeWallId = oriented.id;
                commitState(next, true);
                fitWallToView(oriented);
              }}
              onMoveWallNode={handleMoveWallNode}
              onDeleteWall={(wallId) => {
                const next = cloneProject(project);
                next.walls = next.walls.filter((w) => w.id !== wallId);
                if (next.activeWallId === wallId) {
                  next.activeWallId = next.walls[0]?.id ?? null;
                  next.activeBoxId = next.walls[0]?.boxes[0]?.id ?? null;
                  next.selectedOpeningId = null;
                }
                commitState(next, true);
                showToast('دیوار حذف شد');
              }}
              onDeleteBox={handleDeleteBoxFromPlan}
              onDeleteAppliance={handleDeleteApplianceFromPlan}
              onDeleteOpening={handleDeleteOpening}
              onMoveOpening={handleMoveOpening}
              onCreateBoxesFromSweep={handleCreateBoxesFromSweep}
              onPlaceApplianceFromPlan={handlePlaceAppliance}
              onPlaceFridgeFromPlan={handlePlaceFridge}
              onPlaceOpeningFromPlan={(wallId, offsetX) => handlePlaceOpening(wallId, offsetX)}
              onToast={showToast}
            />
          </div>

          <div
            role="separator"
            aria-label="تغییر ارتفاع پلان و روبرو"
            onPointerDown={(e) => {
              e.preventDefault();
              splitDragging.current = true;
            }}
            className="h-2 bg-slate-100 border-y border-slate-300 cursor-row-resize flex items-center justify-center shrink-0 z-20"
          >
            <div className="w-11 h-1 rounded-full bg-slate-400" />
          </div>

          <FrontCanvas
            wall={activeWall}
            allWalls={project.walls}
            cornerOwners={project.cornerOwners}
            activeBoxId={activeBox?.id ?? null}
            selectedDoorId={project.selectedDoorId}
            selectedOpeningId={project.selectedOpeningId ?? null}
            multiSelection={project.multiSelection}
            tool={tool}
            doorsLocked={project.doorsLocked}
            doorOrient={doorOrient}
            onDoorOrientChange={setDoorOrient}
            doorTargetWidth={doorTargetWidth}
            doorVertCount={doorVertCount}
            onDoorVertCountChange={setDoorVertCount}
            drawerPatIdx={drawerPatIdx}
            onDrawerPatIdxChange={setDrawerPatIdx}
            liftPatIdx={liftPatIdx}
            onLiftPatIdxChange={setLiftPatIdx}
            shelfCount={shelfCount}
            onShelfCountChange={setShelfCount}
            handleStyle={handleStyle}
            handleOrient={handleOrient}
            onHandleOrientChange={setHandleOrient}
            fridgeModel={fridgeModel}
            onFridgeModelChange={setFridgeModel}
            applianceKind={applianceKind}
            onApplianceKindChange={setApplianceKind}
            openingKind={openingKind}
            onOpeningKindChange={setOpeningKind}
            pxPerCm={pxPerCm}
            pan={frontPan}
            onZoomAndPanChange={(nextS, nextPan) => {
              setPxPerCm(nextS);
              setFrontPan(nextPan);
            }}
            onPanChange={setFrontPan}
            onSelectBoxAndDoor={(boxId, doorId) =>
              setProject((p) => ({
                ...p,
                activeBoxId: boxId,
                selectedDoorId: doorId,
                selectedOpeningId: null,
              }))
            }
            onSelectOpening={(openingId) =>
              setProject((p) => ({
                ...p,
                activeBoxId: openingId ? null : p.activeBoxId,
                selectedDoorId: openingId ? null : p.selectedDoorId,
                selectedOpeningId: openingId,
              }))
            }
            onSetMultiSelection={handleSetMultiSelection}
            onBulkDelete={handleBulkDelete}
            onMutateWall={mutateActiveWall}
            onPlaceAppliance={(boxId, desiredOffsetX) => {
              if (activeWall) handlePlaceAppliance(activeWall.id, boxId, desiredOffsetX);
            }}
            onPlaceFridge={(desiredOffsetX) => {
              if (activeWall) handlePlaceFridge(activeWall.id, desiredOffsetX);
            }}
            onPlaceOpening={(desiredOffsetX, desiredElevY) => {
              if (activeWall) handlePlaceOpening(activeWall.id, desiredOffsetX, desiredElevY);
            }}
            onToast={showToast}
          />
        </main>
      </div>

      <BottomDock activeTool={tool} onSelectTool={handleSelectTool} />

      {settingsOpen && (
        <SettingsModal
          settings={project.settings || DEFAULT_PROJECT_SETTINGS}
          onSave={handleSaveSettings}
          onClose={() => setSettingsOpen(false)}
        />
      )}

      {toast && (
        <div
          role="status"
          className="fixed top-14 left-1/2 -translate-x-1/2 bg-slate-900 text-white px-4 py-1.5 rounded-full text-xs font-bold shadow-lg z-50 pointer-events-none"
        >
          {toast}
        </div>
      )}
    </div>
  );
}
