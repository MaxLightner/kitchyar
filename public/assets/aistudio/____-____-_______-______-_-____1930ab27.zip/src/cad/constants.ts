import { ApplianceKind, BoxKind, DrawerPattern, FridgeModel, OpeningKind, ProjectSettings } from './types';

export const SHEET_MM = 16;
export const UNIT_DOUBLE_MM = 32;
export const MIN_DOOR_CM = 30;
export const MAX_DOOR_CM = 60;
export const DEFAULT_DOOR_CM = 60;
export const COUNTERTOP_CM = 4;
export const PLINTH_CM = 10;
export const FRIDGE_FRAME_CM = 2; // 16-20mm side frame panels
export const CORNER_FILLER_CM = 4; // clearance filler so adjacent doors never clash

export const WALL_LOWER_ELEV_CM = 145;
export const WALL_LOWER_HEIGHT_CM = 75; // Top = 220cm (matches tall & over-fridge top)
export const WALL_DOUBLE_LOWER_H_CM = 45; // Lower shallow tier: 145..190cm
export const WALL_DOUBLE_UPPER_ELEV_CM = 190; // Upper deep tier: 190..235cm (Top = 235cm)

export const DEFAULT_PROJECT_SETTINGS: ProjectSettings = {
  wallHeightCm: 265,
  baseHeightCm: 86,
  plinthCm: 10,
  countertopCm: 4,
  wallCabElevCm: 145,
  wallCabHeightCm: 75,
};

export interface FridgeModelConfig {
  id: FridgeModel;
  label: string;
  shortLabel: string;
  width: number;
  depth: number;
  height: number;
}

export const FRIDGE_MODELS: Record<FridgeModel, FridgeModelConfig> = {
  single: {
    id: 'single',
    label: 'معمولی (۷۰cm)',
    shortLabel: 'معمولی',
    width: 70,
    depth: 70,
    height: 185,
  },
  'side-by-side': {
    id: 'side-by-side',
    label: 'ساید بای ساید (۹۲cm)',
    shortLabel: 'ساید',
    width: 92,
    depth: 75,
    height: 185,
  },
  twin: {
    id: 'twin',
    label: 'دوقلو (۱۲۰cm)',
    shortLabel: 'دوقلو',
    width: 120,
    depth: 70,
    height: 185,
  },
};

export const FRIDGE_MODEL_ORDER: FridgeModel[] = ['single', 'side-by-side', 'twin'];

export const APPLIANCE_CONFIGS: Record<
  ApplianceKind,
  { label: string; shortLabel: string; width: number; depth: number }
> = {
  sink: { label: 'سینک (۹۰cm)', shortLabel: 'سینک', width: 90, depth: 50 },
  gas: { label: 'گاز صفحه‌ای (۸۰cm)', shortLabel: 'گاز', width: 80, depth: 52 },
  dishwasher: { label: 'ماشین ظرفشویی (۶۰cm)', shortLabel: 'ظرفشویی', width: 60, depth: 58 },
  washing: { label: 'ماشین لباسشویی (۶۰cm)', shortLabel: 'لباسشویی', width: 60, depth: 58 },
};

export const OPENING_DEFAULTS: Record<
  OpeningKind,
  { label: string; width: number; elevY: number; height: number }
> = {
  window: { label: 'پنجره', width: 120, elevY: 105, height: 120 },
  door: { label: 'درب ورودی / اتاق', width: 90, elevY: 0, height: 210 },
  column: { label: 'ستون / داکت', width: 45, elevY: 0, height: 265 },
};

export const DRAWER_PATTERNS: DrawerPattern[] = [
  { id: '2eq', label: '۲ کشو مساوی', shortLabel: '۲ کشو', ratios: [0.5] },
  { id: '3eq', label: '۳ کشو مساوی', shortLabel: '۳ کشو', ratios: [0.333, 0.667] },
  { id: '3step', label: '۳ کشو پلکانی', shortLabel: 'پلکانی', ratios: [0.22, 0.54] },
  { id: '4eq', label: '۴ کشو مساوی', shortLabel: '۴ کشو', ratios: [0.25, 0.5, 0.75] },
];

export const LIFT_PATTERNS: DrawerPattern[] = [
  { id: '1lift', label: '۱ درب افقی', shortLabel: '۱ افقی', ratios: [] },
  { id: '2lift', label: '۲ درب افقی', shortLabel: '۲ افقی', ratios: [0.5] },
];

export interface BoxPresetConfig {
  name: string;
  height: number;
  depth: number;
  elevY: number;
  plinth: number;
  countertopCm: number;
}

export const BOX_PRESETS: Record<BoxKind, BoxPresetConfig> = {
  base: {
    name: 'زمینی',
    height: 86, // 10 plinth + 72 carcass + 4 countertop
    depth: 60,
    elevY: 0,
    plinth: PLINTH_CM,
    countertopCm: COUNTERTOP_CM,
  },
  wall: {
    name: 'هوایی',
    height: WALL_LOWER_HEIGHT_CM,
    depth: 32,
    elevY: WALL_LOWER_ELEV_CM,
    plinth: 0,
    countertopCm: 0,
  },
  'wall-deep': {
    name: 'هوایی عمق‌دار (ردیف بالا)',
    height: 45,
    depth: 58,
    elevY: WALL_DOUBLE_UPPER_ELEV_CM,
    plinth: 0,
    countertopCm: 0,
  },
  tall: {
    name: 'قدی',
    height: 220, // Matches 145 + 75 wall top!
    depth: 60,
    elevY: 0,
    plinth: PLINTH_CM,
    countertopCm: 0,
  },
  fridge: {
    name: 'یخچال',
    height: 185,
    depth: 70,
    elevY: 0,
    plinth: 0,
    countertopCm: 0,
  },
  closet: {
    name: 'کمد دیواری',
    height: 235,
    depth: 60,
    elevY: 0,
    plinth: 8,
    countertopCm: 0,
  },
};
