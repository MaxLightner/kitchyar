import {
  APPLIANCE_CONFIGS,
  BOX_PRESETS,
  DEFAULT_DOOR_CM,
  DRAWER_PATTERNS,
  FRIDGE_MODELS,
  LIFT_PATTERNS,
  MAX_DOOR_CM,
  MIN_DOOR_CM,
  WALL_DOUBLE_LOWER_H_CM,
  WALL_LOWER_ELEV_CM,
} from './constants';
import { getBoxTier, getCornerBlockedZonesForWall, isBoxIntervalBlocked } from './cornerLogic';
import { findCollidingOpening } from './openingRules';
import {
  ApplianceItem,
  ApplianceKind,
  BlockedZone,
  BoxKind,
  CabinetBox,
  DoorKind,
  DoorUnit,
  FridgeModel,
  Orientation,
  ProjectSettings,
  Wall,
} from './types';

export function uid(prefix = 'id'): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 9)}`;
}

export function createWall(
  name: string,
  x1Cm: number,
  y1Cm: number,
  x2Cm: number,
  y2Cm: number,
  flipSide: 1 | -1 = 1,
  wallHeightCm = 265
): Wall {
  const dx = x2Cm - x1Cm;
  const dy = y2Cm - y1Cm;
  const length = Math.max(40, Math.round(Math.hypot(dx, dy)));
  const angle = +(Math.atan2(dy, dx) * (180 / Math.PI)).toFixed(2);
  return {
    id: uid('wall'),
    name,
    x1Cm,
    y1Cm,
    x2Cm,
    y2Cm,
    length,
    height: wallHeightCm,
    angle,
    flipSide,
    boxes: [],
    appliances: [],
    openings: [],
  };
}

export function createEmptyBox(
  kind: BoxKind,
  offsetX: number,
  width: number,
  opts?: {
    twoDepthWallLower?: boolean;
    hasFridgeFrame?: boolean;
    fridgeModel?: FridgeModel;
    settings?: ProjectSettings;
  }
): CabinetBox {
  const p = BOX_PRESETS[kind] || BOX_PRESETS.base;
  const st = opts?.settings;
  let height = p.height;
  let depth = p.depth;
  let elevY = p.elevY;
  let plinth = p.plinth;
  let countertopCm = p.countertopCm;

  if (kind === 'base' && st) {
    height = st.baseHeightCm;
    plinth = st.plinthCm;
    countertopCm = st.countertopCm;
  } else if (kind === 'wall') {
    if (opts?.twoDepthWallLower) height = WALL_DOUBLE_LOWER_H_CM;
    else if (st) height = st.wallCabHeightCm;
    if (st) elevY = st.wallCabElevCm;
  } else if (kind === 'fridge') {
    const fm = FRIDGE_MODELS[opts?.fridgeModel || 'side-by-side'];
    height = fm.height;
    depth = fm.depth;
  }

  const w = Math.max(30, Math.round(width));
  const doors: DoorUnit[] =
    kind === 'fridge'
      ? [{ id: uid('door'), startCm: 0, widthCm: w, kind: 'fridge', drawerRatios: [] }]
      : [];

  return {
    id: uid('box'),
    name: kind === 'fridge' ? `یخچال ${FRIDGE_MODELS[opts?.fridgeModel || 'side-by-side'].shortLabel}` : p.name,
    type: kind,
    offsetX: Math.round(offsetX),
    elevY,
    width: w,
    height,
    depth,
    plinth,
    countertopCm,
    hasFridgeFrame: kind === 'fridge' ? (opts?.hasFridgeFrame ?? true) : false,
    fridgeModel: kind === 'fridge' ? (opts?.fridgeModel || 'side-by-side') : undefined,
    doors,
    unitDividers: [],
    shelves: [],
    handles: [],
  };
}

/**
 * Returns contiguous unobstructed [startCm, endCm] intervals inside a box (in box-local coordinates)
 * after subtracting existing doors AND any blocked corner zones.
 */
export function getFreeSpansInBox(
  box: CabinetBox,
  blockedZones: BlockedZone[]
): Array<{ startCm: number; endCm: number }> {
  const occupied: Array<[number, number]> = box.doors.map((d) => [
    d.startCm,
    d.startCm + d.widthCm,
  ]);

  // Also treat blocked corner intervals as occupied so doors cannot be placed inside them!
  const boxTier =
    box.type === 'wall'
      ? 'wall-lower'
      : box.type === 'wall-deep'
      ? 'wall-upper'
      : 'lower';

  for (const z of blockedZones) {
    const tierMatches =
      z.tier === boxTier ||
      ((box.type === 'tall' || box.type === 'closet') && z.tier === 'lower');
    if (!tierMatches) continue;
    const localStart = Math.max(0, z.startCm - box.offsetX);
    const localEnd = Math.min(box.width, z.endCm - box.offsetX);
    if (localEnd - localStart > 1) {
      occupied.push([localStart, localEnd]);
    }
  }

  occupied.sort((a, b) => a[0] - b[0]);

  const merged: Array<[number, number]> = [];
  for (const seg of occupied) {
    if (!merged.length || seg[0] > merged[merged.length - 1][1] + 0.1) {
      merged.push([...seg]);
    } else {
      merged[merged.length - 1][1] = Math.max(merged[merged.length - 1][1], seg[1]);
    }
  }

  const free: Array<{ startCm: number; endCm: number }> = [];
  let cursor = 0;
  for (const [s, e] of merged) {
    if (s - cursor >= MIN_DOOR_CM - 0.1) {
      free.push({ startCm: +cursor.toFixed(1), endCm: +s.toFixed(1) });
    }
    cursor = Math.max(cursor, e);
  }
  if (box.width - cursor >= MIN_DOOR_CM - 0.1) {
    free.push({ startCm: +cursor.toFixed(1), endCm: +box.width.toFixed(1) });
  }
  return free;
}

export interface DoorPreviewResult {
  ok: boolean;
  reason?: string;
  replaceSpan?: { startCm: number; endCm: number };
  items: Array<{
    startCm: number;
    widthCm: number;
    kind: DoorKind;
    drawerRatios: number[];
  }>;
}

export interface CabinetUnitInfo {
  startCm: number;
  endCm: number;
  widthCm: number;
  doors: DoorUnit[];
  hasDrawer: boolean;
  hasLift: boolean;
  hingedCount: number;
  canHaveShelves: boolean;
  blockedReason?: string;
}

/**
 * Returns contiguous architectural units inside a box separated by `unitDividers` and corner blind zones.
 * Shelves belong to units (not individual doors). Drawers cannot have internal shelves;
 * multi-door bays (>2 hinged doors or >125cm) require defining unit dividers first.
 */
export function getUnitsInBox(
  box: CabinetBox,
  blockedZones: BlockedZone[]
): CabinetUnitInfo[] {
  const boxTier =
    box.type === 'wall'
      ? 'wall-lower'
      : box.type === 'wall-deep'
      ? 'wall-upper'
      : 'lower';

  const pts = new Set<number>([0, +box.width.toFixed(1)]);
  for (const u of box.unitDividers) {
    if (u > 2 && u < box.width - 2) pts.add(+u.toFixed(1));
  }
  for (const z of blockedZones) {
    const tierMatches =
      z.tier === boxTier ||
      ((box.type === 'tall' || box.type === 'closet') && z.tier === 'lower');
    if (!tierMatches) continue;
    const ls = +(z.startCm - box.offsetX).toFixed(1);
    const le = +(z.endCm - box.offsetX).toFixed(1);
    if (ls > 2 && ls < box.width - 2) pts.add(ls);
    if (le > 2 && le < box.width - 2) pts.add(le);
  }

  const sortedPts = Array.from(pts).sort((a, b) => a - b);
  const deduped: number[] = [];
  for (const p of sortedPts) {
    if (!deduped.length || p - deduped[deduped.length - 1] > 2) {
      deduped.push(p);
    }
  }

  const units: CabinetUnitInfo[] = [];
  for (let i = 0; i < deduped.length - 1; i++) {
    const uStart = deduped[i];
    const uEnd = deduped[i + 1];
    const uWidth = +(uEnd - uStart).toFixed(1);
    if (uWidth < 15) continue;
    if (isBoxIntervalBlocked(box, uStart + 1, uEnd - 1, blockedZones)) continue;

    const unitDoors = box.doors
      .filter((d) => {
        const mid = d.startCm + d.widthCm / 2;
        return mid >= uStart - 0.5 && mid <= uEnd + 0.5;
      })
      .sort((a, b) => a.startCm - b.startCm);

    const hasDrawer = unitDoors.some((d) => d.kind === 'drawer');
    const hasLift = unitDoors.some((d) => d.kind === 'lift');
    const hingedCount = unitDoors.filter((d) => d.kind === 'door').length;

    let canHaveShelves = true;
    let blockedReason: string | undefined;

    if (box.type === 'fridge') {
      canHaveShelves = false;
      blockedReason = 'یخچال طبقه داخلی ندارد';
    } else if (hasDrawer) {
      canHaveShelves = false;
      blockedReason = 'کشو تقسیم‌بندی داخلی (طبقه) نمی‌گیرد';
    } else if (hingedCount >= 3 || (hingedCount >= 1 && uWidth > 125)) {
      canHaveShelves = false;
      blockedReason = 'ابتدا با مداد روی درز بین درب‌ها کلیک کنید تا مرز یونیت مشخص شود (حداکثر ۲ درب در هر یونیت)';
    }

    units.push({
      startCm: uStart,
      endCm: uEnd,
      widthCm: uWidth,
      doors: unitDoors,
      hasDrawer,
      hasLift,
      hingedCount,
      canHaveShelves,
      blockedReason,
    });
  }

  return units;
}

function getBaySpanContainingCursor(
  box: CabinetBox,
  cursorCmInBox: number,
  blockedZones: BlockedZone[]
): { bayStart: number; bayEnd: number } {
  const boxTier =
    box.type === 'wall'
      ? 'wall-lower'
      : box.type === 'wall-deep'
      ? 'wall-upper'
      : 'lower';

  const bounds = [0, box.width, ...box.unitDividers];
  for (const z of blockedZones) {
    const tierMatches =
      z.tier === boxTier ||
      ((box.type === 'tall' || box.type === 'closet') && z.tier === 'lower');
    if (!tierMatches) continue;
    const ls = z.startCm - box.offsetX;
    const le = z.endCm - box.offsetX;
    if (ls > 0 && ls < box.width) bounds.push(ls);
    if (le > 0 && le < box.width) bounds.push(le);
  }
  const sorted = Array.from(new Set(bounds.map((v) => +v.toFixed(1)))).sort((a, b) => a - b);
  for (let i = 0; i < sorted.length - 1; i++) {
    if (cursorCmInBox >= sorted[i] - 0.5 && cursorCmInBox <= sorted[i + 1] + 0.5) {
      return { bayStart: sorted[i], bayEnd: sorted[i + 1] };
    }
  }
  return { bayStart: 0, bayEnd: box.width };
}

function computeShrinkInsertPreview(
  bayStart: number,
  bayEnd: number,
  bayDoors: DoorUnit[],
  cursorCmInBox: number,
  clickedDoor: DoorUnit | undefined
): DoorPreviewResult {
  const bayWidth = +(bayEnd - bayStart).toFixed(1);
  const newCount = bayDoors.length + 1;
  if (newCount * MIN_DOOR_CM > bayWidth + 0.2) {
    return {
      ok: false,
      reason: 'حداقل عرض هر درب ۳۰cm است؛ امکان افزودن درب جدید نیست',
      items: [],
    };
  }

  // Keep existing order and steal deficit down to 30cm starting from the clicked/nearest door
  const widths = bayDoors.map((d) => d.widthCm);
  const existingSum = widths.reduce((a, b) => a + b, 0);
  const freeGap = Math.max(0, +(bayWidth - existingSum).toFixed(1));
  const newDoorW = MIN_DOOR_CM;
  const deficit = Math.max(0, +(newDoorW - freeGap).toFixed(1));

  let anchorIdx = clickedDoor ? bayDoors.indexOf(clickedDoor) : -1;
  if (anchorIdx === -1) {
    let bestDist = Infinity;
    bayDoors.forEach((d, idx) => {
      const dist = Math.abs(cursorCmInBox - (d.startCm + d.widthCm / 2));
      if (dist < bestDist) {
        bestDist = dist;
        anchorIdx = idx;
      }
    });
  }
  if (anchorIdx < 0) anchorIdx = 0;

  let rem = deficit;
  const order = widths
    .map((_, idx) => idx)
    .sort((a, b) => Math.abs(a - anchorIdx) - Math.abs(b - anchorIdx));
  for (const idx of order) {
    if (rem <= 0.05) break;
    const avail = Math.max(0, +(widths[idx] - MIN_DOOR_CM).toFixed(1));
    const take = Math.min(rem, avail);
    widths[idx] = +(widths[idx] - take).toFixed(1);
    rem = +(rem - take).toFixed(1);
  }

  // Insert new door at anchor position (or in the gap side)
  const insertAt = clickedDoor
    ? anchorIdx + 1
    : cursorCmInBox < bayDoors[0].startCm
    ? 0
    : bayDoors.length;

  const newEntries = bayDoors.map((d, idx) => ({
    kind: d.kind,
    drawerRatios: [...d.drawerRatios],
    widthCm: widths[idx],
  }));
  newEntries.splice(insertAt, 0, {
    kind: 'door',
    drawerRatios: [],
    widthCm: newDoorW,
  });

  // Ensure exact bay sum (distribute any leftover freeGap > 0 back if needed, or clamp remainder)
  const used = newEntries.reduce((s, e) => s + e.widthCm, 0);
  const diff = +(bayWidth - used).toFixed(1);
  if (Math.abs(diff) > 0.05) {
    // Only fill leftover gap if bay had no untouched gaps elsewhere (when full bay or tiny sliver)
    newEntries[insertAt].widthCm = +(
      Math.max(MIN_DOOR_CM, Math.min(MAX_DOOR_CM, newEntries[insertAt].widthCm + diff))
    ).toFixed(1);
  }

  let cur = bayStart;
  const items = newEntries.map((ent, idx) => {
    const startCm = +cur.toFixed(1);
    const w =
      idx === newEntries.length - 1
        ? +(bayEnd - startCm).toFixed(1)
        : Math.max(MIN_DOOR_CM, ent.widthCm);
    cur = startCm + w;
    return {
      startCm,
      widthCm: w,
      kind: ent.kind,
      drawerRatios: ent.drawerRatios,
    };
  });

  if (items.some((it) => it.widthCm < MIN_DOOR_CM - 0.1 || it.widthCm > MAX_DOOR_CM + 0.5)) {
    return {
      ok: false,
      reason: 'عرض درب‌ها خارج از بازه مجاز ۳۰ تا ۶۰ سانتی‌متر می‌شود',
      items: [],
    };
  }

  return {
    ok: true,
    replaceSpan: { startCm: bayStart, endCm: bayEnd },
    items,
  };
}

/**
 * Computes the live preview (and placement) for the Door Brush!
 * - Respects MIN_DOOR_CM (30) and MAX_DOOR_CM (60)
 * - Places 60cm doors while room exists; when clicking in tight spaces or full bays,
 *   shrinks neighboring doors in that bay down toward 30cm (refusing if any < 30cm).
 * - Horizontal on base/tall/closet -> Drawers (+ auto unit dividers)
 * - Horizontal on wall/wall-deep -> Horizontal Lift doors (+ auto unit dividers matching door width)
 */
export function computeDoorBrushPreview(
  box: CabinetBox,
  cursorCmInBox: number,
  orient: Orientation,
  verticalCount: number,
  drawerPatternIdx: number,
  liftPatternIdx: number,
  blockedZones: BlockedZone[],
  targetDoorWidthCm: number = DEFAULT_DOOR_CM
): DoorPreviewResult {
  if (box.type === 'fridge') {
    return { ok: false, reason: 'روی یخچال درب جداگانه قرار نمی‌گیرد', items: [] };
  }

  // Check if cursor is inside a corner blind zone
  const blockedAtCursor = isBoxIntervalBlocked(
    box,
    Math.max(0, cursorCmInBox - 1),
    Math.min(box.width, cursorCmInBox + 1),
    blockedZones
  );
  if (blockedAtCursor) {
    return {
      ok: false,
      reason:
        blockedAtCursor.role === 'blind-behind'
          ? `فضای کنج کور (${blockedAtCursor.depthCm}cm) — درب‌گذاری غیرمجاز`
          : `عمق کنج دیوار مجاور (${blockedAtCursor.depthCm}cm) — درب‌گذاری غیرمجاز`,
      items: [],
    };
  }

  // Is cursor over an existing door?
  const existingDoor = box.doors.find(
    (d) => cursorCmInBox >= d.startCm && cursorCmInBox <= d.startCm + d.widthCm
  );

  if (existingDoor) {
    if (orient === 'horizontal') {
      const isWall = box.type === 'wall' || box.type === 'wall-deep';
      if (isWall) {
        const pat = LIFT_PATTERNS[liftPatternIdx % LIFT_PATTERNS.length];
        return {
          ok: true,
          items: [
            {
              startCm: existingDoor.startCm,
              widthCm: existingDoor.widthCm,
              kind: 'lift',
              drawerRatios: [...pat.ratios],
            },
          ],
        };
      } else {
        const pat = DRAWER_PATTERNS[drawerPatternIdx % DRAWER_PATTERNS.length];
        return {
          ok: true,
          items: [
            {
              startCm: existingDoor.startCm,
              widthCm: existingDoor.widthCm,
              kind: 'drawer',
              drawerRatios: [...pat.ratios],
            },
          ],
        };
      }
    }

    // Vertical click on existing door
    if (verticalCount <= 1) {
      // If clicked door >= 60cm, split it directly without touching neighbors
      if (existingDoor.widthCm >= MIN_DOOR_CM * 2) {
        const half = +(existingDoor.widthCm / 2).toFixed(1);
        return {
          ok: true,
          items: [
            { startCm: existingDoor.startCm, widthCm: half, kind: 'door', drawerRatios: [] },
            {
              startCm: +(existingDoor.startCm + half).toFixed(1),
              widthCm: +(existingDoor.widthCm - half).toFixed(1),
              kind: 'door',
              drawerRatios: [],
            },
          ],
        };
      }
      // Otherwise shrink doors in the same unit/bay down to min 30cm to fit a new door!
      const { bayStart, bayEnd } = getBaySpanContainingCursor(box, cursorCmInBox, blockedZones);
      const bayDoors = box.doors
        .filter((d) => {
          const mid = d.startCm + d.widthCm / 2;
          return mid >= bayStart - 0.5 && mid <= bayEnd + 0.5;
        })
        .sort((a, b) => a.startCm - b.startCm);
      return computeShrinkInsertPreview(bayStart, bayEnd, bayDoors, cursorCmInBox, existingDoor);
    }

    const parts = verticalCount;
    const partW = +(existingDoor.widthCm / parts).toFixed(1);
    if (partW < MIN_DOOR_CM) {
      return {
        ok: false,
        reason: `عرض هر درب (${partW}cm) کمتر از حداقل ۳۰cm می‌شود`,
        items: [],
      };
    }
    const items = [];
    for (let i = 0; i < parts; i++) {
      items.push({
        startCm: +(existingDoor.startCm + i * partW).toFixed(1),
        widthCm:
          i === parts - 1
            ? +(existingDoor.widthCm - partW * (parts - 1)).toFixed(1)
            : partW,
        kind: 'door' as DoorKind,
        drawerRatios: [],
      });
    }
    return { ok: true, items };
  }

  // Cursor is in an empty space inside the box -> find free span containing cursor
  const freeSpans = getFreeSpansInBox(box, blockedZones);
  const span = freeSpans.find(
    (sp) => cursorCmInBox >= sp.startCm - 0.5 && cursorCmInBox <= sp.endCm + 0.5
  );

  if (!span) {
    // Check if cursor is in a small (<30cm) sliver next to existing doors inside a bay -> shrink neighbors down to 30cm!
    if (orient === 'vertical' && verticalCount <= 1) {
      const { bayStart, bayEnd } = getBaySpanContainingCursor(box, cursorCmInBox, blockedZones);
      const bayDoors = box.doors
        .filter((d) => {
          const mid = d.startCm + d.widthCm / 2;
          return mid >= bayStart - 0.5 && mid <= bayEnd + 0.5;
        })
        .sort((a, b) => a.startCm - b.startCm);
      if (bayDoors.length > 0) {
        return computeShrinkInsertPreview(bayStart, bayEnd, bayDoors, cursorCmInBox, undefined);
      }
    }
    return {
      ok: false,
      reason: 'فضای خالی با عرض حداقل ۳۰cm در این قسمت وجود ندارد',
      items: [],
    };
  }

  const freeLen = +(span.endCm - span.startCm).toFixed(1);
  if (freeLen < MIN_DOOR_CM) {
    return {
      ok: false,
      reason: 'فضای خالی کمتر از ۳۰ سانتی‌متر است',
      items: [],
    };
  }

  const desiredW = Math.max(MIN_DOOR_CM, Math.min(MAX_DOOR_CM, Math.round(targetDoorWidthCm)));

  if (orient === 'horizontal') {
    const w = Math.min(desiredW, freeLen);
    let start = Math.max(
      span.startCm,
      Math.min(span.endCm - w, Math.round((cursorCmInBox - w / 2) / 5) * 5)
    );
    if (cursorCmInBox - span.startCm < w * 0.65) start = span.startCm;
    else if (span.endCm - cursorCmInBox < w * 0.65) start = +(span.endCm - w).toFixed(1);

    const isWall = box.type === 'wall' || box.type === 'wall-deep';
    if (isWall) {
      const pat = LIFT_PATTERNS[liftPatternIdx % LIFT_PATTERNS.length];
      return {
        ok: true,
        items: [{ startCm: +start.toFixed(1), widthCm: +w.toFixed(1), kind: 'lift', drawerRatios: [...pat.ratios] }],
      };
    } else {
      const pat = DRAWER_PATTERNS[drawerPatternIdx % DRAWER_PATTERNS.length];
      return {
        ok: true,
        items: [{ startCm: +start.toFixed(1), widthCm: +w.toFixed(1), kind: 'drawer', drawerRatios: [...pat.ratios] }],
      };
    }
  }

  // Vertical brush in empty space — directly respects targetDoorWidthCm (30..60cm)!
  if (verticalCount <= 1) {
    const w = Math.min(desiredW, freeLen);
    let start = Math.max(
      span.startCm,
      Math.min(span.endCm - w, Math.round((cursorCmInBox - w / 2) / 5) * 5)
    );
    if (cursorCmInBox - span.startCm < w * 0.65) start = span.startCm;
    else if (span.endCm - cursorCmInBox < w * 0.65) start = +(span.endCm - w).toFixed(1);

    if (freeLen <= desiredW) {
      start = span.startCm;
    }

    return {
      ok: true,
      items: [{ startCm: +start.toFixed(1), widthCm: +w.toFixed(1), kind: 'door', drawerRatios: [] }],
    };
  }

  // Multi-door placement in empty span
  const count = verticalCount;
  const maxSpanForCount = Math.min(freeLen, count * MAX_DOOR_CM);
  const eachW = +(maxSpanForCount / count).toFixed(1);
  if (eachW < MIN_DOOR_CM) {
    return {
      ok: false,
      reason: `برای ${count} درب عرض هر لنگه (${eachW}cm) کمتر از ۳۰cm می‌شود`,
      items: [],
    };
  }

  let start = span.startCm;
  if (freeLen > maxSpanForCount) {
    start = Math.max(
      span.startCm,
      Math.min(span.endCm - maxSpanForCount, Math.round((cursorCmInBox - maxSpanForCount / 2) / 5) * 5)
    );
    if (cursorCmInBox - span.startCm < maxSpanForCount * 0.5) start = span.startCm;
  }

  const items = [];
  for (let i = 0; i < count; i++) {
    items.push({
      startCm: +(start + i * eachW).toFixed(1),
      widthCm: i === count - 1 ? +(maxSpanForCount - eachW * (count - 1)).toFixed(1) : eachW,
      kind: 'door' as DoorKind,
      drawerRatios: [],
    });
  }
  return { ok: true, items };
}

function ensureUnitDividersForRange(box: CabinetBox, startCm: number, endCm: number) {
  if (startCm > 2 && !box.unitDividers.some((u) => Math.abs(u - startCm) < 2)) {
    box.unitDividers.push(+startCm.toFixed(1));
  }
  if (endCm < box.width - 2 && !box.unitDividers.some((u) => Math.abs(u - endCm) < 2)) {
    box.unitDividers.push(+endCm.toFixed(1));
  }
  box.unitDividers.sort((a, b) => a - b);
}

/**
 * Applies a computed Door Brush preview onto the box:
 * - Supports bay shrinking/replacement (`replaceSpan`)
 * - Automatically places unit dividers for drawers and horizontal lift doors
 */
export function applyDoorBrushPreview(
  box: CabinetBox,
  cursorCmInBox: number,
  preview: DoorPreviewResult
): { ok: boolean; selectedDoorId: string | null; message?: string } {
  if (!preview.ok || !preview.items.length) {
    return { ok: false, selectedDoorId: null, message: preview.reason };
  }

  if (preview.replaceSpan) {
    const { startCm, endCm } = preview.replaceSpan;
    const removedIds = new Set(
      box.doors
        .filter((d) => {
          const mid = d.startCm + d.widthCm / 2;
          return mid >= startCm - 0.5 && mid <= endCm + 0.5;
        })
        .map((d) => d.id)
    );
    box.doors = box.doors.filter((d) => !removedIds.has(d.id));
    box.handles = box.handles.filter((h) => !removedIds.has(h.doorId));

    const created: DoorUnit[] = preview.items.map((it) => ({
      id: uid('door'),
      startCm: it.startCm,
      widthCm: it.widthCm,
      kind: it.kind,
      drawerRatios: [...it.drawerRatios],
    }));
    box.doors.push(...created);
    box.doors.sort((a, b) => a.startCm - b.startCm);
    return { ok: true, selectedDoorId: created[0]?.id ?? null };
  }

  const existingDoor = box.doors.find(
    (d) => cursorCmInBox >= d.startCm && cursorCmInBox <= d.startCm + d.widthCm
  );

  if (existingDoor) {
    const idx = box.doors.indexOf(existingDoor);
    if (preview.items.length === 1 && (preview.items[0].kind === 'drawer' || preview.items[0].kind === 'lift')) {
      existingDoor.kind = preview.items[0].kind;
      existingDoor.drawerRatios = [...preview.items[0].drawerRatios];
      box.handles = box.handles.filter((h) => h.doorId !== existingDoor.id);
      ensureUnitDividersForRange(box, existingDoor.startCm, existingDoor.startCm + existingDoor.widthCm);
      return { ok: true, selectedDoorId: existingDoor.id };
    }
    const created: DoorUnit[] = preview.items.map((it) => ({
      id: uid('door'),
      startCm: it.startCm,
      widthCm: it.widthCm,
      kind: it.kind,
      drawerRatios: [...it.drawerRatios],
    }));
    box.doors.splice(idx, 1, ...created);
    box.handles = box.handles.filter((h) => h.doorId !== existingDoor.id);
    return { ok: true, selectedDoorId: created[0].id };
  }

  const created: DoorUnit[] = preview.items.map((it) => ({
    id: uid('door'),
    startCm: it.startCm,
    widthCm: it.widthCm,
    kind: it.kind,
    drawerRatios: [...it.drawerRatios],
  }));
  box.doors.push(...created);
  box.doors.sort((a, b) => a.startCm - b.startCm);
  for (const c of created) {
    if (c.kind === 'drawer' || c.kind === 'lift') {
      ensureUnitDividersForRange(box, c.startCm, c.startCm + c.widthCm);
    }
  }
  return { ok: true, selectedDoorId: created[0].id };
}

/**
 * Erases a door using the strict 30-60cm merge rule:
 * Merges into an adjacent door ONLY if they touch AND combined width <= 60cm;
 * otherwise leaves the space empty.
 */
export function eraseDoorWithRule(box: CabinetBox, doorId: string): string {
  box.doors.sort((a, b) => a.startCm - b.startCm);
  const idx = box.doors.findIndex((d) => d.id === doorId);
  if (idx === -1) return '';

  const door = box.doors[idx];
  const prev = idx > 0 ? box.doors[idx - 1] : null;
  const next = idx < box.doors.length - 1 ? box.doors[idx + 1] : null;
  let msg = '';

  if (
    prev &&
    Math.abs(prev.startCm + prev.widthCm - door.startCm) < 1 &&
    prev.widthCm + door.widthCm <= MAX_DOOR_CM
  ) {
    prev.widthCm = +(prev.widthCm + door.widthCm).toFixed(1);
    box.doors.splice(idx, 1);
    msg = `درب با درب کناری ادغام شد (${prev.widthCm} cm)`;
  } else if (
    next &&
    Math.abs(door.startCm + door.widthCm - next.startCm) < 1 &&
    next.widthCm + door.widthCm <= MAX_DOOR_CM
  ) {
    next.startCm = door.startCm;
    next.widthCm = +(next.widthCm + door.widthCm).toFixed(1);
    box.doors.splice(idx, 1);
    msg = `درب با درب کناری ادغام شد (${next.widthCm} cm)`;
  } else {
    box.doors.splice(idx, 1);
    msg = 'درب حذف شد (ادغام بیش از ۶۰cm می‌شد؛ فضا خالی ماند)';
  }

  box.handles = box.handles.filter((h) => h.doorId !== door.id);
  return msg;
}

/**
 * Clamps internal doors, dividers, and shelves when a box is resized so nothing ever leaks outside.
 */
export function clampBoxInternalsAfterResize(box: CabinetBox): void {
  box.doors = box.doors
    .filter((d) => d.startCm < box.width - MIN_DOOR_CM + 1)
    .map((d) => {
      const maxW = +(box.width - d.startCm).toFixed(1);
      return {
        ...d,
        widthCm: Math.min(d.widthCm, maxW),
      };
    })
    .filter((d) => d.widthCm >= MIN_DOOR_CM - 0.5 || box.type === 'fridge');

  box.unitDividers = box.unitDividers.filter((u) => u > 2 && u < box.width - 2);
  box.shelves = box.shelves
    .filter((s) => s.startCm < box.width - 5)
    .map((s) => ({ ...s, endCm: Math.min(s.endCm, box.width) }));
}

/**
 * Equalizes all doors inside a box (or active free spans) within 30..60cm.
 */
export function equalizeDoorsInBox(
  box: CabinetBox,
  blockedZones: BlockedZone[]
): { ok: boolean; message: string } {
  if (box.doors.length < 2) {
    return { ok: false, message: 'حداقل ۲ درب برای مرتب‌سازی نیاز است' };
  }
  box.doors.sort((a, b) => a.startCm - b.startCm);
  const totalW = box.doors.reduce((s, d) => s + d.widthCm, 0);
  const eqW = +(totalW / box.doors.length).toFixed(1);
  if (eqW < MIN_DOOR_CM || eqW > MAX_DOOR_CM) {
    return {
      ok: false,
      message: `عرض مساوی (${eqW}cm) خارج از بازه مجاز ۳۰ تا ۶۰ سانتی‌متر است`,
    };
  }

  // Respect corner blind zone start if box starts at 0 and has blind zone
  let startCursor = box.doors[0].startCm;
  for (const z of blockedZones) {
    if (z.startCm <= box.offsetX && z.endCm > box.offsetX) {
      startCursor = Math.max(startCursor, z.endCm - box.offsetX);
    }
  }

  if (startCursor + totalW > box.width + 0.5) {
    startCursor = box.doors[0].startCm;
  }

  let cur = startCursor;
  box.doors.forEach((d, i) => {
    d.startCm = +cur.toFixed(1);
    d.widthCm =
      i === box.doors.length - 1
        ? +(totalW - eqW * (box.doors.length - 1)).toFixed(1)
        : eqW;
    cur += eqW;
  });

  return { ok: true, message: `درب‌ها مساوی و مرتب شدند (${eqW} cm)` };
}

/**
 * Mirrors doors, dividers, shelves, and handles left-to-right inside the box.
 */
export function mirrorBoxLayout(box: CabinetBox): void {
  box.doors.forEach((d) => {
    d.startCm = +(box.width - (d.startCm + d.widthCm)).toFixed(1);
  });
  box.doors.sort((a, b) => a.startCm - b.startCm);

  box.unitDividers = box.unitDividers
    .map((u) => +(box.width - u).toFixed(1))
    .sort((a, b) => a - b);

  box.shelves.forEach((sh) => {
    const ns = +(box.width - sh.endCm).toFixed(1);
    const ne = +(box.width - sh.startCm).toFixed(1);
    sh.startCm = ns;
    sh.endCm = ne;
  });

  box.handles.forEach((h) => {
    h.xRatio = +(1 - h.xRatio).toFixed(2);
  });
}

/**
 * Places a kitchen appliance onto a base box:
 * - Clicking directly on an existing appliance replaces it cleanly (e.g., sink -> gas)
 * - Clicking elsewhere adds another appliance without overlapping
 * - Dishwasher / washing snaps flush to sink or edges to avoid <30cm dead slivers
 */
export function placeApplianceWithCabinetRules(
  wall: Wall,
  allWalls: Wall[],
  kind: ApplianceKind,
  targetBox: CabinetBox,
  desiredOffsetX: number,
  cornerOwners: Record<string, string>,
  hoodKind: 'hidden' | 'chimney' = 'hidden'
): { ok: boolean; appliance?: ApplianceItem; replaced?: boolean; message: string } {
  const cfg = APPLIANCE_CONFIGS[kind];
  const width = cfg.width;
  const blocked = getCornerBlockedZonesForWall(wall, allWalls, cornerOwners);

  let minX = targetBox.offsetX;
  let maxX = targetBox.offsetX + targetBox.width - width;

  for (const z of blocked) {
    if (z.tier !== 'lower') continue;
    if (z.startCm <= minX && z.endCm > minX) {
      minX = Math.max(minX, z.endCm);
    }
    if (z.endCm >= targetBox.offsetX + targetBox.width && z.startCm < targetBox.offsetX + targetBox.width) {
      maxX = Math.min(maxX, z.startCm - width);
    }
  }

  if (maxX < minX) {
    return {
      ok: false,
      message: 'فضای کافی بیرون از محدوده کنج برای نصب تجهیز وجود ندارد',
    };
  }

  const desiredClamped = Math.max(minX, Math.min(maxX, Math.round(desiredOffsetX / 5) * 5));
  const clickCenter = desiredOffsetX + width / 2;

  // Check if the user clicked directly over an existing appliance -> replace it cleanly!
  const directHit = wall.appliances.find(
    (other) => clickCenter >= other.offsetX && clickCenter <= other.offsetX + other.width
  );

  let replaced = false;
  if (directHit) {
    replaced = true;
    const oldStart = +(directHit.offsetX - targetBox.offsetX).toFixed(1);
    const oldEnd = +(oldStart + directHit.width).toFixed(1);
    wall.appliances = wall.appliances.filter((a) => a.id !== directHit.id);
    targetBox.doors = targetBox.doors.filter(
      (d) => d.startCm + d.widthCm <= oldStart + 1 || d.startCm >= oldEnd - 1
    );
    targetBox.unitDividers = targetBox.unitDividers.filter(
      (u) => Math.abs(u - oldStart) > 1.5 && Math.abs(u - oldEnd) > 1.5
    );
  }

  const overlapsAny = (x: number) =>
    wall.appliances.some((other) => x < other.offsetX + other.width - 1 && x + width > other.offsetX + 1);

  let offsetX = desiredClamped;

  // Smart snap for dishwasher / washing machine: anchor near sink or avoid <30cm dead slivers
  if (!replaced && (kind === 'dishwasher' || kind === 'washing')) {
    const sink = wall.appliances.find((a) => a.kind === 'sink');
    if (sink) {
      const rightOfSink = sink.offsetX + sink.width;
      const leftOfSink = sink.offsetX - width;
      if (Math.abs(offsetX - rightOfSink) <= 25 && rightOfSink <= maxX && !overlapsAny(rightOfSink)) {
        offsetX = rightOfSink;
      } else if (Math.abs(offsetX - leftOfSink) <= 25 && leftOfSink >= minX && !overlapsAny(leftOfSink)) {
        offsetX = leftOfSink;
      }
    }
    const leftGap = offsetX - minX;
    if (leftGap > 0 && leftGap < MIN_DOOR_CM) {
      if (leftGap < 18 && !overlapsAny(minX)) offsetX = minX;
      else if (minX + MIN_DOOR_CM <= maxX && !overlapsAny(minX + MIN_DOOR_CM)) offsetX = minX + MIN_DOOR_CM;
    }
    const rightGap = maxX - offsetX;
    if (rightGap > 0 && rightGap < MIN_DOOR_CM) {
      if (rightGap < 18 && !overlapsAny(maxX)) offsetX = maxX;
      else if (maxX - MIN_DOOR_CM >= minX && !overlapsAny(maxX - MIN_DOOR_CM)) offsetX = maxX - MIN_DOOR_CM;
    }
  }

  if (overlapsAny(offsetX)) {
    let found: number | null = null;
    for (let step = 5; step <= maxX - minX; step += 5) {
      if (desiredClamped + step <= maxX && !overlapsAny(desiredClamped + step)) {
        found = desiredClamped + step;
        break;
      }
      if (desiredClamped - step >= minX && !overlapsAny(desiredClamped - step)) {
        found = desiredClamped - step;
        break;
      }
    }
    if (found === null) {
      return {
        ok: false,
        message: 'فضای خالی کافی روی این باکس نیست — جای دیگری انتخاب کنید',
      };
    }
    offsetX = found;
  }

  // When replacing a 90cm sink with 80cm gas (etc.), keep centered inside the old slot cleanly if flush
  if (replaced && directHit && offsetX + width <= maxX) {
    offsetX = Math.max(minX, Math.min(maxX, directHit.offsetX));
  }

  const localStart = +(offsetX - targetBox.offsetX).toFixed(1);
  const localEnd = +(localStart + width).toFixed(1);

  targetBox.doors = targetBox.doors.filter(
    (d) => d.startCm + d.widthCm <= localStart + 1 || d.startCm >= localEnd - 1
  );

  if (localStart > 2 && !targetBox.unitDividers.includes(localStart)) {
    targetBox.unitDividers.push(localStart);
  }
  if (localEnd < targetBox.width - 2 && !targetBox.unitDividers.includes(localEnd)) {
    targetBox.unitDividers.push(localEnd);
  }
  targetBox.unitDividers.sort((a, b) => a - b);

  if (kind === 'sink') {
    const half = +(width / 2).toFixed(1);
    targetBox.doors.push(
      { id: uid('door'), startCm: localStart, widthCm: half, kind: 'door', drawerRatios: [] },
      { id: uid('door'), startCm: +(localStart + half).toFixed(1), widthCm: +(width - half).toFixed(1), kind: 'door', drawerRatios: [] }
    );
  } else if (kind === 'gas') {
    targetBox.doors.push({
      id: uid('door'),
      startCm: localStart,
      widthCm: width,
      kind: 'drawer',
      drawerRatios: [0.22, 0.54],
    });
  }
  targetBox.doors.sort((a, b) => a.startCm - b.startCm);

  const app: ApplianceItem = {
    id: uid('app'),
    kind,
    offsetX,
    width,
    hoodKind: kind === 'gas' ? hoodKind : undefined,
  };
  wall.appliances.push(app);

  const msgMap: Record<ApplianceKind, string> = {
    sink: replaced ? 'تجهیز با سینک (۲ درب) جایگزین شد' : 'سینک همراه با یونیت دو درب اختصاصی نصب شد',
    gas: replaced ? 'تجهیز با گاز (کشو پلکانی) جایگزین شد' : 'گاز همراه با کشوهای پلکانی زیر آن نصب شد',
    dishwasher: replaced ? 'تجهیز با ماشین ظرفشویی ۶۰cm جایگزین شد' : 'فضای ۶۰cm ماشین ظرفشویی زیر صفحه ثبت شد',
    washing: replaced ? 'تجهیز با ماشین لباسشویی ۶۰cm جایگزین شد' : 'فضای ۶۰cm ماشین لباسشویی زیر صفحه ثبت شد',
  };

  return {
    ok: true,
    appliance: app,
    replaced,
    message: msgMap[kind],
  };
}

/**
 * Optimizes positions of loose 60cm built-in appliances (dishwasher/washing) inside a base box:
 * anchors them cleanly next to a sink or box edges so leftover empty gaps aren't stuck below 30cm!
 */
export function optimizeBoxWithAppliances(
  wall: Wall,
  allWalls: Wall[],
  box: CabinetBox,
  cornerOwners: Record<string, string>
): { ok: boolean; message: string } {
  const blocked = getCornerBlockedZonesForWall(wall, allWalls, cornerOwners);
  let minX = box.offsetX;
  let maxX = box.offsetX + box.width;

  for (const z of blocked) {
    if (z.tier !== 'lower') continue;
    if (z.startCm <= minX && z.endCm > minX) minX = Math.max(minX, z.endCm);
    if (z.endCm >= maxX && z.startCm < maxX) maxX = Math.min(maxX, z.startCm);
  }

  const boxApps = wall.appliances
    .filter((a) => a.offsetX >= box.offsetX - 1 && a.offsetX + a.width <= box.offsetX + box.width + 1)
    .sort((a, b) => a.offsetX - b.offsetX);

  const looseApps = boxApps.filter((a) => a.kind === 'dishwasher' || a.kind === 'washing');
  if (!looseApps.length) {
    return { ok: false, message: 'ظرفشویی یا لباسشویی روی این باکس وجود ندارد' };
  }

  const fixedApps = boxApps.filter((a) => a.kind === 'sink' || a.kind === 'gas');
  const sink = fixedApps.find((a) => a.kind === 'sink');

  // Remove loose apps temporarily and clear their old dividers
  for (const la of looseApps) {
    const ls = +(la.offsetX - box.offsetX).toFixed(1);
    const le = +(ls + la.width).toFixed(1);
    box.unitDividers = box.unitDividers.filter(
      (u) => Math.abs(u - ls) > 1.5 && Math.abs(u - le) > 1.5
    );
  }

  // Collect free continuous spans around fixed apps inside [minX, maxX]
  const occupied = fixedApps.map((a) => [a.offsetX, a.offsetX + a.width] as [number, number]).sort((a, b) => a[0] - b[0]);
  const freeSpans: Array<{ start: number; end: number }> = [];
  let cur = minX;
  for (const [s, e] of occupied) {
    if (s - cur >= 60) freeSpans.push({ start: cur, end: s });
    cur = Math.max(cur, e);
  }
  if (maxX - cur >= 60) freeSpans.push({ start: cur, end: maxX });

  for (const la of looseApps) {
    // Prefer a span touching sink edge first, else widest span
    let targetSpan =
      (sink &&
        freeSpans.find(
          (sp) =>
            sp.end - sp.start >= la.width &&
            (Math.abs(sp.start - (sink.offsetX + sink.width)) < 2 || Math.abs(sp.end - sink.offsetX) < 2)
        )) ||
      freeSpans
        .filter((sp) => sp.end - sp.start >= la.width)
        .sort((a, b) => b.end - b.start - (a.end - a.start))[0];

    if (!targetSpan) continue;

    // Anchor flush to sink edge if touching sink, else flush to left/right edge of span
    let newX = targetSpan.start;
    if (sink && Math.abs(targetSpan.end - sink.offsetX) < 2) {
      newX = targetSpan.end - la.width;
      targetSpan.end = newX;
    } else {
      targetSpan.start += la.width;
    }

    la.offsetX = newX;
    const ls = +(newX - box.offsetX).toFixed(1);
    const le = +(ls + la.width).toFixed(1);
    box.doors = box.doors.filter((d) => d.startCm + d.widthCm <= ls + 1 || d.startCm >= le - 1);
    if (ls > 2 && !box.unitDividers.includes(ls)) box.unitDividers.push(ls);
    if (le < box.width - 2 && !box.unitDividers.includes(le)) box.unitDividers.push(le);
  }

  box.unitDividers.sort((a, b) => a - b);
  return { ok: true, message: 'جای ماشین ظرفشویی/لباسشویی بدون پرتی فضا بهینه‌سازی شد' };
}

function carveBoxAroundInterval(
  box: CabinetBox,
  cutStart: number,
  cutEnd: number
): CabinetBox[] {
  const bStart = box.offsetX;
  const bEnd = box.offsetX + box.width;
  if (cutEnd <= bStart + 1 || cutStart >= bEnd - 1) return [box];

  const out: CabinetBox[] = [];
  // Left remainder
  const leftW = Math.round(cutStart - bStart);
  if (leftW >= MIN_DOOR_CM) {
    const leftCopy: CabinetBox = JSON.parse(JSON.stringify(box));
    leftCopy.width = leftW;
    clampBoxInternalsAfterResize(leftCopy);
    out.push(leftCopy);
  }

  // Right remainder
  const rightW = Math.round(bEnd - cutEnd);
  if (rightW >= MIN_DOOR_CM) {
    const shift = Math.round(cutEnd - bStart);
    const rightCopy: CabinetBox = JSON.parse(JSON.stringify(box));
    rightCopy.id = uid('box');
    rightCopy.offsetX = Math.round(cutEnd);
    rightCopy.width = rightW;
    rightCopy.doors = rightCopy.doors
      .map((d) => ({ ...d, startCm: +(d.startCm - shift).toFixed(1) }))
      .filter((d) => d.startCm >= -0.5);
    rightCopy.unitDividers = rightCopy.unitDividers
      .map((u) => +(u - shift).toFixed(1))
      .filter((u) => u > 2 && u < rightW - 2);
    rightCopy.shelves = rightCopy.shelves
      .map((s) => ({
        ...s,
        startCm: Math.max(0, +(s.startCm - shift).toFixed(1)),
        endCm: Math.min(rightW, +(s.endCm - shift).toFixed(1)),
      }))
      .filter((s) => s.endCm - s.startCm >= 15);
    clampBoxInternalsAfterResize(rightCopy);
    out.push(rightCopy);
  }
  return out;
}

/**
 * Places a Fridge anywhere along a wall that has backing wall and no door/column clash.
 * If existing base/wall cabinets sit there, automatically carves/splits them around the fridge!
 */
export function placeFridgeOnWall(
  wall: Wall,
  allWalls: Wall[],
  model: FridgeModel,
  desiredOffsetX: number,
  cornerOwners: Record<string, string>,
  hasFrame = true,
  settings?: ProjectSettings
): { ok: boolean; fridgeId?: string; carved?: boolean; message: string } {
  const cfg = FRIDGE_MODELS[model];
  const width = cfg.width;
  const blocked = getCornerBlockedZonesForWall(wall, allWalls, cornerOwners);

  let offsetX = Math.max(0, Math.min(wall.length - width, Math.round(desiredOffsetX / 5) * 5));

  for (const z of blocked) {
    if (z.tier !== 'lower') continue;
    if (offsetX < z.endCm && offsetX + width > z.startCm) {
      if (z.startCm <= 2) offsetX = Math.max(offsetX, z.endCm);
      else offsetX = Math.min(offsetX, z.startCm - width);
    }
  }
  offsetX = Math.max(0, Math.min(wall.length - width, offsetX));

  if (offsetX < 0 || offsetX + width > wall.length) {
    return { ok: false, message: `فضای دیوار برای یخچال ${cfg.label} کافی نیست` };
  }

  const collidingOp = findCollidingOpening(wall, offsetX, offsetX + width, 0, cfg.height);
  if (collidingOp) {
    return { ok: false, message: 'یخچال با پنجره، درب یا ستون دیوار تداخل دارد' };
  }

  const cutStart = offsetX;
  const cutEnd = offsetX + width;

  if (
    wall.boxes.some(
      (b) => b.type === 'fridge' && cutStart < b.offsetX + b.width - 1 && cutEnd > b.offsetX + 1
    )
  ) {
    return {
      ok: false,
      message: 'در این محل قبلاً یخچال قرار دارد (ابتدا با پاک‌کن حذف کنید)',
    };
  }

  // Carve / split any overlapping existing cabinets cleanly!
  let carved = false;
  const nextBoxes: CabinetBox[] = [];
  for (const b of wall.boxes) {
    const overlapsHoriz = cutStart < b.offsetX + b.width - 1 && cutEnd > b.offsetX + 1;
    if (!overlapsHoriz) {
      nextBoxes.push(b);
      continue;
    }
    carved = true;
    nextBoxes.push(...carveBoxAroundInterval(b, cutStart, cutEnd));
  }
  wall.boxes = nextBoxes;

  // Remove any appliances trapped in the carved fridge span
  wall.appliances = wall.appliances.filter(
    (a) => a.offsetX + a.width <= cutStart + 1 || a.offsetX >= cutEnd - 1
  );

  const fridge = createEmptyBox('fridge', offsetX, width, {
    hasFridgeFrame: hasFrame,
    fridgeModel: model,
    settings,
  });
  wall.boxes.push(fridge);

  const topAlign = getWallTopAlignmentCm(wall);
  const overH = Math.max(30, topAlign - fridge.height);
  const over = createEmptyBox('wall-deep', offsetX, width, { settings });
  over.name = 'بالای یخچال';
  over.elevY = fridge.height;
  over.height = overH;
  over.doors = [
    {
      id: uid('door'),
      startCm: 0,
      widthCm: fridge.width,
      kind: 'lift',
      drawerRatios: [],
    },
  ];
  wall.boxes.push(over);

  return {
    ok: true,
    fridgeId: fridge.id,
    carved,
    message: carved
      ? `یخچال ${cfg.label} درج شد و کابینت‌های محل آن خودکار برش خوردند`
      : `یخچال ${cfg.label} همراه با کابینت بالا اضافه شد`,
  };
}

/**
 * Checks if a fridge box has adjacent cabinets on either side so it gets enclosure frames,
 * and ensures an over-fridge horizontal cabinet aligns with the wall cabinet top!
 */
export function getWallTopAlignmentCm(wall: Wall): number {
  const wallCabs = wall.boxes.filter(
    (b) => b.type === 'wall' || b.type === 'wall-deep' || b.type === 'tall'
  );
  if (!wallCabs.length) return WALL_LOWER_ELEV_CM + BOX_PRESETS.wall.height; // 220cm
  return Math.max(...wallCabs.map((b) => b.elevY + b.height));
}

export function doesFridgeTouchCabinet(wall: Wall, fridge: CabinetBox): boolean {
  return wall.boxes.some((other) => {
    if (other.id === fridge.id) return false;
    const gapLeft = Math.abs(other.offsetX + other.width - fridge.offsetX);
    const gapRight = Math.abs(fridge.offsetX + fridge.width - other.offsetX);
    return gapLeft <= 6 || gapRight <= 6;
  });
}

/**
 * Resizes a door inside a box while preventing overlap with neighbors and staying in 30..60cm
 */
export function resizeDoorSafely(
  box: CabinetBox,
  doorId: string,
  newWidthCm: number,
  blockedZones: BlockedZone[]
): number {
  const sorted = [...box.doors].sort((a, b) => a.startCm - b.startCm);
  const idx = sorted.findIndex((d) => d.id === doorId);
  if (idx === -1) return newWidthCm;

  const door = sorted[idx];
  const oldRightEdge = +(door.startCm + door.widthCm).toFixed(1);
  const nextDoor = idx < sorted.length - 1 ? sorted[idx + 1] : null;

  let maxRight = box.width;
  if (nextDoor) maxRight = Math.min(maxRight, nextDoor.startCm);

  const boxTier =
    box.type === 'wall'
      ? 'wall-lower'
      : box.type === 'wall-deep'
      ? 'wall-upper'
      : 'lower';
  for (const z of blockedZones) {
    const tierMatches =
      z.tier === boxTier ||
      ((box.type === 'tall' || box.type === 'closet') && z.tier === 'lower');
    if (!tierMatches) continue;
    const localStart = z.startCm - box.offsetX;
    if (localStart >= door.startCm + MIN_DOOR_CM - 1) {
      maxRight = Math.min(maxRight, localStart);
    }
  }

  const maxAllowedW = Math.min(
    door.kind === 'drawer' ? 90 : MAX_DOOR_CM,
    Math.max(MIN_DOOR_CM, maxRight - door.startCm)
  );
  const clamped = Math.max(MIN_DOOR_CM, Math.min(maxAllowedW, Math.round(newWidthCm)));
  door.widthCm = clamped;

  const newRightEdge = +(door.startCm + clamped).toFixed(1);
  box.unitDividers = box.unitDividers
    .map((u) => (Math.abs(u - oldRightEdge) < 2 ? newRightEdge : u))
    .filter((u) => u > 2 && u < box.width - 2);

  return clamped;
}

/**
 * Coupled seam resize: drags the seam between `leftDoorId` and its immediately adjacent right neighbor
 * so widening one shrinks the neighbor by the exact same amount (within 30..60cm bounds)!
 */
export function resizeDoorSeamCoupled(
  box: CabinetBox,
  leftDoorId: string,
  deltaCm: number
): number {
  const sorted = [...box.doors].sort((a, b) => a.startCm - b.startCm);
  const idx = sorted.findIndex((d) => d.id === leftDoorId);
  if (idx === -1 || idx >= sorted.length - 1) return 0;

  const left = sorted[idx];
  const right = sorted[idx + 1];
  const seamOld = +(left.startCm + left.widthCm).toFixed(1);
  if (Math.abs(right.startCm - seamOld) > 1.5) return 0;

  const leftMax = left.kind === 'drawer' ? 90 : MAX_DOOR_CM;
  const rightMax = right.kind === 'drawer' ? 90 : MAX_DOOR_CM;

  const minDelta = Math.max(MIN_DOOR_CM - left.widthCm, right.widthCm - rightMax);
  const maxDelta = Math.min(leftMax - left.widthCm, right.widthCm - MIN_DOOR_CM);
  const applied = Math.round(Math.max(minDelta, Math.min(maxDelta, deltaCm)));

  left.widthCm = +(left.widthCm + applied).toFixed(1);
  right.startCm = +(left.startCm + left.widthCm).toFixed(1);
  right.widthCm = +(right.widthCm - applied).toFixed(1);

  const seamNew = right.startCm;
  box.unitDividers = box.unitDividers
    .map((u) => (Math.abs(u - seamOld) < 2 ? seamNew : u))
    .filter((u) => u > 2 && u < box.width - 2);

  return applied;
}

/**
 * Evenly divides an entire box into `count` doors respecting corner blind zones
 */
export function divideBoxEvenlyRespectingCorners(
  box: CabinetBox,
  count: number,
  blockedZones: BlockedZone[]
): { ok: boolean; message: string } {
  if (box.type === 'fridge') return { ok: false, message: 'یخچال قابل تقسیم نیست' };

  const spans = getFreeSpansInBox({ ...box, doors: [] }, blockedZones);
  if (!spans.length) return { ok: false, message: 'فضای مجاز برای درب‌گذاری وجود ندارد' };

  const mainSpan = spans.reduce((best, cur) =>
    cur.endCm - cur.startCm > best.endCm - best.startCm ? cur : best
  );
  const avail = +(mainSpan.endCm - mainSpan.startCm).toFixed(1);
  const w = +(avail / count).toFixed(1);

  if (w < MIN_DOOR_CM || w > MAX_DOOR_CM) {
    return {
      ok: false,
      message: `با ${count} بخش، عرض هر درب ${w}cm می‌شود (باید بین ۳۰ تا ۶۰cm باشد)`,
    };
  }

  box.doors = [];
  for (let i = 0; i < count; i++) {
    box.doors.push({
      id: uid('door'),
      startCm: +(mainSpan.startCm + i * w).toFixed(1),
      widthCm: i === count - 1 ? +(avail - w * (count - 1)).toFixed(1) : w,
      kind: 'door',
      drawerRatios: [],
    });
  }
  box.handles = [];
  return { ok: true, message: `فضای مجاز به ${count} درب ${w}cm تقسیم شد` };
}
