export type BoxKind = 'base' | 'wall' | 'wall-deep' | 'tall' | 'fridge' | 'closet';

export type FridgeModel = 'single' | 'side-by-side' | 'twin';

export type DoorKind =
  | 'door'
  | 'drawer'
  | 'lift'
  | 'open'
  | 'rail'
  | 'oven'
  | 'fridge';

export type HandleStyle = 'simple' | 'knob' | 'hidden';
export type Orientation = 'vertical' | 'horizontal';

export type ApplianceKind = 'sink' | 'gas' | 'dishwasher' | 'washing';
export type OpeningKind = 'window' | 'door' | 'column';
export type DoorSwing = 'left-in' | 'right-in' | 'left-out' | 'right-out';

export type ToolId =
  | 'select'
  | 'wall'
  | 'cab-draw'
  | 'fridge'
  | 'appliance'
  | 'opening'
  | 'doors'
  | 'pencil'
  | 'skeleton'
  | 'handle'
  | 'eraser';

export interface DoorUnit {
  id: string;
  startCm: number;
  widthCm: number;
  kind: DoorKind;
  /** Vertical split ratios (0..1) for drawers or stacked horizontal lift doors */
  drawerRatios: number[];
}

export interface ShelfItem {
  id: string;
  startCm: number;
  endCm: number;
  yRatio: number;
}

export interface HandleItem {
  id: string;
  doorId: string;
  /** Which drawer/lift row index (0..N) if door has horizontal splits; 0 for full door */
  rowIndex: number;
  xRatio: number;
  yRatio: number;
  orient: Orientation;
  style: HandleStyle;
  lengthCm: number;
}

export interface CabinetBox {
  id: string;
  name: string;
  type: BoxKind;
  offsetX: number;
  elevY: number;
  width: number;
  height: number;
  depth: number;
  plinth: number;
  countertopCm: number;
  hasFridgeFrame?: boolean;
  fridgeModel?: FridgeModel;
  doors: DoorUnit[];
  unitDividers: number[];
  shelves: ShelfItem[];
  handles: HandleItem[];
}

export interface ApplianceItem {
  id: string;
  kind: ApplianceKind;
  offsetX: number;
  width: number;
  hoodKind?: 'hidden' | 'chimney';
}

export interface WallOpening {
  id: string;
  kind: OpeningKind;
  offsetX: number;
  width: number;
  elevY: number;
  height: number;
  swingDir?: DoorSwing;
}

export interface Wall {
  id: string;
  name: string;
  x1Cm: number;
  y1Cm: number;
  x2Cm: number;
  y2Cm: number;
  length: number;
  height: number;
  angle: number;
  flipSide: 1 | -1;
  boxes: CabinetBox[];
  appliances: ApplianceItem[];
  openings?: WallOpening[];
}

export interface CornerJunction {
  key: string;
  xCm: number;
  yCm: number;
  wallAId: string;
  wallAEnd: 'start' | 'end';
  wallBId: string;
  wallBEnd: 'start' | 'end';
  /** Which wall's cabinet extends all the way into the corner square */
  ownerWallId: string;
}

export interface BlockedZone {
  startCm: number;
  endCm: number;
  depthCm: number;
  tier: 'lower' | 'wall-lower' | 'wall-upper';
  role: 'blind-behind' | 'side-profile';
  otherWallName: string;
  cornerKey: string;
}

export interface DrawerPattern {
  id: string;
  label: string;
  shortLabel: string;
  ratios: number[];
}

export interface ProjectSettings {
  wallHeightCm: number;
  baseHeightCm: number;
  plinthCm: number;
  countertopCm: number;
  wallCabElevCm: number;
  wallCabHeightCm: number;
}

export interface MultiSelection {
  boxIds: string[];
  doorIds: string[];
  openingIds: string[];
  applianceIds: string[];
}

export interface ProjectState {
  walls: Wall[];
  cornerOwners: Record<string, string>;
  activeWallId: string | null;
  activeBoxId: string | null;
  selectedDoorId: string | null;
  selectedOpeningId?: string | null;
  multiSelection?: MultiSelection;
  doorsLocked: boolean;
  settings?: ProjectSettings;
}
