import { DEFAULT_PROJECT_SETTINGS } from './constants';
import { makeCornerKey } from './cornerLogic';
import { createEmptyBox, createWall, uid } from './doorRules';
import { ProjectState } from './types';

export type PresetMode = 'single' | 'L' | 'U' | 'closet';

export function buildPresetProject(mode: PresetMode): ProjectState {
  if (mode === 'closet') {
    const w1 = createWall('دیوار کمد (300)', -150, -70, 150, -70, 1);
    const closet = createEmptyBox('closet', 0, 300);
    closet.doors = [
      { id: uid('door'), startCm: 0, widthCm: 50, kind: 'rail', drawerRatios: [] },
      { id: uid('door'), startCm: 50, widthCm: 50, kind: 'rail', drawerRatios: [] },
      { id: uid('door'), startCm: 100, widthCm: 50, kind: 'drawer', drawerRatios: [0.25, 0.5, 0.75] },
      { id: uid('door'), startCm: 150, widthCm: 50, kind: 'drawer', drawerRatios: [0.25, 0.5, 0.75] },
      { id: uid('door'), startCm: 200, widthCm: 50, kind: 'door', drawerRatios: [] },
      { id: uid('door'), startCm: 250, widthCm: 50, kind: 'door', drawerRatios: [] },
    ];
    closet.unitDividers = [100, 200];
    closet.shelves = [
      { id: uid('sh'), startCm: 0, endCm: 100, yRatio: 0.22 },
      { id: uid('sh'), startCm: 200, endCm: 300, yRatio: 0.22 },
      { id: uid('sh'), startCm: 200, endCm: 300, yRatio: 0.48 },
      { id: uid('sh'), startCm: 200, endCm: 300, yRatio: 0.74 },
    ];
    w1.boxes.push(closet);

    return {
      walls: [w1],
      cornerOwners: {},
      activeWallId: w1.id,
      activeBoxId: closet.id,
      selectedDoorId: closet.doors[0].id,
      selectedOpeningId: null,
      doorsLocked: false,
      settings: { ...DEFAULT_PROJECT_SETTINGS },
    };
  }

  const w1 = createWall('دیوار اصلی (340)', -170, -90, 170, -90, 1);

  const base1 = createEmptyBox('base', 0, 250);
  const startBaseDoor = mode === 'single' ? 0 : 60;
  if (mode === 'single') {
    base1.doors = [
      { id: uid('door'), startCm: 0, widthCm: 45, kind: 'door', drawerRatios: [] },
      { id: uid('door'), startCm: 45, widthCm: 45, kind: 'door', drawerRatios: [] },
      { id: uid('door'), startCm: 90, widthCm: 80, kind: 'drawer', drawerRatios: [0.22, 0.54] },
      { id: uid('door'), startCm: 170, widthCm: 40, kind: 'door', drawerRatios: [] },
      { id: uid('door'), startCm: 210, widthCm: 40, kind: 'door', drawerRatios: [] },
    ];
    base1.unitDividers = [90, 170];
  } else {
    base1.width = 230;
    base1.doors = [
      { id: uid('door'), startCm: startBaseDoor, widthCm: 45, kind: 'door', drawerRatios: [] },
      { id: uid('door'), startCm: 105, widthCm: 45, kind: 'door', drawerRatios: [] },
      { id: uid('door'), startCm: 150, widthCm: 80, kind: 'drawer', drawerRatios: [0.22, 0.54] },
    ];
    base1.unitDividers = [60, 150];
  }

  const wallLower = createEmptyBox('wall', 32, 198, { twoDepthWallLower: true });
  wallLower.doors = [
    { id: uid('door'), startCm: 0, widthCm: 49, kind: 'door', drawerRatios: [] },
    { id: uid('door'), startCm: 49, widthCm: 49, kind: 'door', drawerRatios: [] },
    { id: uid('door'), startCm: 98, widthCm: 50, kind: 'door', drawerRatios: [] },
    { id: uid('door'), startCm: 148, widthCm: 50, kind: 'door', drawerRatios: [] },
  ];
  wallLower.unitDividers = [98];

  const wallUpper = createEmptyBox('wall-deep', 60, 170);
  wallUpper.doors = [
    { id: uid('door'), startCm: 0, widthCm: 56.6, kind: 'lift', drawerRatios: [] },
    { id: uid('door'), startCm: 56.6, widthCm: 56.6, kind: 'lift', drawerRatios: [] },
    { id: uid('door'), startCm: 113.2, widthCm: 56.8, kind: 'lift', drawerRatios: [] },
  ];
  wallUpper.unitDividers = [56.6, 113.2];

  const fridgeOffset = mode === 'single' ? 250 : 230;
  const fridge = createEmptyBox('fridge', fridgeOffset, 90, {
    hasFridgeFrame: true,
    fridgeModel: 'side-by-side',
  });
  const overFridge = createEmptyBox('wall-deep', fridgeOffset, 90);
  overFridge.name = 'بالای یخچال';
  overFridge.elevY = 190;
  overFridge.height = 45;
  overFridge.doors = [{ id: uid('door'), startCm: 0, widthCm: 90, kind: 'lift', drawerRatios: [] }];

  w1.boxes.push(base1, wallLower, wallUpper, fridge, overFridge);

  if (mode === 'single') {
    w1.appliances.push(
      { id: uid('app'), kind: 'sink', offsetX: 0, width: 90 },
      { id: uid('app'), kind: 'gas', offsetX: 90, width: 80, hoodKind: 'hidden' }
    );
  } else {
    w1.appliances.push(
      { id: uid('app'), kind: 'sink', offsetX: 60, width: 90 },
      { id: uid('app'), kind: 'gas', offsetX: 150, width: 80, hoodKind: 'hidden' }
    );
  }

  const walls = [w1];
  const cornerOwners: Record<string, string> = {};

  if (mode === 'L' || mode === 'U') {
    const w2 = createWall('دیوار کنج چپ (200)', -170, -90, -170, 110, -1);
    const key12 = makeCornerKey(w1.id, 'start', w2.id, 'start');
    cornerOwners[key12] = w1.id;

    const base2 = createEmptyBox('base', 60, 140);
    base2.doors = [
      { id: uid('door'), startCm: 0, widthCm: 46.6, kind: 'door', drawerRatios: [] },
      { id: uid('door'), startCm: 46.6, widthCm: 46.6, kind: 'door', drawerRatios: [] },
      { id: uid('door'), startCm: 93.2, widthCm: 46.8, kind: 'door', drawerRatios: [] },
    ];
    base2.unitDividers = [46.6, 93.2];

    const wall2 = createEmptyBox('wall', 32, 168, { twoDepthWallLower: true });
    wall2.doors = [
      { id: uid('door'), startCm: 0, widthCm: 56, kind: 'door', drawerRatios: [] },
      { id: uid('door'), startCm: 56, widthCm: 56, kind: 'door', drawerRatios: [] },
      { id: uid('door'), startCm: 112, widthCm: 56, kind: 'door', drawerRatios: [] },
    ];
    w2.boxes.push(base2, wall2);
    walls.push(w2);
  }

  if (mode === 'U') {
    w1.boxes = w1.boxes.filter((b) => b.id !== fridge.id && b.id !== overFridge.id);
    base1.width = 280;
    base1.doors.push({ id: uid('door'), startCm: 230, widthCm: 50, kind: 'door', drawerRatios: [] });

    const w3 = createWall('دیوار راست (200)', 170, -90, 170, 110, 1);
    const key13 = makeCornerKey(w1.id, 'end', w3.id, 'start');
    cornerOwners[key13] = w1.id;

    const tall3 = createEmptyBox('tall', 60, 120);
    tall3.height = 235;
    tall3.doors = [
      { id: uid('door'), startCm: 0, widthCm: 60, kind: 'oven', drawerRatios: [] },
      { id: uid('door'), startCm: 60, widthCm: 60, kind: 'door', drawerRatios: [] },
    ];
    tall3.unitDividers = [60];
    w3.boxes.push(tall3);
    walls.push(w3);
  }

  return {
    walls,
    cornerOwners,
    activeWallId: w1.id,
    activeBoxId: base1.id,
    selectedDoorId: base1.doors[0]?.id ?? null,
    selectedOpeningId: null,
    doorsLocked: false,
    settings: { ...DEFAULT_PROJECT_SETTINGS },
  };
}
