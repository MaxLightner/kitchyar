import test from 'node:test';
import assert from 'node:assert/strict';
import {
  applyDoorBrushPreview,
  clampBoxInternalsAfterResize,
  computeDoorBrushPreview,
  createEmptyBox,
  createWall,
  equalizeDoorsInBox,
  eraseDoorWithRule,
  getUnitsInBox,
  optimizeBoxWithAppliances,
  placeApplianceWithCabinetRules,
  placeFridgeOnWall,
  resizeDoorSafely,
  resizeDoorSeamCoupled,
} from './doorRules';
import {
  createWallOpening,
  findCollidingOpening,
  updateOpeningGeometry,
} from './openingRules';
import {
  analyzeCornerJunction,
  autoOrientWallsOnAdd,
  collectSmartWallNodes,
  computeMultiWallSweep,
  detectCornerJunctions,
  getCornerBlockedZonesForWall,
  getOutsideCornerBridges,
  getPlanPolygonForBox,
  getPlanVisualSpanForBox,
  getWallVectors,
  makeCornerKey,
  moveSmartWallNode,
  toggleCornerOwner,
} from './cornerLogic';
import { buildPresetProject } from './presets';

test('Door Brush obeys 30..60cm rule when placing and splitting doors', () => {
  const box = createEmptyBox('base', 0, 120);

  // Place first door in empty 120cm box -> 60cm door
  const p1 = computeDoorBrushPreview(box, 20, 'vertical', 1, 0, 0, []);
  assert.equal(p1.ok, true);
  assert.equal(p1.items[0].widthCm, 60);
  applyDoorBrushPreview(box, 20, p1);
  assert.equal(box.doors.length, 1);

  // Split 60cm door -> two 30cm doors
  const p2 = computeDoorBrushPreview(box, 25, 'vertical', 1, 0, 0, []);
  assert.equal(p2.ok, true);
  assert.equal(p2.items.length, 2);
  assert.equal(p2.items[0].widthCm, 30);
  applyDoorBrushPreview(box, 25, p2);
  assert.equal(box.doors.length, 2);

  // Fill remaining 60cm -> 60cm, then split it -> 4x30cm doors
  applyDoorBrushPreview(box, 90, computeDoorBrushPreview(box, 90, 'vertical', 1, 0, 0, []));
  applyDoorBrushPreview(box, 90, computeDoorBrushPreview(box, 90, 'vertical', 1, 0, 0, []));
  assert.equal(box.doors.length, 4);

  // Attempting to add a 5th door (<30cm) must fail cleanly
  const p5 = computeDoorBrushPreview(box, 10, 'vertical', 1, 0, 0, []);
  assert.equal(p5.ok, false);
});

test('Horizontal Door Brush creates drawers on base and horizontal lift doors on wall', () => {
  const base = createEmptyBox('base', 0, 120);
  const pBase = computeDoorBrushPreview(base, 30, 'horizontal', 1, 2 /* stepped 3 */, 0, []);
  assert.equal(pBase.ok, true);
  assert.equal(pBase.items[0].kind, 'drawer');
  assert.deepEqual(pBase.items[0].drawerRatios, [0.22, 0.54]);

  const wallCab = createEmptyBox('wall', 0, 120);
  const pWall = computeDoorBrushPreview(wallCab, 30, 'horizontal', 1, 0, 1 /* 2 lift */, []);
  assert.equal(pWall.ok, true);
  assert.equal(pWall.items[0].kind, 'lift');
  assert.deepEqual(pWall.items[0].drawerRatios, [0.5]);
});

test('Erase door merges only if combined <= 60cm, otherwise leaves space empty', () => {
  const box = createEmptyBox('base', 0, 120);
  box.doors = [
    { id: 'd1', startCm: 0, widthCm: 30, kind: 'door', drawerRatios: [] },
    { id: 'd2', startCm: 30, widthCm: 30, kind: 'door', drawerRatios: [] },
    { id: 'd3', startCm: 60, widthCm: 50, kind: 'door', drawerRatios: [] },
  ];

  // Deleting d2 merges into d1 (30+30=60 <= 60)
  eraseDoorWithRule(box, 'd2');
  assert.equal(box.doors.length, 2);
  assert.equal(box.doors[0].widthCm, 60);

  // Deleting d3 cannot merge with 60cm d1 (60+50=110 > 60), so leaves empty gap
  eraseDoorWithRule(box, 'd3');
  assert.equal(box.doors.length, 1);
  assert.equal(box.doors[0].widthCm, 60);
});

test('Bidirectional L-corner logic blocks doors in corner zone from BOTH walls without overlap', () => {
  const project = buildPresetProject('L');
  const w1 = project.walls[0];
  const w2 = project.walls[1];

  const junctions = detectCornerJunctions(project.walls, project.cornerOwners);
  assert.equal(junctions.length, 1);

  const zonesW1 = getCornerBlockedZonesForWall(w1, project.walls, project.cornerOwners);
  const zonesW2 = getCornerBlockedZonesForWall(w2, project.walls, project.cornerOwners);

  // Both walls see a blocked lower corner zone of 60cm!
  const w1Lower = zonesW1.find((z) => z.tier === 'lower');
  const w2Lower = zonesW2.find((z) => z.tier === 'lower');
  assert.ok(w1Lower);
  assert.ok(w2Lower);
  assert.equal(w1Lower.depthCm, 60);
  assert.equal(w2Lower.depthCm, 60);
  assert.equal(w1Lower.role, 'blind-behind');
  assert.equal(w2Lower.role, 'side-profile');

  // Cannot place a door inside the 0..60cm blind zone on w1's base box
  const base1 = w1.boxes[0];
  const tryBlind = computeDoorBrushPreview(base1, 25, 'vertical', 1, 0, 0, zonesW1);
  assert.equal(tryBlind.ok, false);

  // Flipping corner owner to w2 swaps the blind/side roles cleanly
  const key = makeCornerKey(w1.id, 'start', w2.id, 'start');
  project.cornerOwners = toggleCornerOwner(project.walls, project.cornerOwners, key);
  const flippedW1 = getCornerBlockedZonesForWall(w1, project.walls, project.cornerOwners);
  const flippedW2 = getCornerBlockedZonesForWall(w2, project.walls, project.cornerOwners);
  assert.equal(flippedW1.find((z) => z.tier === 'lower')?.role, 'side-profile');
  assert.equal(flippedW2.find((z) => z.tier === 'lower')?.role, 'blind-behind');

  // Plan visual span trims non-owner boxes so they never overlap in plan
  const span1 = getPlanVisualSpanForBox(w1.boxes[0], w1, project.walls, project.cornerOwners);
  assert.equal(span1.startCm, 60);
});

test('Sink creates 2-door dedicated unit and Gas creates 3-stepped drawers beneath', () => {
  const w = createWall('دیوار تست', 0, 0, 300, 0);
  const base = createEmptyBox('base', 0, 300);
  w.boxes.push(base);

  const rSink = placeApplianceWithCabinetRules(w, [w], 'sink', base, 20, {});
  assert.equal(rSink.ok, true);
  assert.equal(base.doors.length, 2);
  assert.equal(base.doors[0].widthCm, 45);
  assert.equal(base.doors[1].widthCm, 45);

  const rGas = placeApplianceWithCabinetRules(w, [w], 'gas', base, 140, {});
  assert.equal(rGas.ok, true);
  const gasDrawer = base.doors.find((d) => d.kind === 'drawer');
  assert.ok(gasDrawer);
  assert.equal(gasDrawer.widthCm, 80);
  assert.deepEqual(gasDrawer.drawerRatios, [0.22, 0.54]);
});

test('Resizing box clamps doors and resizing door never overlaps neighbor', () => {
  const box = createEmptyBox('base', 0, 120);
  box.doors = [
    { id: 'd1', startCm: 0, widthCm: 40, kind: 'door', drawerRatios: [] },
    { id: 'd2', startCm: 60, widthCm: 50, kind: 'door', drawerRatios: [] },
  ];

  // Try resizing d1 to 80cm -> clamped to 60cm (neighbor start & MAX_DOOR_CM)
  const clamped = resizeDoorSafely(box, 'd1', 80, []);
  assert.equal(clamped, 60);

  // Shrink box width to 80cm -> d2 is clamped/removed if <30cm
  box.width = 80;
  clampBoxInternalsAfterResize(box);
  assert.equal(box.doors.length, 1);

  // Equalize doors on a 100cm box with two doors
  const box2 = createEmptyBox('base', 0, 100);
  box2.doors = [
    { id: 'a', startCm: 0, widthCm: 40, kind: 'door', drawerRatios: [] },
    { id: 'b', startCm: 40, widthCm: 60, kind: 'door', drawerRatios: [] },
  ];
  const eq = equalizeDoorsInBox(box2, []);
  assert.equal(eq.ok, true);
  assert.equal(box2.doors[0].widthCm, 50);
  assert.equal(box2.doors[1].widthCm, 50);
});

test('Auto-orients RTL 4-wall layout inward and classifies 90°, 135° inside, and 225° outside corners', () => {
  // User draws right-to-left: w1 goes UP, w2 goes LEFT, w3 goes DOWN-LEFT (135°), w4 goes LEFT (225° outer bend)
  const w1 = createWall('دیوار 1', 300, 200, 300, -90, 1);
  const w2 = autoOrientWallsOnAdd([w1], createWall('دیوار 2', 300, -90, -130, -90, 1));
  const walls = [w1, w2];
  const w3 = autoOrientWallsOnAdd(walls, createWall('دیوار 3', -130, -90, -320, 100, 1));
  walls.push(w3);
  const w4 = autoOrientWallsOnAdd(walls, createWall('دیوار 4', -320, 100, -570, 100, 1));
  walls.push(w4);

  // All 4 normals must point into the room interior (w1 left, w2 down, w3 down-right, w4 down)
  assert.ok(getWallVectors(w1).nx < -0.9, 'w1 should face left (interior)');
  assert.ok(getWallVectors(w2).ny > 0.9, 'w2 should face down (interior)');
  assert.ok(getWallVectors(w3).nx > 0.5 && getWallVectors(w3).ny > 0.5, 'w3 should face down-right (interior)');
  assert.ok(getWallVectors(w4).ny > 0.9, 'w4 should face down (interior)');

  const g12 = analyzeCornerJunction(w1, 'end', w2, 'start');
  const g23 = analyzeCornerJunction(w2, 'end', w3, 'start');
  const g34 = analyzeCornerJunction(w3, 'end', w4, 'start');
  assert.equal(g12.kind, 'inside-90');
  assert.equal(g23.kind, 'inside-angled');
  assert.equal(g23.getSetbackCm(60), 25); // 60 / tan(67.5°) ≈ 25cm
  assert.equal(g34.kind, 'outside');
  assert.equal(g34.getSetbackCm(60), 0);
});

test('Multi-wall sweep connects all 4 walls continuously with mitered 135° corners and outside caps', () => {
  const w1 = createWall('دیوار 1', 300, 200, 300, -90, 1);
  const w2 = autoOrientWallsOnAdd([w1], createWall('دیوار 2', 300, -90, -130, -90, 1));
  const walls = [w1, w2];
  const w3 = autoOrientWallsOnAdd(walls, createWall('دیوار 3', -130, -90, -320, 100, 1));
  walls.push(w3);
  const w4 = autoOrientWallsOnAdd(walls, createWall('دیوار 4', -320, 100, -570, 100, 1));
  walls.push(w4);

  // Sweep from w1 (near bottom) all the way to w4 (near far left)
  const sweep = computeMultiWallSweep(walls, w1.id, 40, w4.id, 210, 'base', {}, true);
  assert.equal(sweep.segments.length, 4);

  // Place boxes from sweep
  const owners = { ...sweep.suggestedOwners };
  for (const seg of sweep.segments) {
    const w = walls.find((x) => x.id === seg.wallId)!;
    assert.ok(seg.startCm >= 0 && seg.startCm + seg.widthCm <= w.length);
    w.boxes.push(createEmptyBox('base', seg.startCm, seg.widthCm));
  }

  // Verify w1 owns corner 1-2 so w2 starts at 60cm, while w2-w3 and w3-w4 connect at 0
  assert.equal(sweep.segments[0].startCm + sweep.segments[0].widthCm, w1.length);
  assert.equal(sweep.segments[1].startCm, 60);
  assert.equal(sweep.segments[1].startCm + sweep.segments[1].widthCm, w2.length);
  assert.equal(sweep.segments[2].startCm, 0);
  assert.equal(sweep.segments[2].widthCm, w3.length);
  assert.equal(sweep.segments[3].startCm, 0);

  // Verify w1-w2 (90°), w2-w3 (135°), and w3-w4 (225° outside) ALL meet along a single clean miter line!
  const poly1 = getPlanPolygonForBox(w1.boxes[0], w1, walls, owners);
  const poly2 = getPlanPolygonForBox(w2.boxes[0], w2, walls, owners);
  const poly3 = getPlanPolygonForBox(w3.boxes[0], w3, walls, owners);
  const poly4 = getPlanPolygonForBox(w4.boxes[0], w4, walls, owners);
  assert.ok(Math.hypot(poly1[2].x - poly2[3].x, poly1[2].y - poly2[3].y) <= 1.5, '90° miter matches');
  assert.ok(Math.hypot(poly2[2].x - poly3[3].x, poly2[2].y - poly3[3].y) <= 1.5, '135° miter matches');
  assert.ok(Math.hypot(poly3[2].x - poly4[3].x, poly3[2].y - poly4[3].y) <= 1.5, '225° outside miter matches');

  // No separate bridge polygons needed (zero double seam lines)
  const bridges = getOutsideCornerBridges(walls, owners);
  assert.equal(bridges.length, 0);

  // Single tap near end of w1 must NEVER overhang past wall length
  const tapEnd = computeMultiWallSweep(walls, w1.id, w1.length - 5, w1.id, w1.length - 5, 'base', owners, false);
  assert.equal(tapEnd.segments.length, 1);
  assert.ok(tapEnd.segments[0].startCm + tapEnd.segments[0].widthCm <= w1.length);
});

test('Click-click Door Brush places 60cm doors then shrinks neighbors down to 30cm, refusing <30cm', () => {
  const box = createEmptyBox('base', 0, 100);

  // Click 1 -> 60cm door
  const p1 = computeDoorBrushPreview(box, 10, 'vertical', 1, 0, 0, []);
  assert.equal(p1.ok, true);
  assert.equal(p1.items[0].widthCm, 60);
  applyDoorBrushPreview(box, 10, p1);

  // Click 2 in remaining 40cm -> 40cm door
  const p2 = computeDoorBrushPreview(box, 80, 'vertical', 1, 0, 0, []);
  assert.equal(p2.ok, true);
  assert.equal(p2.items[0].widthCm, 40);
  applyDoorBrushPreview(box, 80, p2);
  assert.deepEqual(box.doors.map((d) => d.widthCm), [60, 40]);

  // Click 3 on 40cm door -> shrinks [60, 40] down to [40, 30, 30]
  const p3 = computeDoorBrushPreview(box, 80, 'vertical', 1, 0, 0, []);
  assert.equal(p3.ok, true);
  applyDoorBrushPreview(box, 80, p3);
  assert.equal(box.doors.length, 3);
  assert.ok(box.doors.every((d) => d.widthCm >= 30));

  // Click 4 -> 4 * 30 = 120 > 100 -> must refuse
  const p4 = computeDoorBrushPreview(box, 80, 'vertical', 1, 0, 0, []);
  assert.equal(p4.ok, false);
});

test('Drawers & horizontal doors auto-create unit dividers; shelves target whole Units and block drawers', () => {
  const box = createEmptyBox('base', 0, 180);
  // Place 60cm door + 60cm door + 60cm drawer
  applyDoorBrushPreview(box, 10, computeDoorBrushPreview(box, 10, 'vertical', 1, 0, 0, []));
  applyDoorBrushPreview(box, 70, computeDoorBrushPreview(box, 70, 'vertical', 1, 0, 0, []));
  applyDoorBrushPreview(box, 150, computeDoorBrushPreview(box, 150, 'horizontal', 1, 1, 0, []));

  // Drawer auto-created a unit divider at 120cm!
  assert.ok(box.unitDividers.includes(120));

  const units = getUnitsInBox(box, []);
  assert.equal(units.length, 2);
  // Unit 1 (0..120) has 2 hinged doors -> valid 120cm unit for shelves spanning across BOTH doors!
  assert.equal(units[0].startCm, 0);
  assert.equal(units[0].endCm, 120);
  assert.equal(units[0].canHaveShelves, true);
  // Unit 2 (120..180) is drawer -> cannot take shelves!
  assert.equal(units[1].hasDrawer, true);
  assert.equal(units[1].canHaveShelves, false);

  // A 180cm box with 3 hinged doors and NO unit divider must require defining unit divider first
  const box3 = createEmptyBox('base', 0, 180);
  applyDoorBrushPreview(box3, 10, computeDoorBrushPreview(box3, 10, 'vertical', 3, 0, 0, []));
  const undivided = getUnitsInBox(box3, []);
  assert.equal(undivided[0].canHaveShelves, false);
  box3.unitDividers.push(120);
  const divided = getUnitsInBox(box3, []);
  assert.equal(divided.length, 2);
  assert.equal(divided[0].canHaveShelves, true);
  assert.equal(divided[1].canHaveShelves, true);
});

test('Door Brush supports direct targetDoorWidthCm < 60 (e.g. 40cm and 35cm) in empty bays', () => {
  const box = createEmptyBox('base', 0, 120);

  const p40 = computeDoorBrushPreview(box, 10, 'vertical', 1, 0, 0, [], 40);
  assert.equal(p40.ok, true);
  assert.equal(p40.items.length, 1);
  assert.equal(p40.items[0].widthCm, 40);
  applyDoorBrushPreview(box, 10, p40);

  const p35 = computeDoorBrushPreview(box, 55, 'vertical', 1, 0, 0, [], 35);
  assert.equal(p35.ok, true);
  assert.equal(p35.items.length, 1);
  assert.equal(p35.items[0].widthCm, 35);
  applyDoorBrushPreview(box, 55, p35);

  assert.deepEqual(
    box.doors.map((d) => d.widthCm),
    [40, 35]
  );
});

test('Multiple sinks/gases allowed without overlap; dishwasher/washing reserve 60cm bay', () => {
  const w = createWall('دیوار مطبخ و آشپزخانه', 0, 0, 420, 0);
  const base = createEmptyBox('base', 0, 420);
  w.boxes.push(base);

  const sink1 = placeApplianceWithCabinetRules(w, [w], 'sink', base, 0, {});
  assert.equal(sink1.ok, true);

  // Second sink in another spot (e.g., dirty kitchen / island wall) succeeds cleanly
  const sink2 = placeApplianceWithCabinetRules(w, [w], 'sink', base, 200, {});
  assert.equal(sink2.ok, true);
  assert.equal(w.appliances.filter((a) => a.kind === 'sink').length, 2);

  // Dishwasher placed cleanly inside remaining free span creates unit dividers and no doors
  const dw = placeApplianceWithCabinetRules(w, [w], 'dishwasher', base, 100, {});
  assert.equal(dw.ok, true);
  assert.equal(dw.appliance?.width, 60);

  // Clicking outside the sink in remaining 10cm spot where 60cm dishwasher cannot fit fails cleanly
  const smallWall = createWall('دیوار کوچک', 0, 0, 100, 0);
  const smallBase = createEmptyBox('base', 0, 100);
  smallWall.boxes.push(smallBase);
  assert.equal(placeApplianceWithCabinetRules(smallWall, [smallWall], 'sink', smallBase, 0, {}).ok, true);
  const overlapFail = placeApplianceWithCabinetRules(smallWall, [smallWall], 'dishwasher', smallBase, 65, {});
  assert.equal(overlapFail.ok, false);
});

test('Fridge placement supports single (70), side-by-side (92), twin (120) with aligned upper cabinet', () => {
  const w = createWall('دیوار یخچال', 0, 0, 400, 0);

  const f1 = placeFridgeOnWall(w, [w], 'single', 0, {});
  assert.equal(f1.ok, true);
  const b1 = w.boxes.find((b) => b.id === f1.fridgeId);
  assert.equal(b1?.width, 70);
  assert.equal(b1?.fridgeModel, 'single');

  const f2 = placeFridgeOnWall(w, [w], 'side-by-side', 80, {});
  assert.equal(f2.ok, true);
  const b2 = w.boxes.find((b) => b.id === f2.fridgeId);
  assert.equal(b2?.width, 92);

  const f3 = placeFridgeOnWall(w, [w], 'twin', 200, {});
  assert.equal(f3.ok, true);
  const b3 = w.boxes.find((b) => b.id === f3.fridgeId);
  assert.equal(b3?.width, 120);

  // Each fridge auto-spawns a matching 'wall-deep' lift cabinet above it
  assert.equal(w.boxes.filter((b) => b.type === 'wall-deep').length, 3);

  // Overlapping fridge placement is rejected
  const fOverlap = placeFridgeOnWall(w, [w], 'single', 90, {});
  assert.equal(fOverlap.ok, false);
});

test('Openings (window, room door, column) resize cleanly and detect tier-aware cabinet collisions', () => {
  const w = createWall('دیوار پنجره‌دار', 0, 0, 350, 0);
  const win = createWallOpening('window', 100, w);
  w.openings = [win];

  // Window defaults: width 120, elevY 105, height 120 (105..225)
  // Base cabinet (0..86) passes freely under the high window!
  assert.equal(findCollidingOpening(w, 80, 240, 0, 86), null);

  // Wall cabinet (145..220) collides with the window!
  assert.equal(findCollidingOpening(w, 80, 240, 145, 75)?.id, win.id);

  // Interactive resize clamps cleanly to wall boundaries
  updateOpeningGeometry(win, w, { offsetX: 300, width: 100, elevY: 120, height: 90 });
  assert.equal(win.offsetX, 250); // clamped to 350 - 100
  assert.equal(win.width, 100);
  assert.equal(win.elevY, 120);
  assert.equal(win.height, 90);

  // Room door (elevY=0, height=210) collides with both base & wall cabinets
  const doorOp = createWallOpening('door', 10, w);
  w.openings.push(doorOp);
  assert.equal(findCollidingOpening(w, 0, 120, 0, 86)?.id, doorOp.id);
  assert.equal(findCollidingOpening(w, 0, 120, 145, 75)?.id, doorOp.id);
});

test('Smart wall corner nodes resize connected walls together, clamp boxes, and prevent <40cm collapse', () => {
  const w1 = createWall('دیوار 1 (200)', 0, 0, 200, 0, 1);
  const w2 = createWall('دیوار 2 (200)', 200, 0, 200, 200, 1);
  w1.boxes.push(createEmptyBox('base', 0, 200));

  const nodes = collectSmartWallNodes([w1, w2]);
  const sharedCorner = nodes.find((n) => n.refs.length === 2);
  assert.ok(sharedCorner, 'Expected shared corner node connecting w1 end & w2 start');

  // Drag corner node left by 40cm -> w1 shrinks to 160, w2 tilts diagonally and clamps box cleanly
  const moved = moveSmartWallNode([w1, w2], sharedCorner.refs, 160, 0);
  assert.equal(moved, true);
  assert.equal(w1.length, 160);
  assert.ok(w1.name.includes('(160)'));
  assert.equal(w1.boxes[0].width, 160);

  // Attempting to collapse wall below 40cm must be blocked cleanly
  const collapsed = moveSmartWallNode([w1, w2], sharedCorner.refs, 20, 0);
  assert.equal(collapsed, false);
  assert.equal(w1.length, 160);
});

test('Clicking existing appliance replaces it directly, and optimizeBoxWithAppliances eliminates dead slivers', () => {
  const w = createWall('دیوار آشپزخانه', 0, 0, 250, 0);
  const base = createEmptyBox('base', 0, 250);
  w.boxes.push(base);

  // 1. Place Sink at 20..110, then click Gas right over Sink -> replaces Sink with Gas!
  const rSink = placeApplianceWithCabinetRules(w, [w], 'sink', base, 20, {});
  assert.equal(rSink.ok, true);
  assert.equal(w.appliances.length, 1);

  const rGas = placeApplianceWithCabinetRules(w, [w], 'gas', base, 25, {});
  assert.equal(rGas.ok, true);
  assert.equal(rGas.replaced, true);
  assert.equal(w.appliances.length, 1);
  assert.equal(w.appliances[0].kind, 'gas');
  assert.equal(base.doors.some((d) => d.kind === 'drawer'), true);

  // 2. Place Sink at 0..90 and Dishwasher poorly leaving a <30cm gap, then optimize
  w.appliances = [];
  base.doors = [];
  base.unitDividers = [];
  placeApplianceWithCabinetRules(w, [w], 'sink', base, 0, {});
  // Force an awkward loose dishwasher manually at 110..170 (20cm dead sliver next to sink!)
  w.appliances.push({ id: 'dw1', kind: 'dishwasher', offsetX: 110, width: 60 });
  const opt = optimizeBoxWithAppliances(w, [w], base, {});
  assert.equal(opt.ok, true);
  const dw = w.appliances.find((a) => a.id === 'dw1');
  assert.equal(dw?.offsetX, 90); // snapped flush next to 90cm sink, leaving full 100cm span on right!
});

test('Fridge auto-carves continuous existing base and wall cabinets into valid >=30cm remainders', () => {
  const w = createWall('دیوار سراسری', 0, 0, 300, 0);
  w.boxes.push(createEmptyBox('base', 0, 300));
  w.boxes.push(createEmptyBox('wall', 0, 300));

  // Place 90cm side-by-side fridge (92cm) at 100..192 -> splits 300cm boxes into 0..100 and 190/192..300!
  const res = placeFridgeOnWall(w, [w], 'side-by-side', 100, {});
  assert.equal(res.ok, true);
  assert.equal(res.carved, true);

  const bases = w.boxes.filter((b) => b.type === 'base').sort((a, b) => a.offsetX - b.offsetX);
  assert.equal(bases.length, 2);
  assert.equal(bases[0].offsetX, 0);
  assert.equal(bases[0].width, 100);
  assert.equal(bases[1].offsetX, 192);
  assert.equal(bases[1].width, 108);

  const wallsCabs = w.boxes.filter((b) => b.type === 'wall').sort((a, b) => a.offsetX - b.offsetX);
  assert.equal(wallsCabs.length, 2);
  assert.ok(w.boxes.some((b) => b.type === 'fridge' && b.width === 92));
});

test('Coupled door seam resize widens one door and shrinks its touching neighbor cleanly', () => {
  const box = createEmptyBox('base', 0, 100);
  box.doors = [
    { id: 'd1', startCm: 0, widthCm: 50, kind: 'door', drawerRatios: [] },
    { id: 'd2', startCm: 50, widthCm: 50, kind: 'door', drawerRatios: [] },
  ];
  box.unitDividers = [50];

  const applied = resizeDoorSeamCoupled(box, 'd1', 8);
  assert.equal(applied, 8);
  assert.equal(box.doors[0].widthCm, 58);
  assert.equal(box.doors[1].startCm, 58);
  assert.equal(box.doors[1].widthCm, 42);
  assert.deepEqual(box.unitDividers, [58]);

  // Respects 60cm/30cm bounds when pushed too far
  const capped = resizeDoorSeamCoupled(box, 'd1', 20);
  assert.equal(capped, 2);
  assert.equal(box.doors[0].widthCm, 60);
  assert.equal(box.doors[1].widthCm, 40);
});



